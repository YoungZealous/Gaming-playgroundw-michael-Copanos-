

import Phaser from 'phaser';

export class Lasso extends Phaser.GameObjects.Sprite {
    constructor(scene, x, y) {
        super(scene, x, y, 'rope lasso');
        scene.add.existing(this);
        scene.physics.add.existing(this);
        this.body.setAllowGravity(false);
        this.setActive(false);
        this.setVisible(false);
        this.speed = 800;
        this.range = 400;
        this.startX = 0;
        this.startY = 0;
        this.isCapturing = false;
    }

    fire(x, y, targetX, targetY) {
        this.setPosition(x, y);
        this.startX = x;
        this.startY = y;
        this.setActive(true);
        this.setVisible(true);

        const angle = Phaser.Math.Angle.Between(x, y, targetX, targetY);
        this.setRotation(angle);
        this.scene.physics.velocityFromRotation(angle, this.speed, this.body.velocity);
        
    }

    update(time, delta) {
        if (this.active) {
            const distance = Phaser.Math.Distance.Between(this.startX, this.startY, this.x, this.y);
            if (distance >= this.range) {
                this.destroy();
            }
        }
    }
    capture(enemy) {
        if (this.isCapturing) return;
        this.isCapturing = true;
        this.body.setVelocity(0, 0);
        if (enemy && enemy.isCapturable) {
            enemy.isCapturable = false; // Prevent double capture
            enemy.disableMovement(); // Assumes enemy has this method
            enemy.sprite.setTexture('captured bandit'); // Change enemy appearance
            
            // Link lasso to the enemy
            this.scene.add.existing(new Phaser.GameObjects.Line(
                this.scene, 0, 0, 
                this.startX, this.startY, 
                enemy.sprite.x, enemy.sprite.y, 
                0xffffff, 0.5
            ).setOrigin(0,0));
        }
        // Destroy the lasso sprite after a delay, leaving the captured enemy
        this.scene.time.delayedCall(100, () => {
            this.destroy();
        });
    }
}

