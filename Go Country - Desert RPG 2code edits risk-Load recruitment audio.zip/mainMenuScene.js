

import Phaser from 'phaser';

export class MainMenuScene extends Phaser.Scene {
    constructor() {
        super({ key: 'MainMenuScene' });
    }

    preload() {
        // Load assets for the menu
        this.load.image('desertGround', 'https://play.rosebud.ai/assets/desertGround.png?JqaT');
        this.load.audio('lassoSound', 'https://play.rosebud.ai/assets/lasso sound.mp3?tszE');
        this.load.spritesheet('rope lasso', 'https://play.rosebud.ai/assets/rope lasso.gif?lpbj', { frameWidth: 480, frameHeight: 480 });
    }

    create() {
        this.anims.create({
            key: 'rope_lasso_anim',
            frames: this.anims.generateFrameNumbers('rope lasso', { start: 0, end: -1 }), // Use all frames
            frameRate: 30, // Adjust frame rate as needed
            repeat: -1 // Loop indefinitely
        });
        
        // Create tiled background
        for (let x = 0; x < this.scale.width; x += 200) {
            for (let y = 0; y < this.scale.height; y += 200) {
                const ground = this.add.image(x, y, 'desertGround').setOrigin(0, 0);
                ground.setScale(0.2);
                ground.setAlpha(0.8);
            }
        }

        // Game Title
        this.add.text(this.scale.width / 2, this.scale.height / 2 - 150, 'GO COUNTRY', {
            fontSize: '80px',
            fontFamily: '"Georgia", serif',
            fill: '#FFD700', // Gold color
            stroke: '#4E342E', // Dark brown stroke
            strokeThickness: 8
        }).setOrigin(0.5);

        // Start Game Button
        const startButton = this.add.text(this.scale.width / 2, this.scale.height / 2, 'Start Game', {
            fontSize: '48px',
            fontFamily: '"Georgia", serif',
            fill: '#FFFFFF',
            backgroundColor: '#4E342E',
            padding: { x: 20, y: 10 },
        }).setOrigin(0.5);

        startButton.setInteractive({ useHandCursor: true });
        startButton.on('pointerover', () => startButton.setBackgroundColor('#6D4C41'));
        startButton.on('pointerout', () => startButton.setBackgroundColor('#4E342E'));
        startButton.on('pointerdown', () => {
            this.scene.start('GameScene');
        });

        // Controls Button
        const controlsButton = this.add.text(this.scale.width / 2, this.scale.height / 2 + 100, 'Controls', {
            fontSize: '48px',
            fontFamily: '"Georgia", serif',
            fill: '#FFFFFF',
            backgroundColor: '#4E342E',
            padding: { x: 20, y: 10 },
        }).setOrigin(0.5);

        controlsButton.setInteractive({ useHandCursor: true });
        controlsButton.on('pointerover', () => controlsButton.setBackgroundColor('#6D4C41'));
        controlsButton.on('pointerout', () => controlsButton.setBackgroundColor('#4E342E'));
        controlsButton.on('pointerdown', () => {
            this.scene.start('ControlsScene');
        });
        // Credits Button
        const creditsButton = this.add.text(this.scale.width / 2, this.scale.height / 2 + 200, 'Credits', {
            fontSize: '48px',
            fontFamily: '"Georgia", serif',
            fill: '#FFFFFF',
            backgroundColor: '#4E342E',
            padding: { x: 20, y: 10 },
        }).setOrigin(0.5);
        creditsButton.setInteractive({ useHandCursor: true });
        creditsButton.on('pointerover', () => creditsButton.setBackgroundColor('#6D4C41'));
        creditsButton.on('pointerout', () => creditsButton.setBackgroundColor('#4E342E'));
        creditsButton.on('pointerdown', () => {
            this.scene.start('CreditsScene');
        });
    }
}

