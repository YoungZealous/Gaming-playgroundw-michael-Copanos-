

import Phaser from 'phaser';

export class ChatManager {
    constructor(scene) {
        this.scene = scene;
        this.isListening = false;
        this.isSpeaking = false;
        this.activeNPC = null;
        this.onMessageCallback = null;
        // --- Voice Recognition Setup ---
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (SpeechRecognition) {
            this.recognition = new SpeechRecognition();
            this.recognition.continuous = true;
            this.recognition.interimResults = true;
            this.recognition.lang = 'en-US';
            this.recognition.onresult = (event) => {
                let interim_transcript = '';
                let final_transcript = '';
                for (let i = event.resultIndex; i < event.results.length; ++i) {
                    if (event.results[i].isFinal) {
                        final_transcript += event.results[i][0].transcript;
                    } else {
                        interim_transcript += event.results[i][0].transcript;
                    }
                }
                if (final_transcript && this.onMessageCallback) {
                    this.onMessageCallback(final_transcript);
                }
                // Update UI with interim results:
                if (interim_transcript) {
                    this.scene.uiManager.updateChatLog({ speaker: 'You', text: interim_transcript + '...', isFinal: false });
                }
            };
            this.recognition.onerror = (event) => {
                console.error('Speech recognition error:', event.error);
                this.stopListening();
            };
        } else {
            console.warn("Speech Recognition not supported in this browser.");
            this.recognition = null;
        }
    }
    async startListening(onMessageCallback) {
        if (this.isListening || !this.recognition) return;
        this.onMessageCallback = onMessageCallback;
        try {
            // Request microphone access
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            // The stream is not directly used here, but asking for it triggers the permission prompt.
            // Some browsers require this before starting recognition.
            stream.getTracks().forEach(track => track.stop()); // Stop the track immediately as we don't need to process the stream ourselves
            this.isListening = true;
            this.recognition.start();
            console.log("Speech recognition started.");
        } catch (err) {
            console.error("Microphone access denied:", err);
            // Optionally, show a message to the user in the UI
        }
    }
    stopListening() {
        if (!this.isListening || !this.recognition) return;
        this.isListening = false;
        this.recognition.stop();
        this.onMessageCallback = null;
        console.log("Speech recognition stopped.");
    }
    // This method is now simplified as the UI is handled by UIManager
    showChat() {
        const padding = 10;
        const width = 400;
        const height = 100;
        const x = (this.scene.scale.width - width) / 2;
        const y = this.scene.scale.height - height - 20;

        this.chatBox.clear();
        this.chatBox.fillStyle(0xFFFFFF, 0.9);
        this.chatBox.fillRoundedRect(x, y, width, height, 10);
        this.chatBox.lineStyle(2, 0x000000, 1);
        this.chatBox.strokeRoundedRect(x, y, width, height, 10);
        
        this.chatText.setPosition(x + padding, y + padding);

        this.chatBox.setVisible(true);
        this.chatText.setVisible(true);
    }

    hideChat() {
        this.chatBox.setVisible(false);
        this.chatText.setVisible(false);
    }

    // --- AI & Speech Synthesis (TTS) ---
    async getAIResponse(message, npc) {
        const personality = npc.personality || 'friendly';
        const playerName = this.scene.player.name || 'partner';
        // Personality-based placeholder responses
        const responses = {
            friendly: [
                `Well howdy, ${playerName}! That's right interesting.`,
                "A pleasure talkin' to ya. What else is on your mind?",
                "Good to hear from you!",
            ],
            gruff: [
                `Is that so? Get to the point.`,
                "Spit it out, I ain't got all day.",
                `Hmph. And?`,
            ],
            nervous: [
                "Oh! Uh, right... I think I see.",
                "Are you sure about that? Things are so dangerous...",
                `Y-yes, of course, ${playerName}. Be careful out there!`,
            ],
            stoic: [
                "Understood.",
                "Acknowledged.",
                "...",
                "Carry on."
            ]
        };
        
        // Command processing
        const lowerMessage = message.toLowerCase();
        // This is now handled in gameScene's handlePlayerChat to allow for shopping logic.
        // The gameScene will call this method if no special commands (like buying) are found.
        if (lowerMessage.includes('follow me')) {
            npc.isFollowing = true;
            npc.isGuarding = false;
            return "Alright, I'll follow your lead.";
        }
        if (lowerMessage.includes('stop following') || lowerMessage.includes("that's all")) {
            npc.isFollowing = false;
            return "Understood. I'll stay put here.";
        }
        if (lowerMessage.includes('guard this spot')) {
            npc.isFollowing = false;
            npc.isGuarding = true;
            npc.guardPosition = { x: npc.sprite.x, y: npc.sprite.y };
            npc.guardTargetPosition = null;
            return "You got it. I'll hold this position.";
        }
        
        const personalityResponses = responses[personality] || responses.friendly;
        return personalityResponses[Math.floor(Math.random() * personalityResponses.length)];
    }
    speak(text, npc, onStart, onEnd) {
        if (this.isSpeaking) return;
        this.isSpeaking = true;
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = 'en-US';
        const personality = npc ? npc.personality : 'friendly';
        
        const voiceSettings = {
            friendly: { rate: 1.0, pitch: 1.0 },
            gruff: { rate: 0.8, pitch: 0.5 },
            nervous: { rate: 1.2, pitch: 1.3 },
            stoic: { rate: 0.9, pitch: 0.7 }
        };
        
        const settings = voiceSettings[personality] || voiceSettings.friendly;
        utterance.rate = settings.rate;
        utterance.pitch = settings.pitch;
        
        // Find a suitable voice
        const voices = window.speechSynthesis.getVoices();
        utterance.voice = voices.find(v => v.name === 'Google US English' && v.lang === 'en-US') || voices.find(v => v.lang === 'en-US');
        
        utterance.onstart = () => {
            if (onStart) onStart();
        };
        utterance.onend = () => {
            this.isSpeaking = false;
            if (onEnd) onEnd();
        };
        
        utterance.onerror = (event) => {
            console.error('Speech synthesis error:', event.error);
            this.isSpeaking = false;
            if (onEnd) onEnd(); // Still call onEnd to unblock state
        };
        
        window.speechSynthesis.speak(utterance);
    }
}

