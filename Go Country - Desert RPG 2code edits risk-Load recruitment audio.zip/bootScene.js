

import Phaser from 'phaser';

export class BootScene extends Phaser.Scene {
    constructor() {
        super({ key: 'BootScene' });
    }

    preload() {
        // Display a loading message
        const { width, height } = this.scale;
        const loadingText = this.make.text({
            x: width / 2,
            y: height / 2,
            text: 'Loading...',
            style: {
                font: '20px monospace',
                fill: '#ffffff'
            }
        });
        loadingText.setOrigin(0.5, 0.5);

        // Load all essential assets for the game
        this.load.audio('backgroundMusic', 'https://play.rosebud.ai/assets/Go Country by Young Zealous (Lyric Video).mp3?SNtz');
        this.load.audio('lassoSound', 'https://play.rosebud.ai/assets/lasso sound.mp3?tszE');
        this.load.audio('mycountrypeople', 'https://play.rosebud.ai/assets/my country people.m4a?ZTvq');
        this.load.spritesheet('rope lasso', 'https://play.rosebud.ai/assets/rope lasso.gif?lpbj', { frameWidth: 480, frameHeight: 480 });
        this.load.image('desertGround', 'https://play.rosebud.ai/assets/desertGround.png?JqaT');

        // You can add all other game assets here
    }

    create() {
        // Once assets are loaded, transition to the Main Menu
        this.scene.start('MainMenuScene');
    }
}

