

import Phaser from 'phaser';

const DIALOGUE_STYLES = {
  fontFamily: '"Press Start 2P", sans-serif',
  fontSize: '12px',
  fill: '#fff',
  backgroundColor: 'rgba(0,0,0,0.7)',
  padding: { x: 10, y: 5 },
  wordWrap: { width: 300, useAdvancedWrap: true }
};

// NPC State enumeration
const NPCState = {
  FOLLOW: 'follow',
  GUARD: 'guard', 
  COMBAT: 'combat',
  IDLE: 'idle'
};
class Spy {
    constructor(scene, x, y, originalEnemyData) {
        this.scene = scene;
        this.sprite = scene.add.sprite(x, y, 'playerRanger'); // Using player texture for now
        this.sprite.setScale(0.12);
        this.sprite.setTint(0x999999); // Grey tint to differentiate
        this.sprite.setDepth(9);
        scene.physics.add.existing(this.sprite);
        this.sprite.body.setCollideWorldBounds(true);
        this.sprite.body.setSize(60, 80).setOffset(350, 400);
        this.isRevealed = false;
        this.revealTimer = null;
    }
    reveal() {
        if (this.isRevealed) return;
        this.isRevealed = true;
        this.sprite.clearTint(); // Revert to enemy appearance (or a specific "traitor" look)
        // For now, we'll just remove the spy tint. In future, could change texture.
        
        console.log("A spy has been revealed!");
        // Logic for what happens when a spy is revealed
        // e.g., attack player, attack other NPCs, etc.
        // For now, it just becomes a standard enemy again.
        this.scene.enemyManager.createEnemy(this.sprite.x, this.sprite.y, 'bandit');
        
        // Remove the spy object
        this.sprite.destroy();
    }
}


export class NPCSystem {
  constructor(scene, enemyManager) {
    this.scene = scene;
    this.enemyManager = enemyManager;
    this.npcs = scene.physics.add.group();
    this.recruitedNPCs = [];
    this.spies = [];
    this.guardMarkers = scene.physics.add.group();
    this.bullets = scene.physics.add.group({
        defaultKey: 'croppedBullet',
        maxSize: 20, // Increased bullet pool for elite NPCs
        runChildUpdate: true,
    });
    this.targetingLines = this.scene.add.graphics().setDepth(5);
    this.sightRangeGraphics = this.scene.add.graphics().setDepth(5);
    this.raycastGraphics = this.scene.add.graphics().setDepth(6); // For raycast visualization
    this.targetingArrows = this.scene.add.group(); // Group to hold targeting arrows
    
    // Set up mine collision detection for NPCs
    this.setupMineCollisions();
    
    // Performance optimization tracking
    this.lastTargetingUpdate = 0;
    this.lastSightRangeUpdate = 0;
    this.targetingUpdateInterval = 100; // Update targeting lines every 100ms instead of every frame
    this.sightRangeUpdateInterval = 200; // Update sight ranges every 200ms instead of every frame
    this.previousTargets = new Map(); // Track previous targets to detect changes
    
    // NPC Configurations - Increased cooldowns to reduce firing frequency
    this.npcConfigs = {
      'default': { health: 400, shootCooldown: 1200, tint: 0xADD8E6, scale: 0.12, sightRange: 300, speed: 180, nameColor: '#FFF', weaponType: 'shotgun', damage: 20, detectionRange: 800 },
      'sharpshooter': { health: 350, shootCooldown: 1000, tint: 0xADD8E6, scale: 0.12, sightRange: 350, speed: 150, nameColor: '#a8e6cf', weaponType: 'shotgun', damage: 25, detectionRange: 900 },
      'brawler': { health: 500, shootCooldown: 1400, tint: 0xADD8E6, scale: 0.13, sightRange: 250, speed: 220, nameColor: '#ff8b94', weaponType: 'shotgun', damage: 15, detectionRange: 700 }
    };
    this.reviveCandidate = null;
    this.revivePrompt = null;
    this.reviveCost = 15;
    this.trapEscapeCandidate = null;
    this.trapEscapePrompt = null;
    this.trapEscapeCost = 25; // Cost to free a trapped NPC
    // Create the new elite NPCs
    this.createNPC(300, 300, 'Jrabb', 'brawler');
    this.createNPC(350, 250, 'Poet', 'sharpshooter');
    this.createNPC(250, 350, 'C Worth', 'default');
    this.createNPC(400, 400, 'S.E.R.V', 'brawler');
    this.createNPC(100, 400, 'Richard', 'default');
    this.createNPC(400, 100, 'Matthew', 'sharpshooter');
    this.createNPC(100, 100, 'Charles', 'default');
    
    this.scene.input.keyboard.on('keydown-ONE', this.rallyAll, this);
  }
  
  setupMineCollisions() {
    // Set up collision detection between NPCs and mines
    if (this.scene.mineSystem && this.scene.mineSystem.mines) {
      this.scene.physics.add.overlap(
        this.npcs,
        this.scene.mineSystem.mines,
        (npc, mine) => {
          this.handleNPCMineCollision(npc, mine);
        }
      );
    }
  }
  
  handleNPCMineCollision(npc, mine) {
    if (!npc.isAlive || !mine.active) return;
    
    // Mine damage to NPC (significant damage)
    const mineDamage = 80; // Heavy damage from mines
    
    // Apply damage to the NPC
    this.takeDamage(npc, mineDamage);
    
    // Show mine explosion dialogue
    if (npc.isAlive) {
      const mineMessages = [
        "Mine! Take cover!",
        "Explosion incoming!",
        "Watch your step!",
        "Mines everywhere!",
        "That was close!"
      ];
      const message = Phaser.Math.RND.pick(mineMessages);
      this.showDialogue(npc, message, 3000);
    }
    
    // Trigger mine explosion through mine system
    if (this.scene.mineSystem && this.scene.mineSystem.explodeMine) {
      this.scene.mineSystem.explodeMine(mine);
    } else {
      // Fallback: deactivate mine if mine system method not available
      mine.setActive(false).setVisible(false);
    }
    
    // Create explosion effect at mine location
    this.createMineExplosionEffect(mine.x, mine.y);
    
    console.log(`${npc.name} triggered a mine and took ${mineDamage} damage!`);
  }
  
  createMineExplosionEffect(x, y) {
    // Create explosion particle effect
    const explosionParticles = this.scene.add.particles(x, y, 'croppedBullet', {
      speed: { min: 200, max: 400 },
      angle: { min: 0, max: 360 },
      scale: { start: 0.1, end: 0 },
      tint: [0xFF4500, 0xFF8C00, 0xFFFF00, 0xFF0000], // Orange to red explosion colors
      blendMode: 'ADD',
      lifespan: 500,
      quantity: 20,
      emitting: true
    });
    
    // Create screen shake effect for nearby explosions
    const distanceToPlayer = Phaser.Math.Distance.Between(
      x, y,
      this.scene.player.sprite.x, this.scene.player.sprite.y
    );
    
    if (distanceToPlayer < 300) {
      this.scene.cameras.main.shake(300, 0.02); // Brief screen shake
    }
    
    // Clean up particles after explosion
    this.scene.time.delayedCall(600, () => {
      if (explosionParticles) {
        explosionParticles.destroy();
      }
    });
    
    // Play explosion sound if available
    if (this.scene.sound.get('explosion')) {
      const volume = Math.max(0.3, 0.8 * (1 - distanceToPlayer / 500));
      this.scene.sound.play('explosion', { volume: volume });
    }
  }
  createNPC(x, y, name, type) {
    const config = this.npcConfigs[type] || this.npcConfigs['default'];
    
    // Use specific textures for named NPCs
    let texture = 'playerRanger'; // default
    if (name === 'C Worth') {
      texture = 'cworthNPC';
    } else if (name === 'Richard') {
      texture = 'richardNPC';
    } else if (name === 'Jrabb') {
      texture = 'jrabbNPC';
    } else if (name === 'Poet') {
      texture = 'poetNPC';
    }
    const npcSprite = this.npcs.create(x, y, texture);
    
    // Apply specific scale adjustments for certain NPCs
    let scale = config.scale;
    if (name === 'Poet' || name === 'Richard') {
      scale = 0.14; // Make them a little bigger
    }
    npcSprite.setScale(scale);
    npcSprite.setTint(config.tint);
    npcSprite.setCollideWorldBounds(true);
    npcSprite.setInteractive();
    npcSprite.setDepth(9);
    
    npcSprite.body.setSize(60, 80).setOffset(350, 400);
    npcSprite.name = name;
    
    // State Machine Properties
    npcSprite.currentState = NPCState.IDLE;
    npcSprite.previousState = NPCState.IDLE;
    npcSprite.stateChangeTime = this.scene.time.now;
    npcSprite.isRecruited = false;
    
    // Combat and Movement Properties
    npcSprite.health = config.health;
    npcSprite.maxHealth = config.health;
    npcSprite.isAlive = true;
    npcSprite.shootCooldown = config.shootCooldown;
    npcSprite.lastShot = 0;
    npcSprite.currentTarget = null;
    npcSprite.lastKnownTargetPosition = null;
    
    // Guard and Follow Properties
    npcSprite.guardPosition = null;
    npcSprite.guardMarker = null;
    npcSprite.followTarget = null;
    
    // Configuration
    npcSprite.sightRange = config.sightRange;
    npcSprite.speed = config.speed;
    npcSprite.weaponType = config.weaponType;
    npcSprite.damage = config.damage;
    npcSprite.detectionRange = config.detectionRange;
    
    // Movement Control
    npcSprite.movementLocked = false;
    npcSprite.engagementDistance = 200; // Distance to maintain while shooting
    npcSprite.isTrapped = false;
    npcSprite.trapVisual = null;
    
    // Create targeting arrow for this NPC
    const targetingArrow = this.scene.add.graphics().setDepth(50);
    npcSprite.targetingArrow = targetingArrow;
    npcSprite.arrowPulseTween = null; // Track the pulsing animation
    this.targetingArrows.add(targetingArrow);
    
    // Add alert icon like enemies have
    npcSprite.alertIcon = this.scene.add.text(npcSprite.x + 30, npcSprite.y - 60, '!', {
        fontSize: '32px', fill: '#FF0000', fontStyle: 'bold', stroke: '#000', strokeThickness: 2
    }).setOrigin(0.5).setDepth(100).setVisible(false);
    
    // Health bar for the NPC
    const healthBar = this.scene.add.graphics();
    npcSprite.healthBar = healthBar;
    this.updateHealthBar(npcSprite);
    
    // Add dialogue bubble
    const dialogueBubble = this.scene.add.text(0, 0, '', DIALOGUE_STYLES)
        .setOrigin(0.5, 1)
        .setVisible(false)
        .setDepth(100);
    npcSprite.dialogueBubble = dialogueBubble;
    // Add name text
    const nameText = this.scene.add.text(x, y, name, {
        fontFamily: '"Press Start 2P", sans-serif',
        fontSize: '16px', fill: config.nameColor,
        stroke: '#000', strokeThickness: 4,
        align: 'center'
    }).setOrigin(0.5, 1).setDepth(100);
    npcSprite.nameText = nameText;
    
    // Add shooting indicator text
    const shootingIndicator = this.scene.add.text(x, y + 30, 'Shooting', {
        fontFamily: '"Press Start 2P", sans-serif',
        fontSize: '12px', 
        fill: '#FFD700',
        stroke: '#000', 
        strokeThickness: 2,
        align: 'center'
    }).setOrigin(0.5, 0).setDepth(100).setVisible(false);
    npcSprite.shootingIndicator = shootingIndicator;
    
    return npcSprite;
  }
  getAliveRecruitedNPCs() {
    return this.recruitedNPCs.filter(npc => npc.isAlive);
  }
  
  // State Machine Methods
  changeNPCState(npc, newState) {
    if (npc.currentState === newState) return;
    
    console.log(`${npc.name} transitioning from ${npc.currentState} to ${newState}`);
    
    // Exit current state
    this.exitState(npc, npc.currentState);
    
    // Set new state
    npc.previousState = npc.currentState;
    npc.currentState = newState;
    npc.stateChangeTime = this.scene.time.now;
    
    // Enter new state
    this.enterState(npc, newState);
    
    // Update visual indicators
    this.updateNPCVisuals(npc);
  }
  
  enterState(npc, state) {
    switch(state) {
      case NPCState.FOLLOW:
        npc.followTarget = this.scene.player.sprite;
        break;
      case NPCState.GUARD:
        // Guard position should already be set when transitioning to guard
        break;
      case NPCState.COMBAT:
        npc.movementLocked = false; // Ensure NPC can move during combat
        break;
      case NPCState.IDLE:
        npc.body.setVelocity(0, 0);
        break;
    }
  }
  
  exitState(npc, state) {
    switch(state) {
      case NPCState.COMBAT:
        npc.currentTarget = null;
        npc.lastKnownTargetPosition = null;
        if (npc.alertIcon) {
          npc.alertIcon.setVisible(false);
        }
        break;
    }
  }
  
  updateNPCVisuals(npc) {
    if (!npc.nameText) return;
    
    switch(npc.currentState) {
      case NPCState.FOLLOW:
        npc.nameText.setStyle({ fill: '#00FF00' }); // Green for following
        break;
      case NPCState.GUARD:
        npc.nameText.setStyle({ fill: '#FFA500' }); // Orange for guarding
        break;
      case NPCState.COMBAT:
        npc.nameText.setStyle({ fill: '#FF4444' }); // Red for combat
        break;
      case NPCState.IDLE:
        const originalConfig = this.npcConfigs.default;
        npc.nameText.setStyle({ fill: originalConfig.nameColor }); // Default color
        break;
    }
  }
  
  updateHealthBar(npcSprite) {
      if (!npcSprite.isAlive) {
          if (npcSprite.healthBar) npcSprite.healthBar.clear();
          return;
      }
      const bar = npcSprite.healthBar;
      bar.clear();
      
      const width = 40;
      const height = 5;
      const x = npcSprite.x - width / 2;
      const y = npcSprite.y - npcSprite.displayHeight / 2 - 10;
      
      // Background
      bar.fillStyle(0x000000, 0.5);
      bar.fillRect(x, y, width, height);
      
      // Health
      const healthPercentage = npcSprite.health / npcSprite.maxHealth;
      bar.fillStyle(0x00FF00, 1);
      bar.fillRect(x, y, width * healthPercentage, height);
      
      bar.setDepth(npcSprite.depth);
  }
  
  showDialogue(npc, text, duration = 3000) {
      const bubble = npc.dialogueBubble;
      if (!bubble) return;

      bubble.setText(text);
      bubble.setPosition(npc.x, npc.y - npc.displayHeight / 2 - 15);
      bubble.setVisible(true);

      if (this.scene.dialogueTimers && this.scene.dialogueTimers[npc.name]) {
          this.scene.dialogueTimers[npc.name].remove(false);
      }
      
      this.scene.dialogueTimers = this.scene.dialogueTimers || {};
      this.scene.dialogueTimers[npc.name] = this.scene.time.delayedCall(duration, () => {
          bubble.setVisible(false);
      });
  }

  toggleRecruitment(pointer) {
    const worldPoint = this.scene.cameras.main.getWorldPoint(pointer.x, pointer.y);
    const clickedNPC = this.scene.physics.closest(worldPoint, this.npcs.getChildren());
    if (clickedNPC && Phaser.Math.Distance.Between(worldPoint.x, worldPoint.y, clickedNPC.x, clickedNPC.y) < 50 && !clickedNPC.isTrapped) {
      if (!clickedNPC.isRecruited) {
        // Recruit the NPC
        clickedNPC.isRecruited = true;
        // Make only the name green, not the entire sprite
        clickedNPC.nameText.setStyle({ fill: '#00FF00' });
        this.recruitedNPCs.push(clickedNPC);
        console.log(`RECRUITED: ${clickedNPC.name} - Total recruited: ${this.recruitedNPCs.length}`);
        
        if (clickedNPC.name === 'Jrabb') {
            this.scene.sound.play('mycountrypeople', { volume: 0.7 });
        } else {
            this.showDialogue(clickedNPC, "I'm with you!");
        }
        // Automatically equip recruited NPC with auto gun
        if (this.scene.equipRecruitedNPCWithAutoGun) {
          this.scene.equipRecruitedNPCWithAutoGun(clickedNPC);
        }
      } else { 
        // Un-recruit if they are not guarding
        if (!clickedNPC.isGuard) {
            clickedNPC.isRecruited = false;
            // Reset name color to original config color
            const originalConfig = this.npcConfigs[clickedNPC.name === 'C Worth' || clickedNPC.name === 'Richard' || clickedNPC.name === 'Jrabb' || clickedNPC.name === 'Poet' ? 'default' : 'default'];
            clickedNPC.nameText.setStyle({ fill: originalConfig.nameColor });
            // Remove from array
            this.recruitedNPCs = this.recruitedNPCs.filter(npc => npc !== clickedNPC);
            this.showDialogue(clickedNPC, "Standing down.");
        } else {
            this.showDialogue(clickedNPC, "On guard! Use Rally to call me back.");
        }
      }
    }
  }

  commandGuardMove(pointer) {
    const worldPoint = this.scene.cameras.main.getWorldPoint(pointer.x, pointer.y);
    
    // Find the first recruited NPC that is NOT currently guarding
    const commandedNPC = this.getAliveRecruitedNPCs().find(npc => !npc.isGuard);
    if (commandedNPC) {
        commandedNPC.isGuard = true;
        commandedNPC.guardPosition = { x: worldPoint.x, y: worldPoint.y };
        commandedNPC.nameText.setStyle({ fill: '#FFA500' }); // Orange name for guards
        // If this NPC already had a marker (from a previous guard duty), destroy it.
        if (commandedNPC.guardMarker) {
            commandedNPC.guardMarker.destroy();
        }
        // Create a new marker at the target location.
        const marker = this.guardMarkers.create(worldPoint.x, worldPoint.y, 'guardMarker');
        marker.setScale(0.05).setDepth(1);
        commandedNPC.guardMarker = marker;
        this.showDialogue(commandedNPC, "On my way!");
    } else {
        // Optional: Provide feedback if no NPCs are available to command.
        const feedbackText = this.scene.add.text(worldPoint.x, worldPoint.y, "All units deployed!", {
            fontFamily: '"Press Start 2P", sans-serif',
            fontSize: '14px',
            fill: '#ffdd00',
            stroke: '#000',
            strokeThickness: 2,
            align: 'center'
        }).setOrigin(0.5).setDepth(101);
        this.scene.time.delayedCall(2000, () => {
            feedbackText.destroy();
        });
    }
  }
  commandMoveTo(npc, targetPosition) {
    if (npc && npc.isRecruited) {
        npc.isGuard = true;
        npc.guardPosition = { x: targetPosition.x, y: targetPosition.y };
        npc.nameText.setStyle({ fill: '#FFA500' }); // Orange name for guards
        this.showDialogue(npc, "Moving to position!");
    }
  }
  update(player, enemies) {
    const currentTime = this.scene.time.now;
    let needsTargetingRedraw = false;
    let needsSightRangeRedraw = false;
    
    // Only clear and redraw graphics at specific intervals or when targets change
    if (currentTime - this.lastTargetingUpdate > this.targetingUpdateInterval) {
      needsTargetingRedraw = true;
      this.lastTargetingUpdate = currentTime;
    }
    
    if (currentTime - this.lastSightRangeUpdate > this.sightRangeUpdateInterval) {
      needsSightRangeRedraw = true;
      this.lastSightRangeUpdate = currentTime;
    }
    
    // Check if any NPC targets have changed
    let targetsChanged = false;
    this.npcs.getChildren().forEach(npc => {
      const currentTarget = npc.currentTarget?.sprite?.active ? npc.currentTarget : null;
      const previousTarget = this.previousTargets.get(npc.name);
      
      if (currentTarget !== previousTarget) {
        targetsChanged = true;
        this.previousTargets.set(npc.name, currentTarget);
      }
    });
    
    // Clear graphics only when necessary
    if (needsTargetingRedraw || targetsChanged) {
      this.targetingLines.clear();
      this.raycastGraphics.clear();
      this.targetingArrows.getChildren().forEach(arrow => arrow.clear());
    }
    
    if (needsSightRangeRedraw) {
      this.sightRangeGraphics.clear();
    }
    
    this.npcs.getChildren().forEach(npc => {
        if (!npc.isAlive) {
            npc.body.setVelocity(0);
            return;
        }
        // If trapped, halt all actions and prevent further state updates
        if (npc.isTrapped) {
            npc.body.setVelocity(0);
            if (npc.alertIcon) npc.alertIcon.setVisible(false);
            if (npc.shootingIndicator) npc.shootingIndicator.setVisible(false);
            // Create and position the trap visual if it doesn't exist
            if (!npc.trapVisual) {
                npc.trapVisual = this.scene.add.image(npc.x, npc.y, 'player and npc jail trap')
                    .setScale(0.15)
                    .setDepth(npc.depth + 1);
            }
            npc.trapVisual.setPosition(npc.x, npc.y);
            return;
        } else if (npc.trapVisual) {
            // If no longer trapped, but the visual still exists, destroy it.
            npc.trapVisual.destroy();
            npc.trapVisual = null;
        }
        
        this.updateHealthBar(npc);
        
        // Update alert icon position
        if (npc.alertIcon) {
            npc.alertIcon.setPosition(npc.x + 30, npc.y - 60);
        }
        
        // Update name and dialogue positioning
        if (npc.nameText) {
            const nameY = npc.y - npc.displayHeight / 2 - 10;
            npc.nameText.setPosition(npc.x, nameY);
            if (npc.dialogueBubble && npc.dialogueBubble.visible) {
                const bubbleY = nameY - npc.nameText.height - 5;
                npc.dialogueBubble.setPosition(npc.x, bubbleY);
            }
        } else if (npc.dialogueBubble && npc.dialogueBubble.visible) {
             npc.dialogueBubble.setPosition(npc.x, npc.y - npc.displayHeight / 2 - 15);
        }
        
        // Update shooting indicator position
        if (npc.shootingIndicator) {
            npc.shootingIndicator.setPosition(npc.x, npc.y + npc.displayHeight / 2 + 15);
        }
        
        // Draw sight range for recruited NPCs - only when needed
        if (needsSightRangeRedraw && npc.isRecruited && npc.isAlive) {
            this.sightRangeGraphics.lineStyle(2, 0x00ffff, 0.2);
            this.sightRangeGraphics.strokeCircle(npc.x, npc.y, npc.detectionRange);
        }
        
        // Draw targeting lines and arrows - only when needed
        if ((needsTargetingRedraw || targetsChanged) && npc.currentTarget && npc.currentTarget.sprite.active) {
            this.targetingLines.lineStyle(1, 0xff0000, 0.7);
            this.targetingLines.strokeLineShape({ 
                x1: npc.x, y1: npc.y, 
                x2: npc.currentTarget.sprite.x, y2: npc.currentTarget.sprite.y 
            });
            this.drawTargetingArrow(npc, npc.currentTarget);
        } else if (!npc.currentTarget || !npc.currentTarget.sprite.active) {
            // Stop pulsing animation when no target
            if (npc.arrowPulseTween) {
                npc.arrowPulseTween.remove();
                npc.arrowPulseTween = null;
                npc.targetingArrow.setAlpha(1);
            }
        }
        
        // Core State Machine Logic
        this.updateNPCState(npc, player, enemies);
    });
    this.spies.forEach(spy => spy.update());
    // Handle interaction prompts for reviving or freeing NPCs
    const interactionKeyPressed = Phaser.Input.Keyboard.JustDown(this.scene.wasd.E);
    this.handleRevive(player, interactionKeyPressed);
    this.handleTrapEscape(player, interactionKeyPressed);
  }
  
  updateNPCState(npc, player, enemies) {
    if (npc.isTrapped) {
        if(npc.currentState !== NPCState.IDLE) {
            this.changeNPCState(npc, NPCState.IDLE);
        }
        npc.body.setVelocity(0,0);
        return; // Skip state updates if trapped
    }
    // Detect enemies for all recruited NPCs
    const detectedEnemy = npc.isRecruited ? this.aggressiveEnemyDetection(npc, enemies) : null;
    
    // State transition logic
    switch(npc.currentState) {
      case NPCState.IDLE:
        if (npc.isRecruited) {
          if (detectedEnemy) {
            this.changeNPCState(npc, NPCState.COMBAT);
          } else if (npc.guardPosition) {
            this.changeNPCState(npc, NPCState.GUARD);
          } else {
            this.changeNPCState(npc, NPCState.FOLLOW);
          }
        } else {
          this.executeIdleBehavior(npc);
        }
        break;
        
      case NPCState.FOLLOW:
        if (detectedEnemy) {
          this.changeNPCState(npc, NPCState.COMBAT);
        } else if (npc.guardPosition) {
          this.changeNPCState(npc, NPCState.GUARD);
        } else if (!npc.isRecruited) {
          this.changeNPCState(npc, NPCState.IDLE);
        } else {
          this.executeFollowBehavior(npc, player);
        }
        break;
        
      case NPCState.GUARD:
        if (detectedEnemy) {
          this.changeNPCState(npc, NPCState.COMBAT);
        } else if (!npc.guardPosition) {
          if (npc.isRecruited) {
            this.changeNPCState(npc, NPCState.FOLLOW);
          } else {
            this.changeNPCState(npc, NPCState.IDLE);
          }
        } else {
          this.executeGuardBehavior(npc);
        }
        break;
        
      case NPCState.COMBAT:
        if (!detectedEnemy || !npc.isRecruited) {
          if (npc.guardPosition && npc.isRecruited) {
            this.changeNPCState(npc, NPCState.GUARD);
          } else if (npc.isRecruited) {
            this.changeNPCState(npc, NPCState.FOLLOW);
          } else {
            this.changeNPCState(npc, NPCState.IDLE);
          }
        } else {
          this.executeCombatBehavior(npc, detectedEnemy);
        }
        break;
    }
  }
  
  executeIdleBehavior(npc) {
    if (!npc.idleTimer || this.scene.time.now > npc.idleTimer) {
        const moveX = Math.random() * 100 - 50;
        const moveY = Math.random() * 100 - 50;
        npc.body.setVelocity(moveX, moveY);
        npc.idleTimer = this.scene.time.now + Phaser.Math.Between(2000, 5000);
        
        // Stop after a short duration
        this.scene.time.delayedCall(500, () => {
            if (npc.active) npc.body.setVelocity(0,0);
        });
    }
  }
  
  executeFollowBehavior(npc, player) {
    this.handleFollowAndSeparate(npc, player);
  }
  
  executeGuardBehavior(npc) {
    // Move to guard position
    const distanceToGuardPos = npc.guardPosition ? 
      Phaser.Math.Distance.Between(npc.x, npc.y, npc.guardPosition.x, npc.guardPosition.y) : Infinity;
    const arrivedAtPost = distanceToGuardPos <= 20;
    
    if (arrivedAtPost) {
      npc.body.setVelocity(0, 0);
    } else if (npc.guardPosition) {
      this.scene.physics.moveTo(npc, npc.guardPosition.x, npc.guardPosition.y, npc.speed);
    } else {
      npc.body.setVelocity(0, 0); // Failsafe
    }
  }
  
  executeCombatBehavior(npc, detectedEnemy) {
    const distance = Phaser.Math.Distance.Between(npc.x, npc.y, detectedEnemy.sprite.x, detectedEnemy.sprite.y);
    console.log(`${npc.name} executing combat behavior - Enemy distance: ${distance}, Engagement range: ${npc.engagementDistance}`);
    
    // Set target and alert state
    npc.currentTarget = detectedEnemy;
    if (npc.alertIcon) {
      npc.alertIcon.setVisible(true);
    }
    
    // Enhanced movement logic - be more aggressive in closing distance
    const optimalRange = Math.min(npc.engagementDistance, npc.detectionRange * 0.7);
    
    if (distance > optimalRange) {
      // Move towards enemy aggressively
      this.scene.physics.moveToObject(npc, detectedEnemy.sprite, npc.speed * 1.2);
      console.log(`${npc.name} moving towards enemy (distance: ${distance} > optimal: ${optimalRange})`);
    } else if (distance < npc.engagementDistance * 0.5) {
      // Too close - back away while maintaining line of sight
      const retreatAngle = Phaser.Math.Angle.Between(detectedEnemy.sprite.x, detectedEnemy.sprite.y, npc.x, npc.y);
      npc.body.setVelocity(Math.cos(retreatAngle) * npc.speed * 0.8, Math.sin(retreatAngle) * npc.speed * 0.8);
    } else {
      // At good range - stop and focus on shooting
      npc.body.setVelocity(0, 0);
    }
    
    // Enhanced shooting logic - shoot more frequently when in good range
    const shootingRange = Math.min(npc.detectionRange, distance * 1.1);
    if (distance <= shootingRange) {
      const canShoot = this.scene.time.now > npc.lastShot + npc.shootCooldown;
      if (canShoot) {
        console.log(`${npc.name} FIRING at enemy! Distance: ${distance}, Range: ${shootingRange}`);
        this.shootAt(npc, detectedEnemy);
        npc.lastShot = this.scene.time.now;
        
        // Show shooting indicator
        this.showShootingIndicator(npc);
      } else {
        const cooldownRemaining = (npc.lastShot + npc.shootCooldown) - this.scene.time.now;
        console.log(`${npc.name} weapon cooling down: ${cooldownRemaining}ms remaining`);
      }
    }
  }

  handleFollowAndSeparate(npc, player) {
    const aliveRecruited = this.getAliveRecruitedNPCs();
    const npcIndex = aliveRecruited.findIndex(recruitedNpc => recruitedNpc === npc);
    if (npcIndex === -1) {
      npc.body.setVelocity(0, 0);
      return;
    }
    const formationAngle = Math.PI / 4; // V-shape angle (45 degrees)
    const side = (npcIndex % 2 === 0) ? -1 : 1; // Alternate left and right
    const rank = Math.floor(npcIndex / 2); // How far back in the formation
    const formationOffsetDistance = 120 + (rank * 80); // Base distance + rank spacing
    const angleOffset = side * (formationAngle / 2);
    // Calculate the target position relative to the player
    const playerAngle = player.sprite.rotation;
    const targetAngle = playerAngle + angleOffset;
    const targetX = player.sprite.x - Math.cos(targetAngle) * formationOffsetDistance;
    const targetY = player.sprite.y - Math.sin(targetAngle) * formationOffsetDistance;
    const distanceToTarget = Phaser.Math.Distance.Between(npc.x, npc.y, targetX, targetY);
    // Stop if very close to the target position
    if (distanceToTarget < 10) {
      npc.body.setVelocity(0, 0);
      return;
    }
    // Move towards the formation position
    const moveAngle = Phaser.Math.Angle.Between(npc.x, npc.y, targetX, targetY);
    
    // Scale speed based on distance to prevent jittering
    const moveSpeed = Math.min(npc.speed, distanceToTarget * 1.5);
    this.scene.physics.velocityFromRotation(moveAngle, moveSpeed, npc.body.velocity);
  }

  shootAt(npc, enemy) {
    const baseAngle = Phaser.Math.Angle.Between(npc.x, npc.y, enemy.sprite.x, enemy.sprite.y);
    this.createMuzzleFlash(npc.x, npc.y, baseAngle);
    switch (npc.weaponType) {
        case 'shotgun':
            const pelletCount = 5;
            const spread = Phaser.Math.DegToRad(20); // 20 degree spread
            for (let i = 0; i < pelletCount; i++) {
                const angle = baseAngle - spread / 2 + (spread * i / (pelletCount - 1));
                this.fireSingleBullet(npc, angle, npc.damage);
            }
            break;
        case 'rifle':
            this.fireSingleBullet(npc, baseAngle, npc.damage);
            break;
        case 'pistol':
        default:
            this.fireSingleBullet(npc, baseAngle, npc.damage);
            break;
    }
  }
  fireSingleBullet(npc, angle, damage) {
    const bullet = this.bullets.get(null, null, 'croppedBullet');
    if (bullet) {
        bullet.setActive(true).setVisible(true);
        bullet.setPosition(npc.x, npc.y);
        bullet.setRotation(angle);
        bullet.setScale(0.08, 0.08); // Larger and more visible bullets
        bullet.setTint(0xFFFF00); // Yellow tint for NPC bullets
        bullet.setDepth(50); // Ensure bullets render above ground
        // Use circular body for better collision
        bullet.body.isCircle = true;
        bullet.body.setSize(bullet.width, bullet.height);
        bullet.damage = damage;
        const speed = 900; // Slower speed so bullets are visible
        bullet.body.setVelocity(
            Math.cos(angle) * speed,
            Math.sin(angle) * speed
        );
        this.scene.time.delayedCall(2000, () => {
            if (bullet.active) {
                bullet.disableBody(true, true);
            }
        });
    }
  }
  
  createMuzzleFlash(x, y, angle) {
    const particles = this.scene.add.particles(x, y, 'croppedBullet', {
        speed: { min: 100, max: 250 },
        // Emitter angle points in the direction of the shot, with a small cone
        angle: { min: Phaser.Math.RadToDeg(angle) - 30, max: Phaser.Math.RadToDeg(angle) + 30 },
        scale: { start: 0.02, end: 0 }, // Smaller muzzle flash particles
        tint: [0xFFFF00, 0xFFDD00, 0xFFFFFF], // Yellow-to-white flash for shotgun NPCs
        blendMode: 'ADD',
        lifespan: 100,
        quantity: 12, // More particles for shotgun effect
        emitting: true
    });
    
    this.scene.time.delayedCall(200, () => {
        if (particles) {
            particles.destroy();
        }
    });
  }
  
  takeDamage(npc, damage) {
    if (!npc.isAlive) return;
    
    // Apply 50% damage reduction to make NPCs more survivable
    const reducedDamage = Math.ceil(damage * 0.5);
    console.log(`${npc.name} taking ${reducedDamage} damage (reduced from ${damage})`);
    
    npc.health -= reducedDamage;
    npc.setTint(0xff0000);
    this.scene.time.delayedCall(100, () => {
        if (!npc.isAlive) return;
        // Always restore original sprite appearance - only names stay colored
        const originalConfig = this.npcConfigs.default;
        npc.setTint(originalConfig.tint);
    });

    if (npc.health <= 0) {
      npc.health = 0;
      npc.isAlive = false;
      this.die(npc);
    }
  }
  
  die(npc) {
      console.log('NPC has died');
      npc.body.setVelocity(0, 0);
      npc.setAngle(90);
      npc.isRecruited = false;
      npc.isGuard = false;
      if (npc.guardMarker) {
          npc.guardMarker.destroy();
          npc.guardMarker = null;
      }
      // Does not remove from recruitedNPCs list yet, so they can be revived
      this.showDialogue(npc, "I'm down!", 5000);
      if (npc.healthBar) npc.healthBar.clear();
      if (npc.nameText) npc.nameText.setVisible(false);
      
      // Stop being interactive so you can't recruit a dead NPC
      npc.disableInteractive();
  }
  
  handleRevive(player, isReviving) {
    const reviveRange = 80;
    let closestDeadNPC = null;
    let minDistance = Infinity;
    // Find the closest dead NPC
    this.npcs.getChildren().forEach(npc => {
        if (!npc.isAlive) {
            const distance = Phaser.Math.Distance.Between(player.sprite.x, player.sprite.y, npc.x, npc.y);
            if (distance < minDistance) {
                minDistance = distance;
                closestDeadNPC = npc;
            }
        }
    });
    // Check if the closest dead NPC is within range
    if (closestDeadNPC && minDistance <= reviveRange) {
        // We have a potential revival target
        if (this.reviveCandidate !== closestDeadNPC) {
            this.destroyRevivePrompt();
            this.reviveCandidate = closestDeadNPC;
            this.createRevivePrompt(closestDeadNPC);
        }
        
        // Update prompt position
        if (this.revivePrompt) {
            this.revivePrompt.setPosition(this.reviveCandidate.x, this.reviveCandidate.y - this.reviveCandidate.displayHeight / 2 - 20);
        }
        
        // Handle the actual revival action
        if (isReviving && this.reviveCandidate) {
            // Check if player has enough coins (assuming player object has a 'coins' property)
            if (this.scene.player.coins >= this.reviveCost) {
                this.scene.player.coins -= this.reviveCost;
                this.reviveNPC(this.reviveCandidate);
                this.destroyRevivePrompt();
                this.reviveCandidate = null;
                 // Prevent immediate re-revive with one key press
                this.scene.player.reviveKeyPressed = false; 
            } else {
                // Find a nearby living NPC to show the dialogue, as the player doesn't have a bubble
                const livingNPC = this.findNearestNPC(this.scene.player.sprite.x, this.scene.player.sprite.y, 200);
                if (livingNPC) {
                   this.showDialogue(livingNPC, "We need more coin to revive them!", 2000);
                }
            }
        }
    } else {
        // No valid target in range
        if (this.reviveCandidate) {
            this.destroyRevivePrompt();
            this.reviveCandidate = null;
        }
    }
  }
  
  handleTrapEscape(player, isInteracting) {
    const escapeRange = 80;
    let closestTrappedNPC = null;
    let minDistance = Infinity;
    
    // Find the closest trapped (and alive) NPC
    this.npcs.getChildren().forEach(npc => {
        if (npc.isAlive && npc.isTrapped) {
            const distance = Phaser.Math.Distance.Between(player.sprite.x, player.sprite.y, npc.x, npc.y);
            if (distance < minDistance) {
                minDistance = distance;
                closestTrappedNPC = npc;
            }
        }
    });
    
    // Check if the closest trapped NPC is within range
    if (closestTrappedNPC && minDistance <= escapeRange) {
        if (this.trapEscapeCandidate !== closestTrappedNPC) {
            this.destroyTrapEscapePrompt();
            this.trapEscapeCandidate = closestTrappedNPC;
            this.createTrapEscapePrompt(closestTrappedNPC);
        }
        
        // Update prompt position
        if (this.trapEscapePrompt) {
            this.trapEscapePrompt.setPosition(this.trapEscapeCandidate.x, this.trapEscapeCandidate.y - this.trapEscapeCandidate.displayHeight / 2 - 20);
        }
        
        // Handle the escape action
        if (isInteracting && this.trapEscapeCandidate) {
            if (this.scene.player.money >= this.trapEscapeCost) {
                this.scene.player.money -= this.trapEscapeCost;
                this.scene.sound.play('chaChing', { volume: 0.5 });
                this.freeTrappedNPC(this.trapEscapeCandidate);
                this.destroyTrapEscapePrompt();
                this.trapEscapeCandidate = null;
            } else {
                this.showDialogue(this.trapEscapeCandidate, "Not enough coins!", 2000);
            }
        }
    } else {
        // No valid target in range
        if (this.trapEscapeCandidate) {
            this.destroyTrapEscapePrompt();
            this.trapEscapeCandidate = null;
        }
    }
  }
  createTrapEscapePrompt(npc) {
      if (this.trapEscapePrompt) this.trapEscapePrompt.destroy();
      
      const cost = this.trapEscapeCost;
      const container = this.scene.add.container(npc.x, npc.y - npc.displayHeight / 2 - 20).setDepth(101);
      
      const text = `[E] Free Ally `;
      const costText = `x ${cost}`;
      
      const promptText = this.scene.add.text(0, 0, text, {
          fontFamily: '"Press Start 2P", sans-serif',
          fontSize: '22px',
          fill: '#00FFFF', // Cyan color for trap prompt
          backgroundColor: 'rgba(0,0,0,0.7)',
          padding: { x: 15, y: 8 },
      }).setOrigin(0.5, 0.5);
      
      const coinIcon = this.scene.add.image(promptText.width / 2 + 15, 0, 'coinIcon').setScale(0.08);
      const costLabel = this.scene.add.text(coinIcon.x + coinIcon.displayWidth / 2 + 8, 0, costText, {
          fontFamily: '"Press Start 2P", sans-serif',
          fontSize: '22px',
          fill: '#00FFFF',
          padding: { y: 8 },
      }).setOrigin(0, 0.5);
      
      // Center the whole prompt
      const totalWidth = promptText.width + coinIcon.displayWidth + costLabel.width + 20;
      promptText.x = -totalWidth / 2 + promptText.width / 2;
      coinIcon.x = promptText.x + promptText.width / 2 + 15;
      costLabel.x = coinIcon.x + coinIcon.displayWidth / 2 - 5;
      
      container.add([promptText, coinIcon, costLabel]);
      this.trapEscapePrompt = container;
  }
  destroyTrapEscapePrompt() {
      if (this.trapEscapePrompt) {
          this.trapEscapePrompt.destroy();
          this.trapEscapePrompt = null;
      }
  }
  freeTrappedNPC(npc) {
      if (npc.trapVisual) {
        npc.trapVisual.destroy();
        npc.trapVisual = null;
      }
      this.scene.jailTrapSystem.releaseNPC(npc);
      this.showDialogue(npc, "I'm free! Thanks for the help.", 3000);
      this.changeNPCState(npc, NPCState.IDLE); // Reset state to re-evaluate behavior
      
      // If the NPC was part of the squad, ensure it returns to following.
      if (this.recruitedNPCs.includes(npc)) {
          npc.isRecruited = true;
          this.changeNPCState(npc, NPCState.FOLLOW);
      }
  }
  createRevivePrompt(npc) {
      if (this.revivePrompt) {
          this.revivePrompt.destroy();
      }
      const container = this.scene.add.container(npc.x, npc.y - npc.displayHeight / 2 - 20).setDepth(101);
      const text = `[E] Revive  `; // Text without cost
      const costText = `x ${this.reviveCost}`; // Cost text
      
      const promptText = this.scene.add.text(0, 0, text, {
          fontFamily: '"Press Start 2P", sans-serif',
          fontSize: '22px', // Made text bigger
          fill: '#ffff00',
          backgroundColor: 'rgba(0,0,0,0.7)',
          padding: { x: 15, y: 8 }, // Increased padding
      }).setOrigin(0.5, 0.5);
      const coinIcon = this.scene.add.image(promptText.width / 2 + 15, 0, 'coin').setScale(0.08);
      const costLabel = this.scene.add.text(coinIcon.x + coinIcon.displayWidth / 2 + 8, 0, costText, {
          fontFamily: '"Press Start 2P", sans-serif',
          fontSize: '22px',
          fill: '#ffff00',
          padding: { y: 8 },
      }).setOrigin(0, 0.5);
      const totalWidth = promptText.width + coinIcon.displayWidth + costLabel.width + 20; // Some spacing
      promptText.x = -totalWidth / 2 + promptText.width / 2;
      coinIcon.x = promptText.x + promptText.width / 2 + 15;
      costLabel.x = coinIcon.x + coinIcon.displayWidth / 2 - 5;
      container.add([promptText, coinIcon, costLabel]);
      this.revivePrompt = container;
  }
  destroyRevivePrompt() {
      if (this.revivePrompt) {
          this.revivePrompt.destroy();
          this.revivePrompt = null;
      }
  }
  reviveNPC(npc) {
      npc.isAlive = true;
      npc.health = npc.maxHealth; // Revive with full health
      npc.setAngle(0);
      this.changeNPCState(npc, NPCState.IDLE); // Reset state to re-evaluate behavior
      npc.setInteractive();
      this.updateHealthBar(npc);
      if (npc.nameText) npc.nameText.setVisible(true);
      // Automatically re-recruit them
      if (!this.recruitedNPCs.includes(npc)) {
          this.recruitedNPCs.push(npc);
      }
      npc.isRecruited = true;
      // Only make name green, not the sprite
      npc.nameText.setStyle({ fill: '#00FF00' });
      
      this.showDialogue(npc, "Thanks! I'm back in the fight.", 4000);
      
      // Automatically equip revived NPC with auto gun
      if (this.scene.equipRecruitedNPCWithAutoGun) {
        this.scene.equipRecruitedNPCWithAutoGun(npc);
      }
  }
  findNearestNPC(x, y, range) {
    let closestNPC = null;
    let minDistance = range;

    this.npcs.getChildren().forEach(npc => {
        if (npc.isAlive) {
            const distance = Phaser.Math.Distance.Between(x, y, npc.x, npc.y);
            if (distance < minDistance) {
                minDistance = distance;
                closestNPC = npc;
            }
        }
    });

    return closestNPC;
  }
  
  createSpyFromEnemy(enemy) {
      const spy = new Spy(this.scene, enemy.sprite.x, enemy.sprite.y, {});
      this.spies.push(spy);

      // Optional: Set a timer for the spy to be revealed
      spy.revealTimer = this.scene.time.delayedCall(15000, () => { // 15 seconds
          spy.reveal();
          this.spies = this.spies.filter(s => s !== spy);
      });
      
       enemy.sprite.destroy(); // Remove the original enemy sprite
   }
   
   getNPCSprites() {
       return this.npcs.getChildren();
   }
  commandAttackMove(pointer) {
    const worldPoint = this.scene.cameras.main.getWorldPoint(pointer.x, pointer.y);
    // Find a recruited NPC that is not already on an attack-move.
    const commandedNPC = this.getAliveRecruitedNPCs().find(npc => !npc.attackMovePosition);
    if (commandedNPC) {
        commandedNPC.attackMovePosition = { x: worldPoint.x, y: worldPoint.y };
        commandedNPC.isGuard = false; // Attack-move overrides guarding.
        if (commandedNPC.guardMarker) {
            commandedNPC.guardMarker.destroy();
            commandedNPC.guardMarker = null;
        }
        // Only change name color for attack-move, not sprite
        commandedNPC.nameText.setStyle({ fill: '#FF6347' }); // Tomato red name for attack-move
        this.showDialogue(commandedNPC, "Engaging!");
    }
  }
   rallyAll() {
      // Check if there are any guards to rally to prevent spamming the effect
      const guardsToRally = this.getAliveRecruitedNPCs().some(npc => npc.isGuard || npc.attackMovePosition);
      if (!guardsToRally) return;
      this.getAliveRecruitedNPCs().forEach(npc => {
          if (npc.isGuard || npc.attackMovePosition) {
              npc.isGuard = false;
              npc.guardPosition = null;
              npc.attackMovePosition = null;
              if (npc.guardMarker) {
                  npc.guardMarker.destroy();
                  npc.guardMarker = null;
              }
              // Restore recruited name color
              npc.nameText.setStyle({ fill: '#00FF00' });
              this.showDialogue(npc, "Rallying!", 2000);
          }
      });
      
    this.createRallyEffect();
  }
  
  // Aggressive enemy detection with raycasting
  aggressiveEnemyDetection(npc, enemies) {
    let detectedEnemies = [];
    const maxDetectionRange = npc.detectionRange;
    
    // Limit enemy processing to reduce overwhelm - only check closest 6 enemies
    const nearbyEnemies = enemies
      .filter(enemy => enemy && enemy.sprite && enemy.sprite.active && !enemy.isCaptured && enemy.health > 0)
      .map(enemy => ({
        enemy: enemy,
        distance: Phaser.Math.Distance.Between(npc.x, npc.y, enemy.sprite.x, enemy.sprite.y)
      }))
      .sort((a, b) => a.distance - b.distance)
      .slice(0, 6); // Only check 6 closest enemies
    
    nearbyEnemies.forEach(({enemy, distance}) => {
      if (distance <= maxDetectionRange) {
        // Simplified line of sight check - assume clear if within range
        detectedEnemies.push({
          enemy: enemy,
          distance: distance,
          priority: this.calculateEnemyPriority(npc, enemy)
        });
      }
    });
    
    // Sort by priority (higher priority first)
    detectedEnemies.sort((a, b) => b.priority - a.priority);
    const targetEnemy = detectedEnemies.length > 0 ? detectedEnemies[0].enemy : null;
    
    if (targetEnemy) {
      console.log(`${npc.name} targeting enemy at priority ${detectedEnemies[0].priority}`);
    }
    
    return targetEnemy;
  }
  
  hasLineOfSight(npc, target) {
    // Simplified line of sight - just check distance without complex calculations
    const distance = Phaser.Math.Distance.Between(npc.x, npc.y, target.x, target.y);
    
    // Skip expensive visualization and point calculations for performance
    // Simply return true if target is within reasonable range
    return distance <= npc.detectionRange;
  }
  
  calculateEnemyPriority(npc, enemy) {
    let priority = 100; // Base priority
    
    // Closer enemies get higher priority
    const distance = Phaser.Math.Distance.Between(npc.x, npc.y, enemy.sprite.x, enemy.sprite.y);
    priority += (npc.detectionRange - distance) / 10;
    
    // Enemies targeting the player get highest priority
    const playerDistance = Phaser.Math.Distance.Between(enemy.sprite.x, enemy.sprite.y, this.scene.player.sprite.x, this.scene.player.sprite.y);
    if (playerDistance < enemy.detectionRange) {
      priority += 200;
    }
    
    // Powered up enemies get higher priority
    if (enemy.isPoweredUp) {
      priority += 50;
    }
    
    return priority;
  }
    createRallyEffect() {
        const player = this.scene.player;
        if (!player || !player.sprite) return;
        
        // Main expanding ring
        const rallyCircle = this.scene.add.graphics().setDepth(player.sprite.depth - 1);
        this.scene.tweens.add({
            targets: { radius: 20, alpha: 1, width: 4 },
            radius: 250,
            alpha: 0,
            width: 1,
            duration: 700,
            ease: 'Quint.easeOut',
            onUpdate: (tween) => {
                const { radius, alpha, width } = tween.targets[0];
                rallyCircle.clear()
                           .lineStyle(width, 0xFFFF00, alpha)
                           .strokeCircle(player.sprite.x, player.sprite.y, radius);
            },
            onComplete: () => {
                rallyCircle.destroy();
            }
        });
        // Add a secondary inward pulse for more impact
        const innerPulse = this.scene.add.graphics().setDepth(player.sprite.depth - 1);
        this.scene.tweens.add({
            targets: { radius: 150, alpha: 0.7 },
            radius: 10,
            alpha: 0,
            duration: 500,
            ease: 'Cubic.easeIn',
            delay: 100,
            onUpdate: (tween) => {
                const { radius, alpha } = tween.targets[0];
                innerPulse.clear()
                          .fillStyle(0xFFFF00, alpha)
                          .fillCircle(player.sprite.x, player.sprite.y, radius);
            },
            onComplete: () => {
                innerPulse.destroy();
            }
        });
    }
    
    detectNearbyEnemies(npc, enemies) {
        let closestEnemy = null;
        let minDistance = npc.detectionRange;
        
        enemies.forEach(enemy => {
            if (enemy.sprite.active && !enemy.isCaptured) {
                const distance = Phaser.Math.Distance.Between(npc.x, npc.y, enemy.sprite.x, enemy.sprite.y);
                if (distance < minDistance) {
                    minDistance = distance;
                    closestEnemy = enemy;
                }
            }
        });
        
        return closestEnemy;
    }
    
    isEnemyTargetStillValid(npc) {
        if (!npc.currentTarget || !npc.currentTarget.sprite || !npc.currentTarget.sprite.active || 
            npc.currentTarget.isCaptured || npc.currentTarget.health <= 0) {
            console.log(`${npc.name}: Current target is no longer valid`);
            return false;
        }
        
        const distance = Phaser.Math.Distance.Between(npc.x, npc.y, npc.currentTarget.sprite.x, npc.currentTarget.sprite.y);
        const isInRange = distance <= npc.detectionRange;
        
        if (!isInRange) {
            console.log(`${npc.name}: Target moved out of range (${distance} > ${npc.detectionRange})`);
        }
        
        return isInRange;
    }
    
    enemyAttackedPlayer(attackingEnemy) {
        // Make all recruited NPCs target the enemy that just attacked the player
        this.getAliveRecruitedNPCs().forEach(npc => {
            if (!npc.currentTarget) {
                npc.currentTarget = attackingEnemy;
                npc.isAlerted = true;
                
                if (npc.alertIcon) {
                    npc.alertIcon.setVisible(true);
                }
                
                // Show protective dialogue
                const protectiveMessages = [
                    "Leave them alone!",
                    "You picked the wrong target!",
                    "Not on my watch!",
                    "Covering you!",
                    "Take this!"
                ];
                const message = Phaser.Math.RND.pick(protectiveMessages);
                this.showDialogue(npc, message, 2000);
            }
        });
    }
    
    drawTargetingArrow(npc, target) {
        if (!npc.targetingArrow || !target.sprite.active) return;
        
        const arrow = npc.targetingArrow;
        arrow.clear();
        
        // Start pulsing animation if not already running
        if (!npc.arrowPulseTween) {
            npc.arrowPulseTween = this.scene.tweens.add({
                targets: arrow,
                alpha: { from: 1, to: 0.3 },
                duration: 600,
                ease: 'Sine.easeInOut',
                yoyo: true,
                repeat: -1 // Infinite repeat
            });
        }
        
        // Calculate angle from NPC to target
        const angle = Phaser.Math.Angle.Between(npc.x, npc.y, target.sprite.x, target.sprite.y);
        
        // Position arrow slightly ahead of NPC in direction of target
        const arrowDistance = 60; // Distance from NPC center
        const arrowX = npc.x + Math.cos(angle) * arrowDistance;
        const arrowY = npc.y + Math.sin(angle) * arrowDistance;
        
        // Arrow properties
        const arrowLength = 25;
        const arrowWidth = 15;
        
        // Calculate arrow tip position
        const tipX = arrowX + Math.cos(angle) * arrowLength;
        const tipY = arrowY + Math.sin(angle) * arrowLength;
        
        // Calculate arrow base corners
        const baseAngle1 = angle + Math.PI - 0.5;
        const baseAngle2 = angle + Math.PI + 0.5;
        const base1X = arrowX + Math.cos(baseAngle1) * arrowWidth;
        const base1Y = arrowY + Math.sin(baseAngle1) * arrowWidth;
        const base2X = arrowX + Math.cos(baseAngle2) * arrowWidth;
        const base2Y = arrowY + Math.sin(baseAngle2) * arrowWidth;
        
        // Set arrow color based on weapon type
        let arrowColor, outlineColor;
        switch (npc.weaponType) {
            case 'rifle':
                arrowColor = 0xFF8800; // Orange
                outlineColor = 0xFF4400;
                break;
            case 'shotgun':
                arrowColor = 0xFFDD00; // Yellow
                outlineColor = 0xFFAA00;
                break;
            case 'pistol':
            default:
                arrowColor = 0xFF4444; // Red
                outlineColor = 0xFF0000;
                break;
        }
        
        // Draw arrow with weapon-specific colors
        arrow.fillStyle(arrowColor, 0.8); // Color with transparency
        arrow.lineStyle(2, outlineColor, 1); // Color outline
        
        // Create arrow shape
        arrow.beginPath();
        arrow.moveTo(tipX, tipY); // Arrow tip
        arrow.lineTo(base1X, base1Y); // Left base
        arrow.lineTo(base2X, base2Y); // Right base
        arrow.closePath();
        arrow.fillPath();
        arrow.strokePath();
        
        // Add a small circle at the base for better visibility
        arrow.fillStyle(outlineColor, 1);
        arrow.fillCircle(arrowX, arrowY, 3);
    }
    
    showShootingIndicator(npc) {
        if (npc.shootingIndicator) {
            // Set weapon-specific colors
            let indicatorColor, strokeColor;
            switch (npc.weaponType) {
                case 'shotgun':
                    indicatorColor = '#FFD700'; // Gold
                    strokeColor = '#FF8C00'; // Dark orange
                    break;
                case 'rifle':
                    indicatorColor = '#FF4500'; // Orange red
                    strokeColor = '#8B0000'; // Dark red
                    break;
                case 'pistol':
                default:
                    indicatorColor = '#00FF00'; // Bright green
                    strokeColor = '#006400'; // Dark green
                    break;
            }
            
            // Update the indicator style and make visible
            npc.shootingIndicator.setStyle({
                fontFamily: '"Press Start 2P", sans-serif',
                fontSize: '12px',
                fill: indicatorColor,
                stroke: strokeColor,
                strokeThickness: 2,
                align: 'center'
            }).setVisible(true);
            
            // Create muzzle flash effect for enhanced visual feedback
            this.createShootingMuzzleFlash(npc);
            
            // Create pulsing animation
            const pulseTween = this.scene.tweens.add({
                targets: npc.shootingIndicator,
                scaleX: { from: 1, to: 1.3 },
                scaleY: { from: 1, to: 1.3 },
                alpha: { from: 1, to: 0.7 },
                duration: 150,
                yoyo: true,
                repeat: 1,
                ease: 'Sine.easeInOut'
            });
            
            // Hide the indicator after animation completes
            this.scene.time.delayedCall(600, () => {
                if (npc.shootingIndicator) {
                    npc.shootingIndicator.setVisible(false);
                    // Reset scale in case tween was interrupted
                    npc.shootingIndicator.setScale(1);
                    npc.shootingIndicator.setAlpha(1);
                }
            });
        }
    }
    
    createShootingMuzzleFlash(npc) {
        // Create a brief muzzle flash burst around the NPC
        const particles = this.scene.add.particles(npc.x, npc.y, 'croppedBullet', {
            speed: { min: 80, max: 150 },
            angle: { min: 0, max: 360 }, // 360-degree burst
            scale: { start: 0.03, end: 0 },
            tint: this.getMuzzleFlashColor(npc.weaponType),
            blendMode: 'ADD',
            lifespan: 200,
            quantity: 8, // Moderate particle count for nice effect
            emitting: true
        });
        
        // Destroy the effect after a short duration
        this.scene.time.delayedCall(300, () => {
            if (particles) {
                particles.destroy();
            }
        });
    }
    
    getMuzzleFlashColor(weaponType) {
        switch (weaponType) {
            case 'shotgun':
                return [0xFFD700, 0xFFFF00, 0xFFFFFF]; // Gold to white
            case 'rifle':
                return [0xFF4500, 0xFF8C00, 0xFFFFFF]; // Orange-red to white
            case 'pistol':
            default:
                return [0x00FF00, 0x90EE90, 0xFFFFFF]; // Green to white
        }
    }
}