

import Phaser from 'phaser';

export class InventoryUI {
  constructor(scene, playerInventory) {
    this.scene = scene;
    this.playerInventory = playerInventory;
    this.isVisible = false;
    
    // Main container for the inventory UI
    this.container = this.scene.add.container(0, 0).setDepth(3000).setScrollFactor(0);
    this.container.setVisible(false);
    
    this.createPanel();
    this.createSlots();
    this.createTitle();
    this.itemIcons = this.scene.add.container(0, 0); // Container for icons that will be updated
    this.container.add(this.itemIcons);
  }

  createPanel() {
    const centerX = this.scene.scale.width / 2;
    const centerY = this.scene.scale.height / 2;
    const width = 400;
    const height = 300;

    const panel = this.scene.add.graphics();
    panel.fillStyle(0x000000, 0.8);
    panel.fillRoundedRect(-width / 2, -height / 2, width, height, 10);
    panel.lineStyle(2, 0xFFE4B5, 1); // Moccasin border color, matches player tint
    panel.strokeRoundedRect(-width / 2, -height / 2, width, height, 10);

    this.container.add(panel);
    this.container.setPosition(centerX, centerY);
  }
  
  createTitle() {
      const title = this.scene.add.text(0, -130, 'INVENTORY', {
          fontSize: '28px',
          fill: '#FFD700',
          fontStyle: 'bold',
          stroke: '#000000',
          strokeThickness: 5
      }).setOrigin(0.5);
      this.container.add(title);
  }

  createSlots() {
    const rows = 3;
    const cols = 4;
    const slotSize = 64;
    const slotSpacing = 15;
    const gridWidth = cols * (slotSize + slotSpacing) - slotSpacing;
    const gridHeight = rows * (slotSize + slotSpacing) - slotSpacing;
    const startX = -gridWidth / 2;
    const startY = -gridHeight / 2 + 20; // Move grid down a bit for title

    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < cols; col++) {
        const x = startX + col * (slotSize + slotSpacing);
        const y = startY + row * (slotSize + slotSpacing);
        
        const slotBg = this.scene.add.graphics();
        slotBg.fillStyle(0x333333, 0.7);
        slotBg.fillRect(x, y, slotSize, slotSize);
        slotBg.lineStyle(1, 0xFFE4B5, 0.5);
        slotBg.strokeRect(x, y, slotSize, slotSize);
        
        this.container.add(slotBg);
      }
    }
  }
  updateItems() {
    this.itemIcons.removeAll(true); // Clear old icons before drawing new ones
    const slotSize = 64;
    const slotSpacing = 15;
    const startX = -((4 * (slotSize + slotSpacing) - slotSpacing) / 2);
    const startY = -((3 * (slotSize + slotSpacing) - slotSpacing) / 2) + 20;
    const items = [
        { key: 'healthPack', count: this.playerInventory.healthPacks, tint: 0x00ff00 }
        // Add other items here in the future
    ];
    items.forEach((item, index) => {
        if (item.count > 0) {
            const col = index % 4;
            const row = Math.floor(index / 4);
            const x = startX + col * (slotSize + slotSpacing) + slotSize / 2;
            const y = startY + row * (slotSize + slotSpacing) + slotSize / 2;
            const icon = this.scene.add.sprite(x, y, item.key).setScale(0.1).setTint(item.tint);
            const text = this.scene.add.text(x + 20, y + 20, item.count.toString(), {
                fontSize: '16px', fill: '#fff', stroke: '#000', strokeThickness: 3
            }).setOrigin(0.5);
            
            this.itemIcons.add([icon, text]);
        }
    });
  }
  show() {
    this.isVisible = true;
    this.container.setVisible(true);
    this.updateItems();
  }

  hide() {
    this.isVisible = false;
    this.container.setVisible(false);
  }

  toggle() {
    if (this.isVisible) {
      this.hide();
    } else {
      this.show();
    }
  }
}

