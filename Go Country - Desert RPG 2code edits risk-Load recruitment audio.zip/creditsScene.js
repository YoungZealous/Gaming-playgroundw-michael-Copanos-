

import Phaser from 'phaser';

export class CreditsScene extends Phaser.Scene {
  constructor() {
    super({ key: 'CreditsScene' });
  }

  create() {
    const centerX = this.scale.width / 2;
    const centerY = this.scale.height / 2;

    // Background
    this.add.graphics()
      .fillStyle(0x000000, 0.8)
      .fillRect(0, 0, this.scale.width, this.scale.height);

    // Title
    this.add.text(centerX, 80, 'Credits', {
      fontSize: '48px',
      fill: '#FFD700',
      fontFamily: '"Georgia", serif',
      stroke: '#000000',
      strokeThickness: 6
    }).setOrigin(0.5);

    // Credits Text
    const creditsTextContent = [
      'Game Development & Design:',
      'Rosie (Rosebud AI)',
      '',
      'Music:',
      '"Go Country" by Young Zealous',
      '',
      'Assets:',
      'Sprites and Icons from various sources.',
      'Phaser 3 Framework',
      '',
      'Special Thanks To:',
      'You, for playing!'
    ];

    this.add.text(centerX, centerY, creditsTextContent, {
      fontSize: '24px',
      fill: '#FFFFFF',
      align: 'center',
      lineSpacing: 10
    }).setOrigin(0.5);


    // Back Button
    const backButton = this.add.text(centerX, this.scale.height - 100, 'Back to Main Menu', {
      fontSize: '28px',
      fill: '#FFFFFF',
      fontFamily: '"Georgia", serif',
      backgroundColor: '#4E342E',
      padding: { x: 20, y: 10 }
    }).setOrigin(0.5).setInteractive({ useHandCursor: true });

    backButton.on('pointerover', () => backButton.setBackgroundColor('#6D4C41'));
    backButton.on('pointerout', () => backButton.setBackgroundColor('#4E342E'));
    backButton.on('pointerdown', () => {
      this.scene.start('MainMenuScene');
    });
  }
}

