

import Phaser from 'phaser';

export default class GameScene2 extends Phaser.Scene {
    constructor() {
        super({ key: 'GameScene2' });
    }

    preload() {
        // Assets for this scene will be preloaded here
    }

    create() {
        // Initial setup for the scene
        this.add.text(this.cameras.main.width / 2, this.cameras.main.height / 2, 'Welcome to GameScene2!', {
            fontSize: '32px',
            fill: '#ffffff',
            align: 'center'
        }).setOrigin(0.5);

        console.log('GameScene2 has been created!');
    }

    update(time, delta) {
        // This is the game loop for scene-specific updates
    }
}

