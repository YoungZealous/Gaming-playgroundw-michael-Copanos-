

import Phaser from 'phaser';

export class AutoGunSystem {
  constructor(scene, npcSystem, enemyManager) {
    this.scene = scene;
    this.npcSystem = npcSystem;
    this.enemyManager = enemyManager;
    
    // Auto gun configuration - Enhanced for accuracy
    this.autoGunRange = 450; // Extended range with improved accuracy
    this.autoGunFireRate = 550; // Slower, more controlled fire rate
    this.autoGunDamage = 10; // Reduced damage for balanced gameplay (approx. 10 shots to kill)
    
    // Accuracy enhancement systems
    this.recoilCompensation = 0.85; // Counter-weight recoil reduction (85% compensation)
    this.accuracyModifier = 0.95; // High accuracy modifier (95% hit chance at optimal range)
    this.muzzleVelocity = 820; // Optimized muzzle velocity in m/s equivalent
    this.stabilityFactor = 0.9; // Stability enhancement (90% stability)
    
    // Tracking for each NPC's auto gun
    this.npcAutoGuns = new Map(); // NPC -> auto gun data
    
    // Visual effects
    this.autoGunMarkers = this.scene.add.group();
    this.autoGunBullets = this.scene.physics.add.group({
      defaultKey: 'croppedBullet',
      maxSize: 60, // More bullets for rapid fire
      runChildUpdate: true,
    });
    
    this.setupCollisions();
  }
  
  // Equip an auto gun to a recruited NPC
  equipAutoGun(npc) {
    if (!npc.isRecruited || this.npcAutoGuns.has(npc)) return;
    
    const autoGunData = {
      npc: npc,
      lastShot: 0,
      currentTarget: null,
      isActive: true,
      killCount: 0, // Track kills for the NPC
      recoilAccumulation: 0, // Track recoil buildup
      consecutiveShots: 0, // Track burst firing for accuracy
      lastTargetPosition: { x: 0, y: 0 }, // For improved prediction
      stabilityBonus: 0 // Stability improvements over time
    };
    
    this.npcAutoGuns.set(npc, autoGunData);
    
    // Visual indicator that NPC has auto gun
    const marker = this.autoGunMarkers.create(npc.x, npc.y, 'bulletTracer');
    marker.setScale(0.02);
    marker.setTint(0x00FFFF); // Cyan color for auto gun marker
    marker.setDepth(npc.depth + 1);
    marker.setAlpha(0.7);
    autoGunData.marker = marker;
    
    // Create pulsing effect for the marker
    this.scene.tweens.add({
      targets: marker,
      alpha: { from: 0.7, to: 0.3 },
      duration: 1000,
      yoyo: true,
      repeat: -1,
      ease: 'Sine.easeInOut'
    });
    
    console.log(`${npc.name} equipped with auto gun system`);
  }
  
  // Remove auto gun from NPC
  unequipAutoGun(npc) {
    const autoGunData = this.npcAutoGuns.get(npc);
    if (!autoGunData) return;
    
    if (autoGunData.marker) {
      autoGunData.marker.destroy();
    }
    
    this.npcAutoGuns.delete(npc);
    console.log(`${npc.name} auto gun system removed`);
  }
  
  setupCollisions() {
    this.scene.physics.add.overlap(
      this.autoGunBullets,
      this.enemyManager.enemyGroup,
      (bullet, enemySprite) => {
        const enemy = this.enemyManager.findEnemyBySprite(enemySprite);
        if (enemy && bullet.active && enemy.health > 0 && !enemy.isCaptured) {
          this.handleAutoGunHit(bullet, enemy);
        }
      }
    );
  }
  
  handleAutoGunHit(bullet, enemy) {
    if (!bullet.sourceNPC || !bullet.active) return;
    
    // Create impact effect at hit location
    this.createAutoGunImpact(bullet.x, bullet.y);
    
    // Create enemy hit flash effect
    this.createEnemyHitFlash(enemy);
    
    // Create floating damage number
    this.createFloatingDamageNumber(bullet.x, bullet.y, this.autoGunDamage);
    
    // Damage the enemy
    this.enemyManager.takeDirectDamage(enemy, this.autoGunDamage);
    
    // If enemy dies, credit the NPC
    if (enemy.health <= 0) {
      const autoGunData = this.npcAutoGuns.get(bullet.sourceNPC);
      if (autoGunData) {
        autoGunData.killCount++;
        this.notifyNPCOfKill(bullet.sourceNPC, enemy);
      }
    }
    
    // Clean up bullet and trail
    if (bullet.trailEffect) {
      bullet.trailEffect.destroy();
    }
    bullet.setActive(false).setVisible(false);
  }
  
  notifyNPCOfKill(npc, enemy) {
    // Let the NPC know their auto gun got a kill
    const killMessages = [
      "Auto gun got one!",
      "Target eliminated!",
      "System working perfectly!",
      "Another one down!",
      "Auto targeting successful!"
    ];
    
    const message = Phaser.Math.RND.pick(killMessages);
    this.npcSystem.showDialogue(npc, message, 2000);
    
    // Brief visual effect on the NPC
    npc.setTint(0x00FFFF);
    this.scene.time.delayedCall(200, () => {
      if (npc.active) npc.setTint(0xADD8E6); // Back to normal NPC tint
    });
  }
  
  update() {
    const currentTime = this.scene.time.now;
    
    this.npcAutoGuns.forEach((autoGunData, npc) => {
      if (!npc.isAlive || !npc.isRecruited) {
        this.unequipAutoGun(npc);
        return;
      }
      
      // Update marker position
      if (autoGunData.marker) {
        autoGunData.marker.setPosition(npc.x + 15, npc.y - 15);
      }
      
      // Find closest enemy in range
      const target = this.findClosestEnemyInRange(npc);
      autoGunData.currentTarget = target;
      
      // Auto fire at target
      // Slower firing logic: check if enough time has passed since the last shot
      if (target && currentTime > autoGunData.lastShot + this.autoGunFireRate) {
        this.fireAutoGun(autoGunData, target);
        autoGunData.lastShot = currentTime;
      }
    });
  }
  
  findClosestEnemyInRange(npc) {
    let attackingEnemies = [];
    let otherEnemies = [];
    
    // First, categorize enemies into "attacking" and "others"
    this.enemyManager.enemies.forEach(enemy => {
      if (enemy.sprite.active && !enemy.isCaptured && enemy.health > 0) {
        const distance = Phaser.Math.Distance.Between(npc.x, npc.y, enemy.sprite.x, enemy.sprite.y);
        
        if (distance < this.autoGunRange) {
          // An enemy is considered a high-priority threat if they are prepping an attack.
          if (enemy.isPreppingAttack) {
            attackingEnemies.push({ enemy, distance });
          } else {
            otherEnemies.push({ enemy, distance });
          }
        }
      }
    });
    
    // Prioritize the closest attacking enemy
    if (attackingEnemies.length > 0) {
      attackingEnemies.sort((a, b) => a.distance - b.distance);
      return attackingEnemies[0].enemy;
    }
    
    // If no one is attacking, target the closest other enemy
    if (otherEnemies.length > 0) {
      otherEnemies.sort((a, b) => a.distance - b.distance);
      return otherEnemies[0].enemy;
    }
    
    return null; // No valid targets in range
  }
  
  fireAutoGun(autoGunData, target) {
    const npc = autoGunData.npc;
    const bullet = this.autoGunBullets.get(null, null, 'croppedBullet');
    
    if (bullet) {
      bullet.setActive(true).setVisible(true);
      bullet.setPosition(npc.x, npc.y);
      
      // Enhanced targeting with prediction and recoil compensation
      const predictedPosition = this.calculatePredictedTargetPosition(target, autoGunData);
      let baseAngle = Phaser.Math.Angle.Between(
        npc.x, npc.y,
        predictedPosition.x, predictedPosition.y
      );
      
      // Apply recoil compensation and stability enhancements
      const recoilOffset = this.calculateRecoilOffset(autoGunData);
      const finalAngle = baseAngle + recoilOffset;
      
      bullet.setRotation(finalAngle);
      bullet.setScale(0.08, 0.08); // Optimized size for accuracy
      bullet.setTint(0xFF0000); // Red bullets like player
      bullet.setDepth(50);
      
      // Enhanced physics body setup for precision hits
      bullet.body.reset(bullet.x, bullet.y);
      bullet.body.setSize(10, 10, true); // Precise hitbox for accuracy
      bullet.body.isCircle = true;
      bullet.sourceNPC = npc; // Track which NPC fired this
      
      // Optimized muzzle velocity for better accuracy
      const enhancedSpeed = this.muzzleVelocity * 1.5; // Convert to game units
      bullet.body.setVelocity(
        Math.cos(finalAngle) * enhancedSpeed,
        Math.sin(finalAngle) * enhancedSpeed
      );
      
      // Update recoil and accuracy tracking
      this.updateRecoilSystem(autoGunData);
      
      // Create enhanced visual effects
      this.createBulletTrail(bullet, finalAngle);
      this.createAutoGunMuzzleFlash(npc, finalAngle);
      
      // Auto destroy bullet after 1.8 seconds (faster cleanup)
      this.scene.time.delayedCall(1800, () => {
        if (bullet.active) {
          bullet.setActive(false).setVisible(false);
          if (bullet.trailEffect) {
            bullet.trailEffect.destroy();
          }
        }
      });
      
      // Enhanced sound effect with recoil compensation audio
      const distance = Phaser.Math.Distance.Between(
        npc.x, npc.y,
        this.scene.player.sprite.x, this.scene.player.sprite.y
      );
      const volume = Math.max(0.1, 0.45 * (1 - distance / 800));
      const recoilDetune = 150 - (autoGunData.recoilAccumulation * 20); // Sound changes with recoil
      this.scene.sound.play('gunshot', { 
        volume: volume, 
        detune: recoilDetune
      });
    }
  }
  
  calculatePredictedTargetPosition(target, autoGunData) {
    const enemy = target;
    const currentPos = { x: enemy.sprite.x, y: enemy.sprite.y };
    
    // Calculate enemy velocity if it has physics body
    let enemyVelocity = { x: 0, y: 0 };
    if (enemy.sprite.body && enemy.sprite.body.velocity) {
      enemyVelocity.x = enemy.sprite.body.velocity.x;
      enemyVelocity.y = enemy.sprite.body.velocity.y;
    }
    
    // Calculate time to target for bullet travel
    const distance = Phaser.Math.Distance.Between(
      autoGunData.npc.x, autoGunData.npc.y,
      currentPos.x, currentPos.y
    );
    const bulletSpeed = this.muzzleVelocity * 1.5;
    const timeToTarget = distance / bulletSpeed;
    
    // Predict where enemy will be when bullet arrives
    const predictedX = currentPos.x + (enemyVelocity.x * timeToTarget * 0.8); // 80% prediction accuracy
    const predictedY = currentPos.y + (enemyVelocity.y * timeToTarget * 0.8);
    
    // Store for next shot comparison
    autoGunData.lastTargetPosition = { x: predictedX, y: predictedY };
    
    return { x: predictedX, y: predictedY };
  }
  
  calculateRecoilOffset(autoGunData) {
    // Counter-weight system reduces recoil by 85%
    const baseRecoil = autoGunData.recoilAccumulation * 0.02;
    const compensatedRecoil = baseRecoil * (1 - this.recoilCompensation);
    
    // Apply stability factor for further reduction
    const stabilizedRecoil = compensatedRecoil * (1 - autoGunData.stabilityBonus * 0.1);
    
    // Random spread pattern reduced by accuracy systems
    const spreadReduction = this.accuracyModifier;
    const finalSpread = Phaser.Math.FloatBetween(-0.05, 0.05) * (1 - spreadReduction);
    
    return stabilizedRecoil + finalSpread;
  }
  
  updateRecoilSystem(autoGunData) {
    // Increase recoil accumulation with each shot
    autoGunData.recoilAccumulation = Math.min(autoGunData.recoilAccumulation + 1, 10);
    autoGunData.consecutiveShots++;
    
    // Improve stability bonus over time (learning system)
    if (autoGunData.consecutiveShots > 3) {
      autoGunData.stabilityBonus = Math.min(autoGunData.stabilityBonus + 0.1, 5);
    }
    
    // Gradual recoil reduction over time (counter-weight system recovery)
    this.scene.time.delayedCall(500, () => {
      autoGunData.recoilAccumulation = Math.max(autoGunData.recoilAccumulation - 2, 0);
    });
  }
  
  createEnhancedMuzzleFlash(x, y, angle, autoGunData) {
    // Reduced muzzle flash due to flash suppressor and counter-weight
    const flashIntensity = Math.max(0.3, 1 - (autoGunData.recoilAccumulation * 0.05));
    
    const particles = this.scene.add.particles(x, y, 'croppedBullet', {
      speed: { min: 60 * flashIntensity, max: 180 * flashIntensity },
      angle: { 
        min: Phaser.Math.RadToDeg(angle) - 15, 
        max: Phaser.Math.RadToDeg(angle) + 15 
      },
      scale: { start: 0.04 * flashIntensity, end: 0 },
      tint: [0xFF0000, 0xFF6666, 0xFFFFFF], // Controlled flash colors
      blendMode: 'ADD',
      lifespan: 120,
      quantity: Math.floor(6 * flashIntensity),
      emitting: true
    });
    
    this.scene.time.delayedCall(150, () => {
      if (particles) particles.destroy();
    });
  }
  
  createAutoGunMuzzleFlash(npc, angle) {
    const muzzleOffset = 20; // Distance from NPC center
    const muzzleX = npc.x + muzzleOffset * Math.cos(angle);
    const muzzleY = npc.y + muzzleOffset * Math.sin(angle);
    const flash = this.scene.add.image(muzzleX, muzzleY, 'bulletTracer');
    flash.setRotation(angle);
    flash.setScale(0.05, 0.02); // Elongated flash effect
    flash.setTint(0xFFFF00); // Bright yellow flash
    flash.setBlendMode('ADD');
    flash.setDepth(npc.depth + 1);
    this.scene.tweens.add({
        targets: flash,
        alpha: { from: 1, to: 0 },
        scaleX: { from: 0.05, to: 0.08 },
        scaleY: { from: 0.02, to: 0 },
        duration: 100,
        onComplete: () => {
            flash.destroy();
        }
    });
  }
  
  createAutoGunImpact(x, y) {
    const particles = this.scene.add.particles(x, y, 'croppedBullet', {
      speed: { min: 50, max: 150 },
      angle: { min: 0, max: 360 },
      scale: { start: 0.06, end: 0 },
      tint: [0xFF0000, 0xFF4444], // Red impact like player
      blendMode: 'ADD',
      lifespan: 300,
      quantity: 12,
      emitting: true
    });
    
    this.scene.time.delayedCall(300, () => {
      if (particles) particles.destroy();
    });
  }
  
  createEnemyHitFlash(enemy) {
    if (!enemy || !enemy.sprite.active) return;
    
    // Store original tint
    const originalTint = enemy.sprite.tint;
    
    // Flash white then red
    enemy.sprite.setTint(0xFFFFFF);
    
    this.scene.time.delayedCall(50, () => {
      if (enemy.sprite.active) {
        enemy.sprite.setTint(0xFF0000);
        
        this.scene.time.delayedCall(100, () => {
          if (enemy.sprite.active) {
            enemy.sprite.setTint(originalTint);
          }
        });
      }
    });
  }
  
  createFloatingDamageNumber(x, y, damage) {
    const damageText = this.scene.add.text(x, y, `-${damage}`, {
      fontSize: '20px',
      fill: '#FF4444',
      fontWeight: 'bold',
      stroke: '#000000',
      strokeThickness: 3
    });
    
    damageText.setOrigin(0.5, 0.5);
    damageText.setDepth(100);
    
    // Animate the damage number floating up and fading
    this.scene.tweens.add({
      targets: damageText,
      y: y - 60,
      alpha: 0,
      scale: 1.2,
      duration: 800,
      ease: 'Power2',
      onComplete: () => {
        damageText.destroy();
      }
    });
  }
  
  createBulletTrail(bullet, angle) {
    // Create a particle trail that follows the bullet
    const trail = this.scene.add.particles(bullet.x, bullet.y, 'croppedBullet', {
      speed: 0,
      scale: { start: 0.03, end: 0 },
      tint: [0xFF0000, 0xFF6666, 0xFF9999], // Red gradient trail
      blendMode: 'ADD',
      lifespan: 200,
      frequency: 20,
      quantity: 1,
      emitting: true,
      follow: bullet
    });
    
    // Store reference for cleanup
    bullet.trailEffect = trail;
    
    // Clean up trail when bullet is destroyed
    this.scene.time.delayedCall(2000, () => {
      if (trail) {
        trail.destroy();
      }
    });
  }
  
  createEnemyDeathBurst(x, y) {
    // Create multiple particle effects for a spectacular death burst
    
    // Main explosion burst - red particles
    const mainBurst = this.scene.add.particles(x, y, 'croppedBullet', {
      speed: { min: 150, max: 400 },
      angle: { min: 0, max: 360 },
      scale: { start: 0.8, end: 0 },
      tint: [0xFF0000, 0xFF4444, 0xFFAAAA],
      alpha: { start: 1, end: 0 },
      lifespan: 600,
      quantity: 25,
      emitting: false
    });
    
    // Secondary burst - yellow/orange sparks
    const sparkBurst = this.scene.add.particles(x, y, 'croppedBullet', {
      speed: { min: 200, max: 500 },
      angle: { min: 0, max: 360 },
      scale: { start: 0.4, end: 0 },
      tint: [0xFFFF00, 0xFFA500, 0xFFFFFF],
      alpha: { start: 1, end: 0 },
      lifespan: 800,
      quantity: 15,
      emitting: false
    });
    
    // Create expanding shockwave effect
    const shockwave = this.scene.add.circle(x, y, 5, 0xFF0000, 0.6);
    shockwave.setDepth(45);
    
    // Emit the particle bursts
    mainBurst.explode();
    
    // Delayed spark burst for layered effect
    this.scene.time.delayedCall(100, () => {
      sparkBurst.explode();
    });
    
    // Animate shockwave expansion
    this.scene.tweens.add({
      targets: shockwave,
      radius: 80,
      alpha: 0,
      duration: 500,
      ease: 'Power2',
      onComplete: () => {
        shockwave.destroy();
      }
    });
    
    // Clean up particle systems
    this.scene.time.delayedCall(1000, () => {
      if (mainBurst) mainBurst.destroy();
      if (sparkBurst) sparkBurst.destroy();
    });
  }
  
  createScreenShake(intensity = 3, duration = 150) {
    // Only shake if the camera isn't already shaking
    if (this.scene.cameras.main.shakeEffect && this.scene.cameras.main.shakeEffect.isRunning) {
      return;
    }
    
    // Create screen shake effect
    this.scene.cameras.main.shake(duration, intensity);
  }
  
  // Get stats for UI display
  getAutoGunStats(npc) {
    const autoGunData = this.npcAutoGuns.get(npc);
    return autoGunData ? {
      hasAutoGun: true,
      killCount: autoGunData.killCount,
      currentTarget: autoGunData.currentTarget ? autoGunData.currentTarget.sprite : null
    } : { hasAutoGun: false, killCount: 0, currentTarget: null };
  }
}

