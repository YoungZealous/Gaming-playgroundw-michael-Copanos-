

import Phaser from 'phaser';

export class UIManager {
  constructor(scene) {
    this.scene = scene;
    this.chatBox = null;
    this.chatText = null;
    this.chatHistory = [];
    this.maxChatLines = 5; // Increased line count
    this.minimapGraphics = null;
    this.playerMinimapIcon = null;
    this.isMinimapLarge = false;
    this.minimapElements = {}; // To store minimap related objects
    this.allyTrappedMessage = null; // For the new ally trapped message
    this.createUI();
    this.createControlsUI(); // Create the new controls UI
    this.createChatBox();
  }
  
  createUI() {
    this.titleText = this.scene.add.text(this.scene.scale.width / 2, 40, 'GO COUNTRY', {
      fontFamily: '"Arial Black", Gadget, sans-serif',
      fontSize: '32px',
      color: '#FFD700',
      fontStyle: 'bold'
    });
    this.titleText.setStroke('#4E2E0A', 8);
    this.titleText.setShadow(2, 2, '#333333', 2, true, true);
    this.titleText.setOrigin(0.5);
    this.titleText.setScrollFactor(0);
    this.titleText.setAlpha(0.9);
    this.titleText.setDepth(5000); // Ensure it's on top of all other UI
    
    const gradient = this.titleText.context.createLinearGradient(0, 0, 0, this.titleText.height);
    gradient.addColorStop(0, '#FFD700'); // Gold
    gradient.addColorStop(0.5, '#F0E68C'); // Khaki
    gradient.addColorStop(1, '#B8860B'); // DarkGoldenRod
    this.titleText.setFill(gradient);
    
    // Add bobbing animation to the title
    this.scene.tweens.add({
        targets: this.titleText,
        y: this.titleText.y + 10,
        duration: 2000,
        ease: 'Sine.easeInOut',
        yoyo: true,
        repeat: -1
    });
    
    // --- Minimap UI ---
    const minimapSize = 200;
    const minimapX = this.scene.scale.width - minimapSize - 20;
    const minimapY = 20;
    // The border has been removed for a cleaner look.
  }
  
  createControlsUI() {
    const controlsTextContent = [
      '[WASD] Move',
      '[L-Click] Shoot',
      '[R-Click] Throw Lasso',
      '[F] Equip/Unequip Lasso',
      '[M] Molotov',
      '[R] Recruit/Dismiss',
      '[6] Command Guard',
      '[1] Rally Squad',
      '[E] Revive NPC',
      '[7] Release Captured',
      '[8] Deploy Spy',
      '[U] Mount/Dismount',
    ];
    const controlsText = this.scene.add.text(
      10,
      this.scene.scale.height - 10,
      controlsTextContent,
      {
        fontFamily: '"Press Start 2P", sans-serif',
        fontSize: '15px',
        fill: '#FFFFFF',
        backgroundColor: 'rgba(0,0,0,0.5)',
        padding: { x: 8, y: 6 },
        lineSpacing: 8,
      }
    ).setOrigin(0, 1).setScrollFactor(0).setDepth(2000);
  }
  createChatBox() {
    const instructionBoxHeight = 0; // Old instruction text removed
    const boxHeight = 120;
    const padding = 10;
    const yPos = this.scene.scale.height - boxHeight - instructionBoxHeight - padding - 150; // Adjust position to not overlap new controls UI
    // Create a styled graphics object for the background
    this.chatBox = this.scene.add.graphics();
    this.chatBox.lineStyle(2, 0x8B4513, 1); // Dark wood border
    this.chatBox.fillStyle(0x000000, 0.6); // Slightly more transparent
    this.chatBox.fillRoundedRect(padding, yPos, this.scene.scale.width - padding * 2, boxHeight, 10);
    this.chatBox.strokeRoundedRect(padding, yPos, this.scene.scale.width - padding * 2, boxHeight, 10);
    this.chatBox.setScrollFactor(0);
    this.chatBox.setDepth(2000); // Ensure it's above other UI
    // Create text object for the chat log
    this.chatText = this.scene.add.text(
      padding * 2,
      yPos + (padding / 2),
      '', {
        fontSize: '16px',
        fill: '#E0E0E0',
        fontStyle: 'italic',
        wordWrap: {
          width: this.scene.scale.width - padding * 4
        },
        lineSpacing: 6
      }
    );
    this.chatText.setScrollFactor(0);
    this.chatText.setDepth(2001);
    this.hideChatBox(); // Initially hidden
  }
  showChatBox() {
    this.chatBox.setVisible(true);
    this.chatText.setVisible(true);
  }
  hideChatBox() {
    this.chatBox.setVisible(false);
    this.chatText.setVisible(false);
    this.chatHistory = [];
    this.chatText.setText('');
  }
  updateChatLog({ speaker, text, isFinal }) {
    if (!this.chatBox.visible) this.showChatBox();
    const lastMessage = this.chatHistory[this.chatHistory.length - 1];
    if (!isFinal) {
        // Handle interim player speech or NPC "thinking..." message
        if (lastMessage && lastMessage.speaker === speaker && !lastMessage.isFinal) {
            // Update the existing interim message
            lastMessage.text = text;
        } else {
            // Add a new interim message
            this.chatHistory.push({ speaker, text, isFinal: false });
        }
    } else {
        // Handle final messages
        if (lastMessage && lastMessage.speaker === speaker && !lastMessage.isFinal) {
            // The previous message was an interim one from the same speaker, so finalize it.
            lastMessage.text = text;
            lastMessage.isFinal = true;
        } else {
            // Add a new final message.
            this.chatHistory.push({ speaker, text, isFinal: true });
        }
    }
    // Keep the log from getting too long
    while (this.chatHistory.length > this.maxChatLines) {
        this.chatHistory.shift();
    }
    this.renderChatLog();
  }
  renderChatLog() {
    const styledLog = this.chatHistory.map(msg => {
        const speakerColor = msg.speaker === 'You' ? '#87CEFA' : '#FFD700'; // LightSkyBlue for Player, Gold for NPC
        const prefix = `${msg.speaker}:`;
        return { text: `${prefix} ${msg.text}`, fill: speakerColor };
    });
    this.chatText.setText(styledLog.map(s => s.text).join('\n'));
    // TODO: Implement per-line coloring with multiple text objects for a more robust solution.
    // The current approach of trying to style a single text object's lines is not supported directly.
    this.chatText.setStyle({ fill: '#E0E0E0' }); // Ensure a consistent default color.
    this.chatText.setLineSpacing(6);
  }
  
  update(minimap) {
    // The minimap is now a camera, so it updates automatically.
    // This function can be expanded later if needed.
  }
  toggleMinimapSize() {
      this.isMinimapLarge = !this.isMinimapLarge;
      const minimap = this.scene.minimap;
      const { width, height } = this.scene.scale;
      
      const smallSize = 200;
      const largeSize = Math.min(width, height) * 0.8;
      
      const newSize = this.isMinimapLarge ? largeSize : smallSize;
      const newX = this.isMinimapLarge ? (width - newSize) / 2 : width - smallSize - 20;
      const newY = this.isMinimapLarge ? (height - newSize) / 2 : 20;
      const newZoom = this.isMinimapLarge ? 0.4 : 0.15;
      
      minimap.setPosition(newX, newY);
      minimap.setSize(newSize, newSize);
      minimap.setZoom(newZoom);
      
      // The border element is removed, so we no longer need to update it.
  }
  displayAllyTrappedMessage(npcName) {
    if (this.allyTrappedMessage && this.scene.tweens.isTweening(this.allyTrappedMessage)) {
        // If a message is already showing, don't show another one.
        return;
    }
    const message = `An ally has been trapped!`;
    if (!this.allyTrappedMessage) {
        this.allyTrappedMessage = this.scene.add.text(
            this.scene.scale.width / 2,
            100,
            message, {
                fontFamily: '"Press Start 2P", sans-serif',
                fontSize: '24px',
                fill: '#ff0000', // Red color for urgency
                backgroundColor: 'rgba(0,0,0,0.7)',
                padding: { x: 15, y: 10 },
                align: 'center'
            }
        ).setOrigin(0.5).setScrollFactor(0).setDepth(5001).setAlpha(0);
    }
    
    this.allyTrappedMessage.setText(message);
    this.allyTrappedMessage.setAlpha(0);
    // Fade in and out tween
    this.scene.tweens.add({
        targets: this.allyTrappedMessage,
        alpha: 1,
        duration: 500,
        ease: 'Power2',
        yoyo: true,
        hold: 3000, // Display message for 3 seconds
        onComplete: () => {
            this.allyTrappedMessage.setAlpha(0);
        }
    });
  }
}