

import Phaser from 'phaser';

export class MineSystem {
    constructor(scene) {
        this.scene = scene;
        this.mines = [];
        this.detectionLines = this.scene.add.graphics().setDepth(5);
        this.detectionRanges = this.scene.add.graphics().setDepth(4);
        this.raycastLines = this.scene.add.graphics().setDepth(6);
        
        // Mine configuration
        this.mineConfig = {
            lethal: {
                detectionRange: 200,
                explosionRange: 120,
                armingDelay: 800,
                triggerDelay: 800
            },
            snare: {
                detectionRange: 150,
                explosionRange: 100, // This is the "capture" range
                armingDelay: 1000,
                triggerDelay: 500
            }
        };
        
        // Create initial mines around the map
        this.createMines();
    }
    
    createMines() {
        const numMines = 10;
        const mapBounds = { x: [-600, 600], y: [-600, 600] };
        const minSpawnDistanceFromCenter = 150;
        for (let i = 0; i < numMines; i++) {
            const x = Phaser.Math.Between(mapBounds.x[0], mapBounds.x[1]);
            const y = Phaser.Math.Between(mapBounds.y[0], mapBounds.y[1]);
            
            // Ensure mines don't spawn too close to the player's starting area
            if (Phaser.Math.Distance.Between(x, y, 0, 0) > minSpawnDistanceFromCenter) {
                // Randomly create a lethal or snare mine
                const type = Math.random() < 0.5 ? 'lethal' : 'snare';
                this.createMine(x, y, type);
            } else {
                i--; // Decrement to try again, ensuring we get the full number of mines
            }
        }
    }
    
    createMine(x, y, type = 'lethal') {
        const config = this.mineConfig[type];
        const mineColor = type === 'lethal' ? 0x8B4513 : 0x228B22; // Brown for lethal, ForestGreen for snare
        const mine = {
            type: type,
            sprite: this.scene.add.circle(x, y, 8, mineColor),
            x: x,
            y: y,
            detectionRange: config.detectionRange,
            explosionRange: config.explosionRange,
            isArmed: false,
            isTriggered: false,
            detectedTargets: [],
            armingTimer: null,
            triggerTimer: null
        };
        
        // Add physics body for collision detection
        this.scene.physics.add.existing(mine.sprite, true); // true = static body
        mine.sprite.body.setCircle(8);
        mine.sprite.setDepth(2);
        
        // Add visual indicator
        const indicator = this.scene.add.circle(x, y, 3, 0xFF0000);
        indicator.setAlpha(0);
        mine.indicator = indicator;
        
        // Start arming process
        mine.armingTimer = this.scene.time.delayedCall(this.mineConfig[type].armingDelay, () => {
            mine.isArmed = true;
            mine.indicator.setAlpha(0.8);
            // Pulsing animation when armed
            this.scene.tweens.add({
                targets: mine.indicator,
                alpha: { from: 0.8, to: 0.3 },
                duration: 800,
                yoyo: true,
                repeat: -1,
                ease: 'Sine.easeInOut'
            });
        });
        
        this.mines.push(mine);
        return mine;
    }
    
    update(player, npcs, enemies) {
        this.detectionLines.clear();
        this.detectionRanges.clear();
        this.raycastLines.clear();
        
        this.mines.forEach(mine => {
            if (!mine.isArmed || mine.isTriggered) return;
            
            // Clear previous detected targets
            mine.detectedTargets = [];
            
            // Check for player detection
            this.checkTarget(mine, player.sprite, 'player');
            
            // Check for NPCs
            if (npcs && npcs.getChildren) {
                npcs.getChildren().forEach(npc => {
                    if (npc.isAlive) {
                        this.checkTarget(mine, npc, 'npc');
                    }
                });
            }
            
            // Check for enemies
            if (enemies) {
                enemies.forEach(enemy => {
                    if (enemy.sprite.active && !enemy.isCaptured) {
                        this.checkTarget(mine, enemy.sprite, 'enemy');
                    }
                });
            }
            
            // Draw detection range
            // Draw detection range
            if (mine.detectedTargets.length > 0) {
                this.detectionRanges.lineStyle(2, 0xFF4444, 0.4);
                this.detectionRanges.strokeCircle(mine.x, mine.y, mine.detectionRange);
                
                // Draw explosion range
                this.detectionRanges.lineStyle(3, 0xFF0000, 0.6);
                this.detectionRanges.strokeCircle(mine.x, mine.y, mine.explosionRange);
            }
            
            // Trigger if targets in explosion range
            const explosionTargets = mine.detectedTargets.filter(target => 
                target.distance <= mine.explosionRange
            );
            
            if (explosionTargets.length > 0 && !mine.triggerTimer) {
                this.triggerMine(mine);
            }
        });
    }
    
    checkTarget(mine, target, targetType) {
        // Don't detect targets that are already trapped
        if (target.isTrapped) return;
        
        const distance = Phaser.Math.Distance.Between(mine.x, mine.y, target.x, target.y);
        
        if (distance <= mine.detectionRange) {
            // Perform raycast to check line of sight
            const hasLineOfSight = this.performRaycast(mine, target);
            
            if (hasLineOfSight) {
                mine.detectedTargets.push({
                    target: target,
                    type: targetType,
                    distance: distance
                });
                
                // Draw detection line with color based on target type
                let lineColor;
                switch(targetType) {
                    case 'player':
                        lineColor = 0xFF0000; // Red for player
                        break;
                    case 'npc':
                        lineColor = 0x00FF00; // Green for NPCs
                        break;
                    case 'enemy':
                        lineColor = 0xFFFF00; // Yellow for enemies
                        break;
                    default:
                        lineColor = 0xFFFFFF;
                }
                
                this.detectionLines.lineStyle(2, lineColor, 0.8);
                this.detectionLines.strokeLineShape({
                    x1: mine.x, y1: mine.y,
                    x2: target.x, y2: target.y
                });
                
                // Draw raycast visualization
                this.visualizeRaycast(mine, target, lineColor);
            }
        }
    }
    
    performRaycast(mine, target) {
        // Create a line from mine to target
        const line = new Phaser.Geom.Line(mine.x, mine.y, target.x, target.y);
        const raycastPoints = line.getPoints(0, Math.floor(Phaser.Math.Distance.Between(mine.x, mine.y, target.x, target.y) / 15));
        
        // For now, assume clear line of sight (can be enhanced with obstacle detection)
        // This is where you could add collision checks with terrain, walls, etc.
        
        return true; // Clear line of sight
    }
    
    visualizeRaycast(mine, target, color) {
        // Draw multiple thin lines to show the raycast effect
        const numRays = 3;
        const spreadAngle = 0.1; // Small spread for effect
        
        for (let i = 0; i < numRays; i++) {
            const baseAngle = Phaser.Math.Angle.Between(mine.x, mine.y, target.x, target.y);
            const rayAngle = baseAngle + (i - 1) * spreadAngle;
            
            const rayDistance = Phaser.Math.Distance.Between(mine.x, mine.y, target.x, target.y);
            const rayEndX = mine.x + Math.cos(rayAngle) * rayDistance;
            const rayEndY = mine.y + Math.sin(rayAngle) * rayDistance;
            
            // Draw raycast line with varying alpha
            const alpha = 0.6 - (Math.abs(i - 1) * 0.2);
            this.raycastLines.lineStyle(1, color, alpha);
            this.raycastLines.strokeLineShape({
                x1: mine.x, y1: mine.y,
                x2: rayEndX, y2: rayEndY
            });
            
            // Add small dots along the ray
            const dotCount = Math.floor(rayDistance / 30);
            for (let j = 1; j < dotCount; j++) {
                const dotX = mine.x + Math.cos(rayAngle) * (rayDistance * j / dotCount);
                const dotY = mine.y + Math.sin(rayAngle) * (rayDistance * j / dotCount);
                
                this.raycastLines.fillStyle(color, alpha * 0.8);
                this.raycastLines.fillCircle(dotX, dotY, 1);
            }
        }
    }
    
    triggerMine(mine) {
        if (mine.isTriggered || mine.triggerTimer) return;
        
        mine.indicator.setFillStyle(0xFFFF00); // Yellow warning
        
        mine.triggerTimer = this.scene.time.delayedCall(this.mineConfig[mine.type].triggerDelay, () => {
            this.explodeMine(mine);
        });
        
        // Rapid pulsing warning
        this.scene.tweens.killTweensOf(mine.indicator);
        this.scene.tweens.add({
            targets: mine.indicator,
            alpha: { from: 1, to: 0.2 },
            duration: 100,
            yoyo: true,
            repeat: -1,
            ease: 'Sine.easeInOut'
        });
    }
    
    explodeMine(mine) {
        mine.isTriggered = true;
        let cleanupTimer = 800;
        if (mine.type === 'lethal') {
            // Play a sound for the explosion
            this.scene.sound.play('mine bombs', { 
                volume: 0.6,
                detune: Phaser.Math.Between(-800, -400) // Low pitch for explosion effect
            });
            const explosion = this.scene.add.particles(mine.x, mine.y, 'croppedBullet', {
                speed: { min: 100, max: 400 },
                angle: { min: 0, max: 360 },
                scale: { start: 0.05, end: 0 },
                tint: [0xFF4500, 0xFF6347, 0xFFFF00, 0xFFFFFF],
                blendMode: 'ADD',
                lifespan: 600,
                quantity: 25,
                emitting: true
            });
            this.scene.time.delayedCall(cleanupTimer, () => {
                if (explosion) explosion.destroy();
            });
        } else { // snare
            // Play a sound for the snare trap
             this.scene.sound.play('lasso sound', { 
                volume: 0.4,
                detune: Phaser.Math.Between(-100, 100)
            });
            // Visual effect for snare
            const snareEffect = this.scene.add.graphics();
            snareEffect.fillStyle(0x00FF00, 0.4);
            snareEffect.fillCircle(mine.x, mine.y, mine.explosionRange);
            this.scene.tweens.add({
                targets: snareEffect,
                scale: 0,
                alpha: 0,
                duration: 300,
                ease: 'Power2',
                onComplete: () => snareEffect.destroy()
            });
            cleanupTimer = 300;
        }
        
        // Apply effect to targets in range
        mine.detectedTargets.forEach(targetData => {
            if (targetData.distance <= mine.explosionRange) {
                this.applyMineEffect(mine.type, targetData.target, targetData.type);
            }
        });
        
        // Remove mine visuals
        mine.sprite.destroy();
        mine.indicator.destroy();
        
        // Remove from mines array after a delay to allow effects to play out
        this.scene.time.delayedCall(cleanupTimer, () => {
            const index = this.mines.indexOf(mine);
            if (index > -1) {
                this.mines.splice(index, 1);
            }
        });
    }
    
    applyMineEffect(mineType, target, targetType) {
        if (mineType === 'lethal') {
            const damage = 40;
            switch(targetType) {
                case 'player':
                    if (this.scene.player && this.scene.player.takeDamage) {
                        this.scene.player.takeDamage(damage);
                    }
                    break;
                case 'npc':
                    if (this.scene.npcSystem && this.scene.npcSystem.takeDamage) {
                        this.scene.npcSystem.takeDamage(target, damage);
                    }
                    break;
                case 'enemy':
                    if (this.scene.enemyManager) {
                        const enemy = this.scene.enemyManager.enemies.find(e => e.sprite === target);
                        if (enemy) {
                            this.scene.enemyManager.takeDirectDamage(enemy, damage);
                        }
                    }
                    break;
            }
        } else if (mineType === 'snare') {
            const damage = 15; // Snares now do a bit of damage
            switch(targetType) {
                case 'player':
                    if (this.scene.player && this.scene.player.takeDamage) {
                        this.scene.player.takeDamage(damage);
                    }
                    break;
                case 'npc':
                    if (this.scene.npcSystem && this.scene.npcSystem.takeDamage) {
                        this.scene.npcSystem.takeDamage(target, damage);
                    }
                    break;
                case 'enemy':
                    if (this.scene.enemyManager) {
                        const enemy = this.scene.enemyManager.enemies.find(e => e.sprite === target);
                        if (enemy) {
                            this.scene.enemyManager.takeDirectDamage(enemy, damage);
                        }
                    }
                    break;
            }
            this.snareTarget(target, targetType);
        }
    }
    snareTarget(target, targetType) {
        // Prevent re-trapping or trapping enemies that are already captured.
        if (target.isTrapped || (targetType === 'enemy' && target.isCaptured)) return;
        // Stop the target's movement immediately
        if (target.body) {
            target.body.stop();
        }
        target.isTrapped = true;
        // Use a different trap visual based on the target type
        const trapImageKey = (targetType === 'enemy') ? 'captured bandit' : 'player and npc jail trap';
        const trapVisual = this.scene.add.image(target.x, target.y, trapImageKey);
        let scale = 0.08;
        if(targetType === 'player' || targetType === 'npc'){
            scale = 0.12;
            trapVisual.y += 5; // Adjust position for player/npc visual
        } else { // enemy
            scale = 0.15;
            trapVisual.y -= 10;
        }
        trapVisual.setScale(scale);
        trapVisual.setDepth(target.depth + 1);
        target.trapVisual = trapVisual;
        // Add a message for the player
        if (targetType === 'player') {
            this.scene.uiManager.showTemporaryMessage("You're trapped! Press 'E' to pay 10 coins and escape.", 'orange');
        } else if (targetType === 'npc') {
            const npcData = this.scene.npcSystem.npcs.getChildren().find(n => n === target);
            if (npcData) {
                 this.scene.uiManager.showTemporaryMessage(`${npcData.name} is trapped! Get close and press 'E' to free them.`, 'orange');
            }
        }
    }
    
    destroy() {
        this.mines.forEach(mine => {
            if (mine.sprite) mine.sprite.destroy();
            if (mine.indicator) mine.indicator.destroy();
        });
        
        if (this.detectionLines) this.detectionLines.destroy();
        if (this.detectionRanges) this.detectionRanges.destroy();
        if (this.raycastLines) this.raycastLines.destroy();
    }
}

