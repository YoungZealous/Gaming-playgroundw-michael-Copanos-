

import Phaser from 'phaser';

export class ControlsScene extends Phaser.Scene {
    constructor() {
        super({ key: 'ControlsScene' });
    }

    create() {
        // Create tiled background, reusing the asset from the main menu
        for (let x = 0; x < this.scale.width; x += 200) {
            for (let y = 0; y < this.scale.height; y += 200) {
                const ground = this.add.image(x, y, 'desertGround').setOrigin(0, 0);
                ground.setScale(0.2);
                ground.setAlpha(0.8);
            }
        }

        // Scene Title
        this.add.text(this.scale.width / 2, this.scale.height / 2 - 250, 'Controls', {
            fontSize: '80px',
            fontFamily: '"Georgia", serif',
            fill: '#FFD700', // Gold color
            stroke: '#4E342E', // Dark brown stroke
            strokeThickness: 8
        }).setOrigin(0.5);

        // Controls Text
        const controlsText = [
            'W / Up Arrow: Move Up',
            'S / Down Arrow: Move Down',
            'A / Left Arrow: Move Left',
            'D / Right Arrow: Move Right',
            'Mouse Click: Shoot',
            'R: Reload',
            'E: Interact / Mount Horse',
            'Spacebar: Use Lasso'
        ];

        controlsText.forEach((text, index) => {
            this.add.text(this.scale.width / 2, this.scale.height / 2 - 120 + (index * 45), text, {
                fontSize: '32px',
                fontFamily: '"Georgia", serif',
                fill: '#FFFFFF',
                 stroke: '#000000',
                strokeThickness: 4
            }).setOrigin(0.5);
        });

        // Back Button
        const backButton = this.add.text(this.scale.width / 2, this.scale.height - 100, 'Back', {
            fontSize: '48px',
            fontFamily: '"Georgia", serif',
            fill: '#FFFFFF',
            backgroundColor: '#4E342E',
            padding: { x: 20, y: 10 },
        }).setOrigin(0.5);

        backButton.setInteractive({ useHandCursor: true });
        backButton.on('pointerover', () => backButton.setBackgroundColor('#6D4C41'));
        backButton.on('pointerout', () => backButton.setBackgroundColor('#4E342E'));
        backButton.on('pointerdown', () => {
            this.scene.start('MainMenuScene');
        });
    }
}

