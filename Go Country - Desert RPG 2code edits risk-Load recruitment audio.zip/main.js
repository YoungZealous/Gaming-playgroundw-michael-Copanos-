

import Phaser from 'phaser';
import { BootScene } from './bootScene.js';
import { MainMenuScene } from './mainMenuScene.js';
import { GameScene } from './gameScene.js';
import { ControlsScene } from './controlsScene.js';

const config = {
  type: Phaser.AUTO,
  physics: {
    default: 'arcade',
    arcade: {
      gravity: { y: 0 },
      debug: false
    }
  },
  scale: {
    mode: Phaser.Scale.FIT,
    autoCenter: Phaser.Scale.CENTER_BOTH,
    parent: 'phaser-game-container',
    width: 1024,
    height: 768
  },
  scene: [BootScene, MainMenuScene, GameScene, ControlsScene],
  backgroundColor: '#CD853F'
};

new Phaser.Game(config);

