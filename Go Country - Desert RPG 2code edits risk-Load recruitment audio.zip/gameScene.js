import Phaser from 'phaser';
import { Player } from './player.js';
import { EnemyManager } from './enemyManager.js';
import { NPCSystem } from './npcSystem.js';
import { UIManager } from './uiManager.js';
import { ChatManager } from './chatManager.js';
import { Molotov } from './molotov.js';
import { InventoryUI } from './inventory.js';
import { Horse } from './horse.js';
import { MineSystem } from './mineSystem.js';
import { AutoGunSystem } from './autoGunSystem.js';
import { JailTrapSystem } from './jailTrapSystem.js';
import { assets } from './assets.js';
export class GameScene extends Phaser.Scene {
  constructor() {
    super({ key: 'GameScene' });
    this.jailText = null;
    this.jailTextVisible = false;
    this.totalCapturedCount = 0;
    this.shopMenuContainer = null;
    this.isShopOpen = false;
    this.shopButtons = [];
    this.selectedShopButtonIndex = 0;
    this.isCommandMode = false;
    this.commandTargetSprite = null;
    this.commandPromptText = null;
    this.selectedNPCForCommand = null;
    this.joystick = null;
    this.shootButton = null;
    this.lassoButton = null;
    this.lassoButtonIcon = null;
    this.healthButton = null;
    this.healthButtonIcon = null;
    this.lastCoinSoundTime = 0; // To throttle coin sound
  }

  preload() {
    // Load assets
    this.load.image('playerRanger', 'https://play.rosebud.ai/assets/Untitled Project - 2025-07-06T183356.881-Photoroom.png?83Z6');
    this.load.image('playerRangerDown', 'https://play.rosebud.ai/assets/Untitled Project - 2025-07-06T193815.285.png?bM7N');
    this.load.image('banditEnemy', 'https://play.rosebud.ai/assets/BANDIT ENEMY AI.png?41VW');
    this.load.image('coyote-idle', 'https://play.rosebud.ai/assets/Untitled Project - 2025-07-06T163848.114.png?PCeG');
    this.load.image('coyote-shooting', 'https://play.rosebud.ai/assets/Untitled Project - 2025-07-06T163848.114.png?PCeG');
    this.load.image('desertGround', 'https://play.rosebud.ai/assets/desertGround.png?JqaT');
    this.load.image('desertCactus', 'https://play.rosebud.ai/assets/desertCactus.png?NJBi');
    this.load.image('bullet', 'https://play.rosebud.ai/assets/Untitled Project - 2025-07-07T130417.816.png?SKzg');
    this.load.image('playerBullet', 'https://play.rosebud.ai/assets/cropped bullet.png?0xgX');
    this.load.image('bulletTracer', 'https://play.rosebud.ai/assets/bulletTracer.png?VHux');
    this.load.image('lasso', 'https://play.rosebud.ai/assets/WHIP COLONIZERS.png?qRq0');
    this.load.image('healthPack', 'https://play.rosebud.ai/assets/health.png?AuIo');
    this.load.image('coin', 'https://play.rosebud.ai/assets/Go country real coin..png?6YQe');
    this.load.image('speedBoostIcon', 'https://play.rosebud.ai/assets/bulletTracer.png?VHux'); // Placeholder for speed boost
    this.load.image('jailHouse', 'https://play.rosebud.ai/assets/SPRINGFIELD MO JAIL HOUSE.png?gkpi');
    this.load.image(assets.playerMinimapIcon.name, assets.playerMinimapIcon.url);
    this.load.spritesheet('jailHouseUIText', 'https://play.rosebud.ai/assets/SPRINGFIELD MO JAIL HOUSE UI TEXT INDICATOR.gif?khU2', { frameWidth: 800, frameHeight: 211 });
    this.load.audio('gunshot', 'https://play.rosebud.ai/assets/snd_pistol_shot.wav?3arv');
    this.load.audio('reloadHandgun', 'https://play.rosebud.ai/assets/reload hand gun 9mm.mp3.mp3?Yn49');
    this.load.audio('npc_hurt', 'https://play.rosebud.ai/assets/snd_pistol_shot.wav?3arv'); // Placeholder sound
    this.load.audio('bullet_impact', 'https://play.rosebud.ai/assets/snd_pistol_shot.wav?3arv'); // Placeholder sound
    this.load.image('playerDeath1', 'https://play.rosebud.ai/assets/ezgif-frame-022-Photoroom.png?kaPL');
    this.load.image('playerDeath2', 'https://play.rosebud.ai/assets/ezgif-frame-022-Photoroom.png?kaPL');
    this.load.spritesheet('lassoAnim', 'https://play.rosebud.ai/assets/rope lasso.gif?lpbj', { frameWidth: 480, frameHeight: 480 });
    this.load.image('capturedBandit', 'https://play.rosebud.ai/assets/captured bandit.png?wHNw');
    this.load.audio('background_music', 'https://play.rosebud.ai/assets/Go Country by Young Zealous (Lyric Video).mp3?SNtz');
    this.load.image('horse', 'https://play.rosebud.ai/assets/horse.png?L2Bq');
    this.load.image('playerOnHorse', 'https://play.rosebud.ai/assets/Go country horse jump yz_09_delay-0.08s-removebg-preview.png?oGGx');
    this.load.audio('jail_door_close', 'https://play.rosebud.ai/assets/jail-door-closing-heavy-door-370000.mp3?P2Ky');
    this.load.audio('chaChing', 'https://play.rosebud.ai/assets/coins sound cha ching.mp3?DUXu');
    this.load.image('command_arrow', 'https://play.rosebud.ai/assets/pngimg.com - target_PNG17.png?1bo7');
    this.load.image('cworthNPC', 'https://play.rosebud.ai/assets/C-Worth NPC.png?GPgm');
    this.load.image('richardNPC', 'https://play.rosebud.ai/assets/Richard NPC.png?OCuI');
    this.load.image('jrabbNPC', 'https://play.rosebud.ai/assets/J Rabb.png?pXy0');
    this.load.image('poetNPC', 'https://play.rosebud.ai/assets/Prolly Poet.png?r1mM');
    this.load.audio('mine bombs', 'https://play.rosebud.ai/assets/mine bombs.mp3?QYw5');
    this.load.audio('lasso sound', 'https://play.rosebud.ai/assets/lasso sound.mp3?tszE');
    this.load.image('jailTrap', 'https://play.rosebud.ai/assets/player and npc jail trap.png?Rf2P');
  }
  create(data) {
    this.isLassoReady = false;
    this.lassoEffect = null;
    this.shopItems = {
        healthPack: { cost: 15, name: 'Health Pack' },
        life: { cost: 50, name: 'Extra Life' },
        lasso: { cost: 20, name: 'Lasso' },
        speedBoost: { cost: 10, name: 'Speed Boost' }
    };
    this.horseCost = 500;
    this.playerLives = data.playerLives !== undefined ? data.playerLives : 3;
    this.speedBoostTimer = null; // To manage the speed boost countdown
    // Create tiled desert background
    this.cacti = this.physics.add.staticGroup();
    this.createDesertEnvironment();
    this.createJailHouse(); // Create the Jail House building
    // Set the world bounds to match the desert environment size
    this.physics.world.setBounds(-2000, -2000, 4000, 4000);
    this.physics.world.drawDebug = false; // Ensure debug view is off
    
    // Ropes group for pickups
    this.lassos = this.physics.add.group(); // This is for lasso pickups
    // Power-ups group
    this.powerUps = this.physics.add.group();
    
    // Coins group
    this.coins = this.physics.add.group();
    // Molotovs group for throwing
    this.molotovs = this.physics.add.group({ classType: Molotov, runChildUpdate: true });
    // Fire areas group
    this.fireAreas = this.physics.add.group();
    this.horses = this.physics.add.group({ classType: Horse, runChildUpdate: true });
    // Initialize systems
    this.player = new Player(this, 400, 300);
    this.player.lives = this.playerLives;
    // Persist stats from previous life if they exist in the data object
    if (data.money !== undefined) {
        this.player.money = data.money;
    }
    if (data.inventory !== undefined) {
        this.player.inventory = data.inventory;
    }
    if (data.lassoCount !== undefined) {
        this.player.lassoCount = data.lassoCount;
    }
    this.player.totalEnemiesCaptured = data.totalEnemiesCaptured || 0;
    this.player.onHorse = false;
    if (this.player && this.player.sprite && this.lassos) {
        this.physics.add.overlap(this.player.sprite, this.lassos, this.collectLasso, null, this);
    }
    if (this.player && this.player.sprite && this.powerUps) {
        this.physics.add.overlap(this.player.sprite, this.powerUps, this.collectPowerUp, null, this);
    }
    this.healthPacks = this.physics.add.group();
    if(this.player && this.player.sprite && this.healthPacks) {
        this.physics.add.overlap(this.player.sprite, this.healthPacks, this.collectHealthPack, null, this);
    }
    if (this.player && this.player.sprite && this.coins) {
        this.physics.add.overlap(this.player.sprite, this.coins, this.collectCoin, null, this);
    }
    this.enemyManager = new EnemyManager(this, this.player);
    this.npcSystem = new NPCSystem(this);
    this.mineSystem = new MineSystem(this);
    this.jailTrapSystem = new JailTrapSystem(this);
    this.autoGunSystem = new AutoGunSystem(this, this.npcSystem, this.enemyManager);
    this.uiManager = new UIManager(this);
    this.chatManager = new ChatManager(this);
    this.inventoryUI = new InventoryUI(this, this.player.inventory);
    this.physics.add.overlap(this.player.sprite, this.jailTrapSystem.traps, this.handlePlayerTrapCollision, null, this);
    this.physics.add.overlap(this.npcSystem.getNPCSprites(), this.jailTrapSystem.traps, this.handleNPCTrapCollision, null, this);
    // Patch for missing uiManager function
    if (this.uiManager && typeof this.uiManager.showTemporaryMessage !== 'function') {
        this.uiManager.showTemporaryMessage = (message, duration = 3000) => {
            const messageStyle = {
                fontSize: '24px',
                fill: '#FFD700',
                fontFamily: '"Georgia", serif',
                backgroundColor: 'rgba(0,0,0,0.7)',
                padding: { x: 15, y: 10 },
                align: 'center',
                stroke: '#000000',
                strokeThickness: 3
            };
            const messageText = this.add.text(this.cameras.main.width / 2, this.cameras.main.height / 2 + 100, message, messageStyle)
                .setOrigin(0.5)
                .setScrollFactor(0)
                .setDepth(5000)
                .setAlpha(0);
            this.tweens.add({
                targets: messageText,
                alpha: 1,
                duration: 400,
                ease: 'Power2',
                yoyo: true,
                hold: duration - 800, // Account for fade in/out time
                onComplete: () => {
                    messageText.destroy();
                }
            });
        };
    }
    // Add collision between enemy bullets and NPCs
    // Set up NPC mine collision detection
    if (this.npcSystem && this.mineSystem) {
        this.npcSystem.setupMineCollisions();
    }
    
    if (this.enemyManager && this.enemyManager.bullets && this.npcSystem && this.npcSystem.getNPCSprites() && this.player && this.player.sprite) {
        this.physics.add.overlap(this.enemyManager.bullets, this.npcSystem.getNPCSprites(), this.damageNPC, null, this);
        this.physics.add.overlap(this.enemyManager.bullets, this.player.sprite, this.damagePlayer, null, this);
    } else {
        console.warn('GameScene.create: Could not set up collision for enemy bullets, a required object is missing.', {
            enemyManager: !!this.enemyManager,
            enemyBullets: !!this.enemyManager?.bullets,
            npcSystem: !!this.npcSystem,
            npcSprites: !!this.npcSystem?.getNPCSprites(),
            player: !!this.player?.sprite
        });
    }
    
    
    // Collision between fire and enemies
    if (this.enemyManager && this.enemyManager.enemySprites && this.fireAreas) {
        this.physics.add.overlap(this.enemyManager.enemySprites, this.fireAreas, this.handleFireDamage, null, this);
    }
    // Collision between enemy bullets and horses
    if (this.enemyManager && this.enemyManager.bullets && this.horses) {
        this.physics.add.overlap(this.enemyManager.bullets, this.horses, this.damageHorse, null, this);
    }
    // Collision between player bullets and enemies
    if (this.player && this.player.bullets && this.enemyManager && this.enemyManager.enemySprites) {
        this.physics.add.collider(this.player.bullets, this.enemyManager.enemySprites, this.bulletHitEnemy, null, this);
    }
    
    // Collision between player bullets and cacti
    if (this.player && this.player.bullets && this.cacti) {
        this.physics.add.collider(this.player.bullets, this.cacti, this.bulletHitCactus, null, this);
    }
    
    // Collision between NPC bullets and enemies
    if (this.npcSystem && this.npcSystem.bullets && this.enemyManager) {
        const enemySprites = this.enemyManager.enemies.map(e => e.sprite);
        this.physics.add.overlap(this.npcSystem.bullets, enemySprites, this.npcBulletHitEnemy, null, this);
    }
    
    // Collision between player's lasso and enemies
    if (this.player && this.player.lassos && this.enemyManager && this.enemyManager.enemySprites) {
        this.physics.add.overlap(this.player.lassos, this.enemyManager.enemySprites, this.lassoHitEnemy, null, this);
    }
    
    // Collision between NPCs, and between NPCs and Enemies
    const enemySprites = this.enemyManager.enemies.map(e => e.sprite);
    const npcSprites = this.npcSystem.getNPCSprites();
    this.physics.add.collider(npcSprites, npcSprites); // NPCs collide with each other
    this.physics.add.collider(npcSprites, enemySprites); // NPCs collide with enemies
    this.physics.add.collider(enemySprites, enemySprites); // Enemies collide with each other
    // Setup input
    this.cursors = this.input.keyboard.createCursorKeys();
    this.wasd = this.input.keyboard.addKeys('W,S,A,D,H,I,L,SPACE,R,E,M,X,EQUALS,TAB,P,T,F,Y,N,O,J,SIX');
    this.escKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.ESC);
    this.enterKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.ENTER);
    // Custom cursor
    this.input.setDefaultCursor(`url('https://play.rosebud.ai/assets/pngimg.com - target_PNG17.png?1bo7') 16 16, pointer`);
    this.input.on('pointerdown', (pointer) => {
        // We multiplex the pointerdown event here
        if (this.isCommandMode) {
            this.handleCommandClick(pointer);
        } else if (this.isShopOpen) {
            // The shop menu now handles its own button clicks directly,
            // so this global handler doesn't need to do anything for the shop.
        } else if (!this.sys.game.device.os.desktop && this.isLassoReady && this.lassoButton?.getBounds().contains(pointer.x, pointer.y)) {
            // This case is handled by the lassoButton's on 'pointerdown' event, so we do nothing here to avoid double-firing.
        } else {
            // This is the new lasso throw logic for desktop
            if (this.sys.game.device.os.desktop) {
              this.handleLassoThrow(pointer);
            }
        }
    }, this);
    // Camera follows player
    this.cameras.main.startFollow(this.player.sprite);
    this.cameras.main.setZoom(0.8);
    // --- Minimap Camera ---
    const minimapSize = 200;
    this.minimap = this.cameras.add(this.scale.width - minimapSize - 20, 20, minimapSize, minimapSize)
        .setZoom(0.1)
        .setName('mini')
        .setBackgroundColor(0x0D2039) // Dark desert night color
        .startFollow(this.player.sprite);
    this.minimap.setScroll(this.player.sprite.x, this.player.sprite.y);
    // Setup minimap elements that depend on the minimap camera
    this.setupMinimapElements();
    
    // Atmospheric lighting overlay
    const overlay = this.add.rectangle(0, 0, this.scale.width, this.scale.height, 0xFFB366, 0.2);
    overlay.setScrollFactor(0);
    overlay.setDepth(1000); // Ensure it's on top of everything
    
    // Damage flash effect
    this.damageFlash = this.add.rectangle(0, 0, this.scale.width, this.scale.height, 0xFF0000, 0)
      .setScrollFactor(0)
      .setDepth(1500);
      
    // --- Player Status UI ---
    this.createPlayerStatusUI();
    
    // Create player death animation
    this.anims.create({
        key: 'player_death_anim',
        frames: [
            { key: 'playerDeath1' },
            { key: 'playerDeath2' }
        ],
        frameRate: 2,
        repeat: 0
    });
    this.anims.create({
        key: 'jail_text_anim',
        frames: this.anims.generateFrameNumbers('jailHouseUIText', { start: 0, end: -1 }),
        frameRate: 10,
        repeat: -1
    });
    this.anims.create({
        key: 'lasso_swing_anim',
        frames: this.anims.generateFrameNumbers('lassoAnim', { start: 0, end: 11 }),
        frameRate: 12,
        repeat: -1
    });
    // --- Background Music ---
    // Check if music is already playing to prevent overlap when a life is lost
    const existingMusic = this.sound.get('background_music');
    if (!existingMusic || !existingMusic.isPlaying) {
        this.backgroundMusic = this.sound.add('background_music', {
          loop: true,
          volume: 0.5 // Start at 50% volume
        });
        this.backgroundMusic.play();
    } else {
        this.backgroundMusic = existingMusic;
    }
    this.isPaused = false;
    this.pauseMenuContainer = null;
    this.pauseMenuItems = [];
    this.selectedPauseItemIndex = 0;
    this.createPauseMenu();
    this.createShopMenu();
    this.createInstructionsMenu();
    this.uiFocusGroups = ['game', 'pause', 'shop', 'inventory'];
    this.currentUIFocus = 'game'; // 'game', 'pause', 'shop', 'inventory'
    this.selectedInventorySlotIndex = 0;
    this.playerTitleText = this.add.text(this.cameras.main.width / 2, this.cameras.main.height / 2 - 60, 'Young Zealous', {
        fontSize: '24px',
        fill: '#FFFFFF',
        fontStyle: 'italic',
        stroke: '#000000',
        strokeThickness: 4,
    }).setOrigin(0.5).setAlpha(0.7).setVisible(false).setDepth(100).setScrollFactor(0);
    this.turnInPrompt = this.add.text(this.cameras.main.width / 2, this.cameras.main.height - 70, '', {
        fontFamily: '"Georgia", serif',
        fontSize: '28px',
        fill: '#FFD700',
        align: 'center',
        backgroundColor: 'rgba(0,0,0,0.7)',
        padding: { x: 15, y: 10 },
        stroke: '#000000',
        strokeThickness: 3
    }).setOrigin(0.5).setScrollFactor(0).setDepth(2000).setVisible(false)
      .setInteractive({ useHandCursor: true })
      .on('pointerdown', () => {
        if (this.turnInPrompt.visible) {
          this.toggleShopMenu();
        }
      })
      .on('pointerover', () => {
        if (this.turnInPrompt.visible) {
          this.turnInPrompt.setFill('#FFFF00'); // Brighter highlight on hover
        }
      })
      .on('pointerout', () => {
        this.turnInPrompt.setFill('#FFD700'); // Revert to original color
      });
    this.createCommandUI();
    this.commandTargetSprite = this.add.sprite(0, 0, 'command_arrow').setVisible(false).setDepth(3000).setScale(0.1);
    this.createMobileControls();
    
    // Create the lasso effect sprite but keep it hidden
    this.lassoEffect = this.add.sprite(this.player.sprite.x, this.player.sprite.y, 'lassoAnim').setVisible(false).setDepth(this.player.sprite.depth + 1);
    this.lassoEffect.setScale(0.35);
  }
  
  npcBulletHitEnemy(enemySprite, bullet) {
    if (!bullet.active || !enemySprite.active) return;
    // Add sound and visual effect for impact
    this.sound.play('bullet_impact', { volume: 0.15, detune: 100 });
    this.createImpactEffect(bullet.x, bullet.y);
    const enemy = this.enemyManager.enemies.find(e => e.sprite === enemySprite);
    if (enemy && !enemy.isCaptured) {
        this.enemyManager.takeDirectDamage(enemy, bullet.damage || 10);
    }
    bullet.disableBody(true, true);
  }
  lassoHitEnemy(lasso, enemySprite) {
    if (!lasso.active || !enemySprite.active) return;
    const enemy = this.enemyManager.findEnemyBySprite(enemySprite);
    if (enemy && enemy.isAlive && !enemy.isCaptured) {
        lasso.kill();
        
        // Capture logic
        enemy.sprite.setTexture('capturedBandit');
        enemy.sprite.clearTint();
        if (enemy.moveTween) {
            enemy.moveTween.stop();
        }
        this.enemyManager.captureEnemy(enemy, this.player);
        this.sound.play('lasso sound', { volume: 0.5 });
        // Add a visual "poof" effect on successful capture
        this.createLassoPoofEffect(enemy.sprite.x, enemy.sprite.y);
        
        // Switch back to pistol after a successful capture
        this.player.isLassoEquipped = false; 
    }
  }
  
  bulletHitEnemy(bullet, enemySprite) {
    if (!bullet.active || !enemySprite.active) return;
    
    // Create impact sound
    this.sound.play('bullet_impact', { volume: 0.2, detune: 200 });
    
    // Damage the enemy
    const enemy = this.enemyManager.enemies.find(e => e.sprite === enemySprite);
    // This check is now handled inside enemyManager.takeDirectDamage to centralize the logic.
    if (enemy) {
        this.enemyManager.takeDirectDamage(enemy, 10);
    }
    
    // Deactivate bullet
    bullet.setActive(false).setVisible(false);
  }
  
  bulletHitCactus(bullet, cactus) {
    if (!bullet.active) return;
    // Create impact sound
    this.sound.play('bullet_impact', { volume: 0.1, detune: 500 });
    // Damage the cactus
    if (cactus.health > 0) {
        cactus.health -= 1;
        cactus.setTint(0xff8a8a); // Tint red on hit
        this.time.delayedCall(100, () => cactus.clearTint().setTint(0x8B7355));
    }
    if (cactus.health <= 0) {
        this.destroyCactus(cactus);
    }
    // Deactivate bullet
    // Deactivate bullet
    bullet.setActive(false).setVisible(false);
  }
  createLassoPoofEffect(x, y) {
    const particles = this.add.particles(x, y, 'bulletTracer', {
        speed: { min: 20, max: 80 },
        angle: { min: 0, max: 360 },
        scale: { start: 0.3, end: 0 },
        lifespan: 400,
        quantity: 10,
        emitting: true,
        tint: [0x8B4513, 0xD2B48C], // SaddleBrown and Tan
        blendMode: 'ADD'
    });
    this.time.delayedCall(500, () => particles.destroy());
  }
  
  destroyCactus(cactus) {
    // Optional: flash effect before destroying
    cactus.setTint(0xff0000);
    this.time.delayedCall(100, () => {
        cactus.destroy();
    });
  }
  createDesertEnvironment() {
    // Create tiled ground
    for (let x = -2000; x < 2000; x += 200) {
      for (let y = -2000; y < 2000; y += 200) {
        const ground = this.add.image(x, y, 'desertGround');
        ground.setScale(0.2);
        ground.setAlpha(0.8);
        ground.setDepth(-1); // Ensure ground is behind everything
      }
    }
    
    // Add cacti scattered around
    for (let i = 0; i < 15; i++) {
      const x = Phaser.Math.Between(-800, 800);
      const y = Phaser.Math.Between(-600, 600);
      const cactus = this.cacti.create(x, y, 'desertCactus');
      cactus.setScale(0.15).setTint(0x8B7355);
      cactus.health = 3; // Give cactus 3 health points
      cactus.refreshBody(); // Apply scale changes to the static physics body
    }
  }
  createJailHouse() {
    // Create the building sprite
    const jailHouseSprite = this.physics.add.staticSprite(0, -150, 'jailHouse');
    jailHouseSprite.setScale(1.0).refreshBody();
    jailHouseSprite.setDepth(5);
    
    // --- Unified Turn-In and Collision Zone ---
    // The jailhouse sprite's body itself is now the trigger zone.
    // The separate 'turnInZone' is no longer needed, simplifying the logic.
    // The jailhouse object now directly references the sprite, which contains the zone.
    // The jailhouse object holds both the sprite and the zone for easy access
    this.jailhouse = {
      sprite: jailHouseSprite,
      turnInZone: jailHouseSprite // The sprite itself is the zone
    };
    // Keep the UI text logic, but refer to the new structure
    this.jailText = this.add.sprite(this.jailhouse.sprite.x, this.jailhouse.sprite.y - this.jailhouse.sprite.displayHeight / 2 - 20, 'jailHouseUIText')
      .setScale(0.5)
      .setAlpha(0)
      .setDepth(100);
    this.jailText.play('jail_text_anim');
  }
  setupMinimapElements() {
    // Add minimap indicator for the jailhouse
    // This is the minimap indicator logic, we'll keep it as is.
    const minimapIndicator = this.add.sprite(this.jailhouse.sprite.x, this.jailhouse.sprite.y - this.jailhouse.sprite.displayHeight / 2 - 30, 'jailHouseUIText');
    minimapIndicator.play('jail_text_anim');
    minimapIndicator.setScale(1.2);
    minimapIndicator.setDepth(this.jailhouse.sprite.depth + 1);
    this.minimap.ignore(this.jailhouse.sprite); // Optionally hide the big building from minimap
    this.cameras.main.ignore(minimapIndicator); // Hide indicator from main camera
  }
  
  createMobileControls() {
    if (!this.sys.game.device.os.desktop) {
      // Joystick for movement
      this.joystick = this.add.circle(0, 0, 75, 0x888888, 0.5).setScrollFactor(0).setDepth(4000).setVisible(false);
      this.joystick.inner = this.add.circle(0, 0, 35, 0xffffff, 0.7).setScrollFactor(0).setDepth(4001).setVisible(false);
      
      const buttonY = this.scale.height - 100;
      
      // Shoot button
      // Shoot button
      this.shootButton = this.add.circle(this.scale.width - 80, buttonY, 50, 0xff0000, 0.5)
        .setScrollFactor(0)
        .setDepth(4000)
        .setInteractive()
        .on('pointerdown', () => {
          if (this.player && !this.player.isTrapped) {
            this.player.startShooting();
            this.shootButton.setFillStyle(0xaa0000, 0.7);
          }
        })
        .on('pointerup', () => {
          this.player.stopShooting();
          this.shootButton.setFillStyle(0xff0000, 0.5);
        })
        .on('pointerout', () => {
          this.player.stopShooting();
          this.shootButton.setFillStyle(0xff0000, 0.5);
        });
      this.add.image(this.shootButton.x, this.shootButton.y, 'playerBullet').setScale(3).setScrollFactor(0).setDepth(4001);
      // Lasso Button
      this.lassoButton = this.add.circle(this.scale.width - 180, buttonY, 40, 0x8B4513, 0.6)
        .setScrollFactor(0)
        .setDepth(4000)
        .setInteractive();
      this.lassoButton.on('pointerdown', () => {
          if (this.player.lassoCount > 0 && !this.isLassoReady) {
              this.handleLassoReady(true);
              this.handleLassoThrow(null, true);
              this.lassoButton.setFillStyle(0x652B0E, 0.8);
          }
      }).on('pointerup', () => {
          this.lassoButton.setFillStyle(0x8B4513, 0.6);
      }).on('pointerout', () => {
           this.lassoButton.setFillStyle(0x8B4513, 0.6);
      });
      this.lassoButtonIcon = this.add.image(this.lassoButton.x, this.lassoButton.y, 'lasso').setScale(0.08).setScrollFactor(0).setDepth(4001);
        
      // Health Button
      this.healthButton = this.add.circle(this.scale.width - 260, buttonY, 40, 0x008000, 0.6)
          .setScrollFactor(0)
          .setDepth(4000)
          .setInteractive();
      this.healthButton.on('pointerdown', () => {
        if (this.player.inventory.healthPacks > 0) {
            this.player.useHealthPack();
            this.healthButton.setFillStyle(0x005500, 0.8);
        }
      }).on('pointerup', () => {
        this.healthButton.setFillStyle(0x008000, 0.6);
      }).on('pointerout', () => {
        this.healthButton.setFillStyle(0x008000, 0.6);
      });
      this.healthButtonIcon = this.add.image(this.healthButton.x, this.healthButton.y, 'healthPack').setScale(0.04).setScrollFactor(0).setDepth(4001);
      this.input.on('pointerdown', this.handleJoystickDown, this);
      this.input.on('pointermove', this.handleJoystickMove, this);
      this.input.on('pointerup', this.handleJoystickUp, this);
      this.updateMobileButtonStates();
    }
  }
  handleJoystickDown(pointer) {
    if (this.sys.game.device.os.desktop) return;
    // Only activate joystick if the touch is on the left half of the screen and not on an action button
    const rightSideButtons = [this.shootButton, this.lassoButton, this.healthButton].filter(b => b);
    const onButton = rightSideButtons.some(button => button.getBounds().contains(pointer.x, pointer.y));
    if (pointer.x < this.scale.width / 2 && !onButton) {
      this.joystick.setPosition(pointer.x, pointer.y).setVisible(true);
      this.joystick.inner.setPosition(pointer.x, pointer.y).setVisible(true);
      this.joystick.pointerId = pointer.id;
    }
  }
  handleJoystickMove(pointer) {
    if (this.sys.game.device.os.desktop || !this.joystick.visible || pointer.id !== this.joystick.pointerId) return;
    
    const dist = Phaser.Math.Distance.Between(this.joystick.x, this.joystick.y, pointer.x, pointer.y);
    const maxDist = 75;
    if (dist < maxDist) {
      this.joystick.inner.setPosition(pointer.x, pointer.y);
    } else {
      const angle = Phaser.Math.Angle.Between(this.joystick.x, this.joystick.y, pointer.x, pointer.y);
      this.joystick.inner.setPosition(
        this.joystick.x + maxDist * Math.cos(angle),
        this.joystick.y + maxDist * Math.sin(angle)
      );
    }
  }
  handleJoystickUp(pointer) {
    if (this.sys.game.device.os.desktop || !this.joystick.visible || pointer.id !== this.joystick.pointerId) return;
    this.joystick.setVisible(false).removeData('pointerId');
    this.joystick.inner.setVisible(false);
  }
  update() {
    this.handleGlobalInput();
    
    if (this.currentUIFocus === 'pause') {
      this.handlePauseMenuInput();
    }
    
    if (this.currentUIFocus === 'shop') {
      this.handleShopInput();
    }
    
    if (this.currentUIFocus === 'inventory') {
      this.handleInventoryInput();
    }
    if (this.isPaused || this.isShopOpen || this.inventoryUI.isOpen) {
        return; // Skip game updates when a menu is open
    }
    // --- UPDATE CHECKS ---
    // Make sure objects exist and are active before updating them.
    if (this.player && this.player.sprite && this.player.sprite.active && !this.player.isTrapped) {
      const joystickMove = (this.joystick && this.joystick.visible) ? {
          x: (this.joystick.inner.x - this.joystick.x) / 75,
          y: (this.joystick.inner.y - this.joystick.y) / 75
      } : null;
      this.player.update(this.wasd, this.input.activePointer, joystickMove);
      if (this.playerTitleText) {
          const isMoving = this.player.sprite.body.velocity.x !== 0 || this.player.sprite.body.velocity.y !== 0;
          this.playerTitleText.setVisible(isMoving);
      }
      if (this.lassoEffect && this.isLassoReady) {
        this.lassoEffect.setPosition(this.player.sprite.x, this.player.sprite.y);
      }
    } else if (this.player && this.player.isTrapped) {
        if (this.player.trapIndicator) {
            this.player.trapIndicator.setPosition(this.player.sprite.x, this.player.sprite.y);
        }
    } else if (!this.player) {
      console.log('GameScene.update: this.player is undefined.');
    }
    if (this.enemyManager) {
      this.enemyManager.update();
    } else {
      console.log('GameScene.update: this.enemyManager is undefined.');
    }
    this.updateCapturedEnemyIndicators();
    this.updateCaptiveSafeStatus();
    this.drawRopes();
    if (this.npcSystem) {
      // Provide NPCs with a list of only non-captured enemies to target
      const activeEnemies = this.enemyManager.enemies.filter(e => e.isAlive && !e.isCaptured);
      this.npcSystem.update(this.player, activeEnemies);
    } else {
      console.log('GameScene.update: this.npcSystem is undefined.');
    }
    
    // Update mine system with current entities
    if (this.mineSystem) {
      this.mineSystem.update(this.player, this.npcSystem.npcs, this.enemyManager.enemies);
    }
    
    // Update auto gun system
    if (this.autoGunSystem) {
      this.autoGunSystem.update();
    }
    
    if (this.jailTrapSystem) {
        this.jailTrapSystem.update();
    }
    if (this.uiManager) {
      this.uiManager.update(this.minimap);
    }
    
    // Handle input - These are now handled by handleGlobalInput
    // this.handleChatInput();
    // this.handleInventoryInput();
    // this.handleShopInput();
    this.handleLassoReady();
    if (Phaser.Input.Keyboard.JustDown(this.wasd.T)) {
        this.uiManager.toggleMinimapSize();
    }
    if (Phaser.Input.Keyboard.JustDown(this.wasd.SIX)) {
        this.toggleCommandMode();
    }
    if (Phaser.Input.Keyboard.JustDown(this.wasd.J)) {
        this.jailTrapSystem.placeTrap(this.player.sprite.x, this.player.sprite.y);
    }
    if (this.isCommandMode && this.selectedNPCForCommand && this.commandTargetSprite) {
        const pointer = this.input.activePointer;
        const worldPoint = this.cameras.main.getWorldPoint(pointer.x, pointer.y);
        this.commandTargetSprite.setPosition(worldPoint.x, worldPoint.y);
    }
    
    // Update Money UI
    this.updatePlayerStatusUI();
    // Update target position
    this.checkJailProximity();
    this.handleHorseInteraction();
    this.checkJailDropOff();
  }
  updateCapturedEnemyIndicators() {
    if (!this.player || !this.player.capturedEnemies) return;
    this.player.capturedEnemies.forEach(enemy => {
        if (enemy && enemy.sprite && enemy.sprite.active) {
            if (!enemy.capturedIndicator) {
                // Create indicator if it doesn't exist
                enemy.capturedIndicator = this.add.text(0, 0, 'CAPTURED', {
                    fontSize: '14px',
                    fill: '#FFD700', // Gold color for visibility
                    stroke: '#000000',
                    strokeThickness: 2,
                    backgroundColor: 'rgba(0,0,0,0.5)',
                    padding: { x: 3, y: 1 }
                }).setOrigin(0.5);
            }
            // Position indicator above the health bar
            const healthBarY = enemy.healthBar.y;
            const healthBarX = enemy.healthBar.x;
            enemy.capturedIndicator.setPosition(healthBarX, healthBarY - 18);
            enemy.capturedIndicator.setDepth(enemy.sprite.depth);
        } else if (enemy && enemy.capturedIndicator) {
            // Clean up indicator if enemy is gone
            enemy.capturedIndicator.destroy();
            enemy.capturedIndicator = null;
        }
    });
  }
  updateCaptiveSafeStatus() {
    if (!this.player || !this.player.capturedEnemies) return;
    const inDropOffZone = this.jailhouse && Phaser.Geom.Intersects.RectangleToRectangle(this.player.sprite.getBounds(), this.jailhouse.turnInZone.getBounds());
    this.player.capturedEnemies.forEach(enemy => {
        if (!enemy || !enemy.sprite || !enemy.sprite.active) return;
        // The safe indicator is linked to the main drop-off zone centered on the player
        if (inDropOffZone) {
            if (!enemy.safeIndicator) {
                enemy.safeIndicator = this.add.text(0, 0, 'SAFE', {
                    fontSize: '16px',
                    fill: '#00FFFF', // Cyan color for 'SAFE'
                    stroke: '#000000',
                    strokeThickness: 2,
                    fontStyle: 'bold'
                }).setOrigin(0.5);
            }
            const healthBarY = enemy.healthBar.y;
            const healthBarX = enemy.healthBar.x;
            const healthBarWidth = enemy.healthBar.width;
            // Position it above the 'following' checkmark
            enemy.safeIndicator.setPosition(healthBarX + healthBarWidth / 2 + 10, healthBarY - 18);
            enemy.safeIndicator.setDepth(enemy.sprite.depth).setVisible(true);
        } else if (enemy.safeIndicator) {
            enemy.safeIndicator.setVisible(false);
        }
    });
  }
  drawRopes() {
      // Initialize or clear the graphics object for ropes
      if (!this.ropeGraphics) {
          this.ropeGraphics = this.add.graphics().setDepth(10); // Draw ropes above ground but below sprites
      }
      this.ropeGraphics.clear();
      
      if (this.player && this.player.capturedEnemies.length > 0) {
          this.ropeGraphics.lineStyle(3, 0x8B4513, 0.7); // SaddleBrown, semi-transparent
          
          this.player.capturedEnemies.forEach(enemy => {
              if (enemy && enemy.sprite && enemy.sprite.active) {
                  this.ropeGraphics.beginPath();
                  this.ropeGraphics.moveTo(this.player.sprite.x, this.player.sprite.y);
                  this.ropeGraphics.lineTo(enemy.sprite.x, enemy.sprite.y);
                  this.ropeGraphics.strokePath();
              }
          });
      }
  }
  
  checkJailProximity() {
      if (!this.player || !this.player.sprite.active || !this.jailhouse || !this.jailText) return;
      const distance = Phaser.Math.Distance.Between(
          this.player.sprite.x,
          this.player.sprite.y,
          this.jailhouse.sprite.x,
          this.jailhouse.sprite.y
      );
      const triggerDistance = 350;
      if (distance < triggerDistance && !this.jailTextVisible) {
          this.jailTextVisible = true;
          this.tweens.killTweensOf(this.jailText);
          this.tweens.add({
              targets: this.jailText,
              alpha: 1,
              duration: 500,
              ease: 'Power2',
              onComplete: () => {
                  this.time.delayedCall(2000, () => {
                      this.tweens.add({
                          targets: this.jailText,
                          alpha: 0,
                          duration: 500,
                          ease: 'Power2',
                          onComplete: () => {
                              this.jailTextVisible = false;
                          }
                      });
                  });
              }
          });
      }
  }
  handleLassoReady(force = false) {
    if (force || Phaser.Input.Keyboard.JustDown(this.wasd.F)) {
      if (this.player.lassoCount > 0 && !this.isLassoReady) {
        this.isLassoReady = true;
        this.player.lassoCount--;
        this.updatePlayerStatusUI();
        
        // Show and animate the lasso effect
        this.lassoEffect.setVisible(true);
        this.lassoEffect.play('lasso_swing_anim');
        
        // Optional: play a sound
        // this.sound.play('lasso_swoosh');
      } else if (this.isLassoReady && !force) {
        // Cancel the lasso ready state
        this.isLassoReady = false;
        this.lassoEffect.setVisible(false).stop();
        this.player.lassoCount++; // Give the lasso back
        this.updatePlayerStatusUI();
      }
    }
  }
  handleReviveInput() {
    this.npcSystem.handleRevive(this.player, this.wasd.EQUALS.isDown);
  }
  handleLassoThrow(pointer, force = false) {
    // Only throw if the lasso is readied and it's a primary click, or if forced by mobile button
    if (this.isLassoReady && (force || (pointer && pointer.leftButtonDown()))) {
        const captureRadius = 150; // How close the player needs to be to capture
        let closestEnemy = null;
        let minDistance = captureRadius;
        // Find the closest, non-captured enemy within range
        this.enemyManager.enemies.forEach(enemy => {
            if (enemy.isAlive && !enemy.isCaptured) {
                const distance = Phaser.Math.Distance.Between(
                    this.player.sprite.x, this.player.sprite.y,
                    enemy.sprite.x, enemy.sprite.y
                );
                if (distance < minDistance) {
                    minDistance = distance;
                    closestEnemy = enemy;
                }
            }
        });
        if (closestEnemy) {
            // Successfully captured an enemy
            // Change texture and stop any ongoing movement tweens
            closestEnemy.sprite.setTexture('capturedBandit');
            closestEnemy.sprite.clearTint(); // Ensure no tints are carried over
            if (closestEnemy.moveTween) {
                closestEnemy.moveTween.stop();
            }
            this.enemyManager.captureEnemy(closestEnemy, this.player);
            // this.sound.play('capture_success'); // Optional: success sound
        } else {
            // Lasso throw failed (no enemy in range), give the lasso back
            this.player.lassoCount++;
            this.updatePlayerStatusUI();
            // this.sound.play('lasso_miss'); // Optional: miss sound
        }
        // Reset lasso state regardless of success
        this.isLassoReady = false;
        this.lassoEffect.setVisible(false).stop();
    } else if (this.isLassoReady && !force && pointer && !pointer.leftButtonDown()) {
        // If lasso was ready but user clicked with something other than left-click, cancel it
        this.isLassoReady = false;
        this.lassoEffect.setVisible(false).stop();
        this.player.lassoCount++;
        this.updatePlayerStatusUI();
    }
  }
  handleInventoryInput() {
    const totalSlots = this.player.inventory.maxSize;
    const itemsInInventory = Object.keys(this.player.inventory.items).length;
    if (itemsInInventory === 0) {
      this.inventoryUI.updateSelection(-1); // No selection if empty
      return; 
    }
    if (Phaser.Input.Keyboard.JustDown(this.cursors.right) || Phaser.Input.Keyboard.JustDown(this.wasd.D)) {
        this.selectedInventorySlotIndex = (this.selectedInventorySlotIndex + 1) % totalSlots;
    } else if (Phaser.Input.Keyboard.JustDown(this.cursors.left) || Phaser.Input.Keyboard.JustDown(this.wasd.A)) {
        this.selectedInventorySlotIndex = (this.selectedInventorySlotIndex - 1 + totalSlots) % totalSlots;
    } else if (Phaser.Input.Keyboard.JustDown(this.enterKey)) {
        this.inventoryUI.useItem(this.selectedInventorySlotIndex);
    }
    
    this.inventoryUI.updateSelection(this.selectedInventorySlotIndex);
  }
  handleShopInput() {
    // This is now called when this.currentUIFocus === 'shop'
    if (Phaser.Input.Keyboard.JustDown(this.cursors.down) || Phaser.Input.Keyboard.JustDown(this.wasd.S)) {
        this.selectedShopButtonIndex = (this.selectedShopButtonIndex + 1) % this.shopButtons.length;
        this.updateShopButtonSelection();
    } else if (Phaser.Input.Keyboard.JustDown(this.cursors.up) || Phaser.Input.Keyboard.JustDown(this.wasd.W)) {
        this.selectedShopButtonIndex = (this.selectedShopButtonIndex - 1 + this.shopButtons.length) % this.shopButtons.length;
        this.updateShopButtonSelection();
    } else if (Phaser.Input.Keyboard.JustDown(this.enterKey)) {
        const selectedButton = this.shopButtons[this.selectedShopButtonIndex];
        if (selectedButton && selectedButton.active) { // Check if the button is active (can be afforded)
            selectedButton.emit('pointerdown');
        }
    }
  }
  togglePause() {
    this.isPaused = !this.isPaused;
    if (this.isPaused) {
      this.physics.pause();
      this.tweens.pauseAll();
      this.selectedPauseItemIndex = 0;
      this.updatePauseMenuSelection();
      this.pauseMenuContainer.setVisible(true);
      this.currentUIFocus = 'pause';
    } else {
      this.physics.resume();
      this.tweens.resumeAll();
      this.pauseMenuContainer.setVisible(false);
      if (this.currentUIFocus === 'pause') {
        this.currentUIFocus = 'game';
      }
    }
  }
  createPauseMenu() {
    this.pauseMenuContainer = this.add.container(this.cameras.main.width / 2, this.cameras.main.height / 2)
      .setScrollFactor(0)
      .setDepth(3000)
      .setVisible(false);
    const bg = this.add.graphics();
    bg.fillStyle(0x000000, 0.7);
    bg.fillRoundedRect(-200, -150, 400, 350, 15);
    this.pauseMenuContainer.add(bg);
    const pausedText = this.add.text(0, -120, 'PAUSED', { 
        fontSize: '48px', 
        fill: '#FFFFFF', 
        fontFamily: '"Georgia", serif', 
        stroke: '#000000', 
        strokeThickness: 6 
    }).setOrigin(0.5);
    this.pauseMenuContainer.add(pausedText);
    const volumeText = this.add.text(0, -20, 'Music Volume', { 
        fontSize: '24px', 
        fill: '#FFFFFF', 
        fontFamily: '"Georgia", serif' 
    }).setOrigin(0.5);
    this.pauseMenuContainer.add(volumeText);
    const sliderWidth = 200;
    const sliderX = -sliderWidth / 2;
    const musicSliderY = 20;
    const musicSlider = this.createVolumeSlider('music', sliderX, musicSliderY, sliderWidth, (volume) => {
        if (this.backgroundMusic) {
            this.backgroundMusic.setVolume(volume);
        }
    });
    this.pauseMenuItems.push(musicSlider);
    const soundSliderY = 80;
    const soundSlider = this.createVolumeSlider('sound', sliderX, soundSliderY, sliderWidth, (volume) => {
        this.sound.setVolume(volume);
    });
    this.pauseMenuItems.push(soundSlider);
    // --- Buttons ---
    const resumeButton = this.createPauseButton('Resume (ESC)', 130, () => this.togglePause());
    this.pauseMenuContainer.add(resumeButton);
    this.pauseMenuItems.push({ type: 'button', gameObject: resumeButton });
    const instructionsButton = this.createPauseButton('Instructions', 180, () => this.toggleInstructionsMenu(true));
    this.pauseMenuContainer.add(instructionsButton);
    this.pauseMenuItems.push({ type: 'button', gameObject: instructionsButton });
    const restartButton = this.createPauseButton('Restart', 230, () => {
        if (this.backgroundMusic && this.backgroundMusic.isPlaying) {
            this.backgroundMusic.stop();
        }
        this.registry.remove('playerLives');
        this.scene.restart();
    });
    this.pauseMenuContainer.add(restartButton);
    this.pauseMenuItems.push({ type: 'button', gameObject: restartButton });
    
    // Set interactive area for the handle itself
  }
  handlePauseMenuInput() {
    if (Phaser.Input.Keyboard.JustDown(this.cursors.down) || Phaser.Input.Keyboard.JustDown(this.wasd.S)) {
        this.selectedPauseItemIndex = (this.selectedPauseItemIndex + 1) % this.pauseMenuItems.length;
        this.updatePauseMenuSelection();
    } else if (Phaser.Input.Keyboard.JustDown(this.cursors.up) || Phaser.Input.Keyboard.JustDown(this.wasd.W)) {
        this.selectedPauseItemIndex = (this.selectedPauseItemIndex - 1 + this.pauseMenuItems.length) % this.pauseMenuItems.length;
        this.updatePauseMenuSelection();
    }
    const selectedItem = this.pauseMenuItems[this.selectedPauseItemIndex];
    if (selectedItem.type === 'slider') {
        let volumeChange = 0;
        if (Phaser.Input.Keyboard.JustDown(this.cursors.left) || Phaser.Input.Keyboard.JustDown(this.wasd.A)) {
            volumeChange = -0.1;
        } else if (Phaser.Input.Keyboard.JustDown(this.cursors.right) || Phaser.Input.Keyboard.JustDown(this.wasd.D)) {
            volumeChange = 0.1;
        }
        if (volumeChange !== 0) {
            const handle = selectedItem.handle;
            const currentVolume = (handle.x - selectedItem.x) / selectedItem.width;
            const newVolume = Phaser.Math.Clamp(currentVolume + volumeChange, 0, 1);
            handle.x = selectedItem.x + selectedItem.width * newVolume;
            selectedItem.updateVolume(newVolume);
        }
    } else if (selectedItem.type === 'button') {
        if (Phaser.Input.Keyboard.JustDown(this.enterKey)) {
            selectedItem.gameObject.emit('pointerdown');
        }
    }
  }
  updatePauseMenuSelection() {
    this.pauseMenuItems.forEach((item, index) => {
        const isSelected = index === this.selectedPauseItemIndex;
        if (item.type === 'button') {
            item.gameObject.setBackgroundColor(isSelected ? '#6D4C41' : '#4E342E');
            item.gameObject.setScale(isSelected ? 1.1 : 1.0);
        } else if (item.type === 'slider') {
            item.handle.clear();
            item.handle.fillStyle(isSelected ? 0xFFFF00 : 0xFFFFFF, 1);
            item.handle.fillRect(-5, -5, 10, 20);
        }
    });
  }
  createVolumeSlider(type, x, y, width, onVolumeChange) {
    const label = type === 'music' ? 'Music Volume' : 'Game Sound';
    const text = this.add.text(x + width / 2, y - 20, label, {
      fontSize: '20px',
      fill: '#FFFFFF',
      fontFamily: '"Georgia", serif'
    }).setOrigin(0.5);
    this.pauseMenuContainer.add(text);
    const sliderTrack = this.add.graphics();
    sliderTrack.fillStyle(0x444444, 1);
    sliderTrack.fillRect(x, y, width, 10);
    this.pauseMenuContainer.add(sliderTrack);
    const initialVolume = type === 'music' ? (this.backgroundMusic?.volume ?? 0.5) : this.sound.volume;
    const handleX = x + width * initialVolume;
    const sliderHandle = this.add.graphics();
    sliderHandle.fillStyle(0xffffff, 1);
    sliderHandle.fillRect(-5, -5, 10, 20); // Center the handle graphic
    sliderHandle.setPosition(handleX, y + 5); // Position the handle container
    this.pauseMenuContainer.add(sliderHandle);
    const sliderZone = this.add.zone(x - 10, y - 10, width + 20, 30).setOrigin(0).setInteractive();
    this.pauseMenuContainer.add(sliderZone);
    
    sliderHandle.setInteractive(new Phaser.Geom.Rectangle(-5, -5, 10, 20), Phaser.Geom.Rectangle.Contains);
    this.input.setDraggable(sliderHandle);
    
    const updateVolume = (pointerX) => {
        const newX = Phaser.Math.Clamp(pointerX - this.pauseMenuContainer.x, x, x + width);
        sliderHandle.x = newX;
        const volume = (newX - x) / width;
        onVolumeChange(volume);
    };
    sliderHandle.on('drag', (pointer, dragX, dragY) => {
        updateVolume(pointer.x);
    });
    sliderZone.on('pointerdown', (pointer) => {
        updateVolume(pointer.x);
    });
    return {
        type: 'slider',
        handle: sliderHandle,
        updateVolume: onVolumeChange,
        x,
        y,
        width,
        gameObject: sliderHandle // For selection highlighting
    };
  }
  createPauseButton(text, y, callback) {
    const button = this.add.text(0, y, text, {
        fontSize: '28px',
        fill: '#FFFFFF',
        fontFamily: '"Georgia", serif',
        backgroundColor: '#4E342E',
        padding: { x: 20, y: 10 },
    }).setOrigin(0.5);
    
    // Set interactive area based on the button's dimensions
    button.setInteractive({
      useHandCursor: true
    });
    
    button.on('pointerover', () => button.setBackgroundColor('#6D4C41'));
    button.on('pointerout', () => button.setBackgroundColor('#4E342E'));
    button.on('pointerdown', callback);
    return button;
  }
  // This function is no longer needed as we now use direct dragging.
  // We'll keep it here but commented out in case we need it for another purpose later.
  /*
  updateVolumeFromPointer(pointer, sliderX, sliderWidth, sliderHandle) {
    const relativeX = pointer.x - this.pauseMenuContainer.x - sliderX;
    const volume = Phaser.Math.Clamp(relativeX / sliderWidth, 0, 1);
    
    if (this.backgroundMusic) {
      this.backgroundMusic.setVolume(volume);
    }
    
    sliderHandle.x = sliderX + (sliderWidth * volume);
  }
  */
  handleChatInput() {
    const spaceKey = this.wasd.SPACE;
    if (Phaser.Input.Keyboard.JustDown(spaceKey) && !this.chatManager.isListening) {
      // Find the closest NPC to talk to
      let closestNPC = null;
      let minDistance = this.npcSystem.chatDistance;
      this.npcSystem.npcs.getChildren().filter(npc => npc.isAlive).forEach(npc => {
        const distance = Phaser.Math.Distance.Between(npc.x, npc.y, this.player.sprite.x, this.player.sprite.y);
        if (distance < minDistance) {
          minDistance = distance;
          closestNPC = npc;
        }
      });
      if (closestNPC) {
        this.npcSystem.activeChatNPC = closestNPC;
        this.npcSystem.showListeningPrompt(this.npcSystem.activeChatNPC);
        this.uiManager.showChatBox();
        const shopGreeting = `Howdy! I've got Health Packs for ${this.shopItems.healthPack.cost}, Lassos for ${this.shopItems.lasso.cost}, an extra Life for ${this.shopItems.life.cost}, and a Speed Boost for ${this.shopItems.speedBoost.cost}. What'll it be?`;
        this.npcSystem.showNPCDialogue(closestNPC, shopGreeting);
        this.chatManager.startListening((message) => {
          this.handlePlayerChat(message);
        });
      }
    }
    if (Phaser.Input.Keyboard.JustUp(spaceKey) && this.chatManager.isListening) {
      this.chatManager.stopListening();
      if (this.npcSystem.activeChatNPC) {
        this.npcSystem.showChatPrompt(this.npcSystem.activeChatNPC);
      }
      // Hide the chat box after a delay if the conversation ends
      this.time.delayedCall(3000, () => {
        if (!this.chatManager.isListening && !this.chatManager.isSpeaking) {
          this.uiManager.hideChatBox();
        }
      });
    }
  }
  
  gameOver() {
    this.physics.pause();
    this.player.isAlive = false;
    // Stop the music on game over
    if (this.backgroundMusic && this.backgroundMusic.isPlaying) {
      this.backgroundMusic.stop();
    }
    
    // Use a delayed call to show game over text after animation
    this.time.delayedCall(1000, () => {
        const centerX = this.cameras.main.width / 2;
        const centerY = this.cameras.main.height / 2;
        
        const gameOverText = this.add.text(centerX, centerY - 50, 'GAME OVER', {
          fontSize: '64px', fill: '#FF0000', fontStyle: 'bold', stroke: '#000000', strokeThickness: 8
        }).setOrigin(0.5).setScrollFactor(0).setDepth(2000);
        
        const restartText = this.add.text(centerX, centerY + 20, 'Click to Restart', {
          fontSize: '32px', fill: '#FFFFFF', stroke: '#000000', strokeThickness: 4
        }).setOrigin(0.5).setScrollFactor(0).setDepth(2000);
        
        this.input.once('pointerdown', () => {
          // Restart the scene without passing any data to ensure a full reset.
          // The 'create' method will use default values when no data is provided.
          this.scene.restart({});
        });
    });
  }
  
  loseLife() {
    this.cameras.main.fade(500, 0, 0, 0, false, (camera, progress) => {
      if (progress === 1) {
        this.scene.restart({
          playerLives: this.player.lives,
          money: this.player.money,
          inventory: this.player.inventory,
          lassoCount: this.player.lassoCount,
          totalEnemiesCaptured: this.player.totalEnemiesCaptured
        });
      }
    });
  }
  
  dropLasso(x, y) {
    const lasso = this.lassos.create(x, y, 'lasso');
    lasso.setScale(0.1);
    lasso.body.isCircle = true;
    lasso.body.setCircle(lasso.width * 0.5);
  }
  
  collectLasso(playerSprite, lasso) {
    lasso.destroy();
    this.player.lassoCount++;
}
  collectHealthPack(playerSprite, pack) {
    pack.destroy();
    this.player.inventory.healthPacks++;
    // Add sound or visual feedback here
  }
  
  collectCoin(playerSprite, coin) {
    this.createCoinCollectEffect(coin.x, coin.y);
    coin.destroy();
    this.player.money++;
    const currentTime = this.time.now;
    if (currentTime > this.lastCoinSoundTime + 150) { // 150ms cooldown to prevent sound spam
        this.sound.play('chaChing', { volume: 1.0 });
        this.lastCoinSoundTime = currentTime;
    }
  }
  
  collectPowerUp(playerSprite, powerUp) {
    powerUp.destroy();
    this.player.activateFireRateBoost();
    this.sound.play('gunshot', { volume: 0.1, detune: -400 }); // Player power-up collect sound
  }
  
  dropPowerUp(x, y) {
    const powerUp = this.powerUps.create(x, y, 'playerBullet');
    powerUp.setScale(1); // Use original asset size
    powerUp.body.isCircle = true;
    powerUp.body.setCircle(powerUp.width * 0.5);
  }
  
  dropHealthPack(x, y) {
    const pack = this.healthPacks.create(x, y, 'healthPack');
    pack.setScale(0.1);
    pack.setDepth(11); // Ensure it renders above coins (which are at depth 10)
    pack.body.setCircle(pack.width * 0.5);
  }
  dropCoin(x, y) {
    const coin = this.coins.create(x, y, 'coin');
    coin.setScale(0.1);
    coin.setDepth(10);
    
    // Flash effect
    // Bouncy animation
    const startY = y;
    const peakY = y - Phaser.Math.Between(40, 80); // How high it bounces
    this.tweens.add({
        targets: coin,
        y: peakY,
        duration: 200,
        ease: 'Quad.easeOut',
        onComplete: () => {
            // Check if coin and scene still exist before starting next tween
            if (coin && coin.scene) { 
                this.tweens.add({
                    targets: coin,
                    y: startY,
                    duration: 350,
                    ease: 'Bounce.easeOut'
                });
            }
        }
    });
  }
  triggerDamageFlash() {
    this.damageFlash.setAlpha(0.3);
    this.tweens.add({
      targets: this.damageFlash,
      alpha: 0,
      duration: 250,
      ease: 'Cubic.easeOut'
    });
  }
  
  createImpactEffect(x, y) {
    const impact = this.add.circle(x, y, 8, 0xff0000);
    this.tweens.add({
      targets: impact,
      alpha: 0,
      scale: 2,
      duration: 200,
      onComplete: () => impact.destroy()
    });
  }
  
  createCoinCollectEffect(x, y) {
    // 1. Floating Score Text
    const moneyText = this.add.text(x, y, '+$1', {
      fontSize: '22px',
      fill: '#FFD700',
      fontFamily: '"Georgia", serif',
      stroke: '#000000',
      strokeThickness: 4,
    }).setOrigin(0.5).setDepth(5000);
    this.tweens.add({
      targets: moneyText,
      y: y - 50,
      alpha: 0,
      duration: 1000,
      ease: 'Cubic.easeOut',
      onComplete: () => {
        moneyText.destroy();
      }
    });
    // 2. Outward burst of sparkles
    const sparkles = this.add.particles(x, y, 'bulletTracer', {
        speed: { min: 100, max: 200 },
        angle: { min: 0, max: 360 },
        scale: { start: 0.25, end: 0 },
        lifespan: 500,
        quantity: 15,
        emitting: true,
        tint: [0xFFD700, 0xFFFF00, 0xFFA500],
        blendMode: 'ADD'
    });
    sparkles.setDepth(4999);
    // 3. One coin flies towards the UI
    const targetX = 50; // Approximate X position of money UI
    const targetY = 70; // Approximate Y position of money UI
    const worldPoint = this.cameras.main.getWorldPoint(targetX, targetY);
    const flyingCoin = this.add.image(x, y, 'coin').setScale(0.1).setDepth(5001);
    
    this.tweens.add({
      targets: flyingCoin,
      x: worldPoint.x,
      y: worldPoint.y,
      scale: 0.05,
      duration: 700,
      ease: 'Cubic.easeIn',
      onComplete: () => {
        flyingCoin.destroy();
        // Little flash on the UI to signify arrival
        if (this.moneyText) {
            // The issue might be that multiple tweens are created, interfering with each other.
            // We ensure only one scale tween runs on the money text at a time.
            if (!this.moneyText.isScaling) {
                this.moneyText.isScaling = true;
                const originalScale = this.moneyText.scale;
                this.tweens.add({
                    targets: this.moneyText,
                    scale: originalScale * 1.2,
                    duration: 150,
                    yoyo: true,
                    ease: 'Quad.easeInOut',
                    onComplete: () => {
                        this.moneyText.setScale(originalScale); // Explicitly reset scale
                        this.moneyText.isScaling = false;
                    }
                });
            }
        }
      }
    });
    
    this.time.delayedCall(600, () => {
        if(sparkles) sparkles.destroy();
    });
  }
  
  damageNPC(npcSprite, bullet) {
      if (bullet) {
        bullet.setActive(false).setVisible(false);
      }
      
      const npc = this.npcSystem.npcs.getChildren().find(n => n === npcSprite);
      // Only damage recruited NPCs
      if (npc && npc.isAlive && npc.isRecruited && npcSprite && npcSprite.body) {
        this.npcSystem.takeDamage(npcSprite, 15);
      }
      // Non-following NPCs are ignored by enemy bullets.
  }
  damagePlayer(playerSprite, bullet) {
    if (!bullet.active) return; // Prevent multi-hit from a single bullet
    if (bullet) {
      bullet.setActive(false).setVisible(false);
    }
    if (playerSprite && this.player) {
      this.player.takeDamage(15);
    }
  }
  damageHorse(horse, bullet) {
    if (!bullet.active || !horse.active) return;
    bullet.setActive(false).setVisible(false);
    
    const damage = 15; // Standard enemy bullet damage
    horse.takeDamage(damage);
  }
  handleFireDamage(enemySprite, fireZone) {
    const enemy = this.enemyManager.findEnemyBySprite(enemySprite);
    if (enemy && enemy.isAlive) { // The captured check is now handled in takeDirectDamage
      const now = this.time.now;
      const fireDamageCooldown = 500; // ms between damage ticks
      const fireDamage = 5;
      
      if (!enemy.lastFireDamageTime || now > enemy.lastFireDamageTime + fireDamageCooldown) {
        enemy.lastFireDamageTime = now;
        this.enemyManager.takeDirectDamage(enemy, fireDamage);
        
        // Visual feedback for fire damage - will not apply to captured enemies due to new checks
        if (!enemy.isCaptured) {
            enemy.sprite.setTint(0xFF8C00); // Orange tint
            this.time.delayedCall(150, () => {
                if (enemy.isAlive && !enemy.isCaptured) {
                   enemy.sprite.clearTint();
                }
            });
        }
      }
    }
  }
  
  createFireArea(x, y) {
      const fireZone = this.add.zone(x, y, 150, 150);
      this.physics.world.enable(fireZone);
      fireZone.body.setAllowGravity(false);
      fireZone.body.moves = false;
      this.fireAreas.add(fireZone);
      // Visual effect placeholder: You can add a static sprite or a tint effect here
      const fireVisual = this.add.graphics();
      fireVisual.fillStyle(0xFF8C00, 0.3);
      fireVisual.fillCircle(x, y, 75);
      
      this.time.delayedCall(5000, () => {
          this.fireAreas.remove(fireZone, true, true);
          fireVisual.destroy();
      });
  }
  handlePlayerChat(message) {
    const lowerMessage = message.toLowerCase();
    const npc = this.npcSystem.activeChatNPC;
    if (!npc) return;
    // Check for purchase intent first
    const buyHealthKeywords = ["health", "buy health", "byhealth", "by help", "my help"];
    const buyLassoKeywords = ["lasso", "buy lasso"];
    const buyLifeKeywords = ["life", "extra life", "buy life"];
    const buySpeedKeywords = ["speed", "boost", "speed boost", "buy speed boost"];
    if (buyHealthKeywords.some(keyword => lowerMessage.includes(keyword))) {
        const resultMessage = this.handlePurchase('healthPack');
        this.npcSystem.showNPCDialogue(npc, resultMessage);
    } else if (buyLassoKeywords.some(keyword => lowerMessage.includes(keyword))) {
        const resultMessage = this.handlePurchase('lasso');
        this.npcSystem.showNPCDialogue(npc, resultMessage);
    } else if (buyLifeKeywords.some(keyword => lowerMessage.includes(keyword))) {
        const resultMessage = this.handlePurchase('life');
        this.npcSystem.showNPCDialogue(npc, resultMessage);
    } else if (buySpeedKeywords.some(keyword => lowerMessage.includes(keyword))) {
        const resultMessage = this.handlePurchase('speedBoost');
        this.npcSystem.showNPCDialogue(npc, resultMessage);
    } else {
        // If not a purchase, pass to regular AI response
        this.npcSystem.sendMessage(message);
    }
  }
  
  handlePurchase(itemKey) {
    const item = this.shopItems[itemKey];
    if (!item) return "What in tarnation is that?";
    if (this.player.money >= item.cost) {
      this.player.money -= item.cost;
      
      switch(itemKey) {
        case 'healthPack':
          this.player.inventory.healthPacks++;
          break;
        case 'lasso':
          this.player.lassoCount++;
          break;
        case 'life':
          this.player.lives++;
          break;
        case 'speedBoost':
          this.player.activateSpeedBoost(() => {
              this.startSpeedBoostTimer(10);
          });
          break;
      }
      
      this.sound.play('chaChing', { volume: 0.6 });
      this.updatePlayerStatusUI(); // Immediately reflect the change in money
      this.updateShopButtonsState();
      return `Got it. One ${item.name} for you. That'll be ${item.cost} coin.`;
    } else {
      return `Looks like you're a bit short on coin for that, partner. You need ${item.cost}.`;
    }
  }
  createPlayerStatusUI() {
    const x = 20;
    const y = 20;
    const iconSize = 30;
    const spacing = 35;
    const textOffsetX = iconSize + 10;
    const textStyle = { 
        fontFamily: '"Georgia", serif',
        fontSize: '24px', 
        fontStyle: 'bold',
        stroke: '#4E342E',
        strokeThickness: 4
    };
    // UI Background Panel
    const bgWidth = 240;
    const bgHeight = 285;
    const uiPanel = this.add.graphics().setScrollFactor(0).setDepth(1998);
    uiPanel.fillStyle(0x211A16, 0.85); // Dark, semi-transparent leather color
    uiPanel.fillRoundedRect(x - 10, y - 10, bgWidth, bgHeight, 10);
    uiPanel.lineStyle(3, 0x4E342E, 1); // Dark brown border
    uiPanel.strokeRoundedRect(x - 10, y - 10, bgWidth, bgHeight, 10);
    // Health Bar
    this.healthBarBg = this.add.graphics().setScrollFactor(0).setDepth(1999);
    this.healthBar = this.add.graphics().setScrollFactor(0).setDepth(2000);
    this.healthBarBg.fillStyle(0x8B0000, 1); // Dark Red background
    this.healthBarBg.fillRect(x, y, 220, 25);
    // --- Stats ---
    const startY = y + spacing + 10;
    this.add.image(x, startY, 'coin').setDisplaySize(iconSize, iconSize).setOrigin(0, 0.5).setScrollFactor(0).setDepth(2000);
    this.moneyText = this.add.text(x + textOffsetX, startY, `Money: `, textStyle).setOrigin(0, 0.5).setScrollFactor(0).setDepth(2000);
    
    this.add.image(x, startY + spacing, 'playerRanger').setDisplaySize(iconSize, iconSize).setOrigin(0, 0.5).setScrollFactor(0).setDepth(2000);
    this.livesText = this.add.text(x + textOffsetX, startY + spacing, `Lives: `, textStyle).setOrigin(0, 0.5).setScrollFactor(0).setDepth(2000);
    
    // Make whip icon bigger
    this.add.image(x, startY + spacing * 2, 'lasso').setDisplaySize(iconSize + 5, iconSize + 5).setOrigin(0, 0.5).setScrollFactor(0).setDepth(2000);
    this.lassoCountText = this.add.text(x + textOffsetX, startY + spacing * 2, `Lassos: `, textStyle).setOrigin(0, 0.5).setScrollFactor(0).setDepth(2000);
    
    // Speed Boost UI (initially hidden)
    this.speedBoostIcon = this.add.image(x, startY + spacing * 3, 'speedBoostIcon').setDisplaySize(iconSize, iconSize).setOrigin(0, 0.5).setScrollFactor(0).setDepth(2000).setVisible(false);
    this.speedBoostText = this.add.text(x + textOffsetX, startY + spacing * 3, ``, textStyle).setOrigin(0, 0.5).setScrollFactor(0).setDepth(2000).setVisible(false);
    
    // Health Packs UI
    this.add.image(x, startY + spacing * 4, 'healthPack').setDisplaySize(iconSize, iconSize).setOrigin(0, 0.5).setScrollFactor(0).setDepth(2000);
    this.healthPacksText = this.add.text(x + textOffsetX, startY + spacing * 4, ``, textStyle).setOrigin(0, 0.5).setScrollFactor(0).setDepth(2000);
    this.add.image(x, startY + spacing * 5, 'capturedBandit').setDisplaySize(iconSize, iconSize).setOrigin(0, 0.5).setScrollFactor(0).setDepth(2000);
    this.capturedText = this.add.text(x + textOffsetX, startY + spacing * 5, ``, textStyle).setOrigin(0, 0.5).setScrollFactor(0).setDepth(2000);
    this.totalCapturedText = this.add.text(x + textOffsetX, startY + spacing * 6, ``, textStyle).setOrigin(0, 0.5).setScrollFactor(0).setDepth(2000);
    
    // Fire Rate Boost UI (initially hidden)
    this.fireRateBoostText = this.add.text(x, startY + spacing * 7, 'FIRE RATE UP!', textStyle)
      .setOrigin(0, 0.5)
      .setScrollFactor(0)
      .setDepth(2000)
      .setVisible(false);
    
    // Apply gradient to all text elements
    const textElements = [this.moneyText, this.livesText, this.lassoCountText, this.speedBoostText, this.healthPacksText, this.capturedText, this.totalCapturedText, this.fireRateBoostText];
    textElements.forEach(text => {
      const gradient = text.context.createLinearGradient(0, 0, 0, text.height);
      gradient.addColorStop(0, '#FFD700'); // Gold
      gradient.addColorStop(1, '#A0522D'); // Sienna (brown)
      text.setFill(gradient);
    });
    this.fireRateBoostText.setFill('#00FFFF'); // Special color for fire rate boost
  }
  startSpeedBoostTimer(duration) {
      this.speedBoostIcon.setVisible(true);
      this.speedBoostText.setVisible(true);
      if (this.speedBoostTimer) {
          this.speedBoostTimer.remove(false);
      }
      this.speedBoostTimer = this.time.addEvent({
          delay: 1000,
          callback: () => {
              duration--;
              this.speedBoostText.setText(`Speed Boost: ${duration}s`);
              if (duration <= 0) {
                  this.speedBoostIcon.setVisible(false);
                  this.speedBoostText.setVisible(false);
                  this.speedBoostTimer.remove(false);
                  this.speedBoostTimer = null;
              }
          },
          callbackScope: this,
          loop: true
      });
      this.speedBoostText.setText(`Speed Boost: ${duration}s`);
  }
  updatePlayerStatusUI() {
    if (!this.player || !this.player.sprite.active) return;
    this.moneyText.setText(`Money: ${this.player.money}`);
    this.livesText.setText(`Lives: ${this.player.lives}`);
    this.lassoCountText.setText(`Lassos: ${this.player.lassoCount}`);
    this.healthPacksText.setText(`Health Packs: ${this.player.inventory.healthPacks}`);
    this.capturedText.setText(`Captured: ${this.player.capturedEnemies.length}`);
    this.totalCapturedText.setText(`Turned In: ${this.player.totalEnemiesCaptured}`);
    // Update Fire Rate Boost UI
    if (this.fireRateBoostText) {
        this.fireRateBoostText.setVisible(this.player.fireRateBoostActive);
    }
    
    // Update Health Bar
    this.healthBar.clear();
    const healthPercentage = this.player.health / this.player.maxHealth;
    this.healthBar.fillStyle(0x00FF00, 1); // Green
    this.healthBar.fillRect(20, 20, 220 * healthPercentage, 25);
    this.handleReviveInput();
    this.updateMobileButtonStates();
  }
  handleHorseInteraction() {
    if (Phaser.Input.Keyboard.JustDown(this.wasd.O)) {
      if (this.player.onHorse) {
        this.dismountHorse();
      } else {
        this.mountHorse();
      }
    }
  }
  mountHorse() {
    let closestHorse = null;
    let minDistance = 150; // Max distance to mount
    this.horses.getChildren().forEach(horse => {
      const distance = Phaser.Math.Distance.Between(this.player.sprite.x, this.player.sprite.y, horse.x, horse.y);
      if (distance < minDistance) {
        minDistance = distance;
        closestHorse = horse;
      }
    });
    if (closestHorse) {
      this.player.onHorse = true;
      this.player.speed = 450; // Faster speed on horse
      this.player.sprite.setTexture('playerOnHorse');
      this.player.sprite.setScale(0.35);
      // Remove the horse from the scene
      this.horses.remove(closestHorse, true, true);
    }
  }
  dismountHorse() {
    this.player.onHorse = false;
    this.player.speed = 250; // Revert to normal speed
    this.player.sprite.setTexture('playerRanger'); // Revert to original sprite
    this.player.sprite.setScale(0.28);
    // Spawn a new horse where the player dismounted
    const horseX = this.player.sprite.x;
    const horseY = this.player.sprite.y;
    this.horses.get(horseX, horseY);
  }
  checkJailDropOff() {
    if (!this.player || !this.player.sprite.active) return;
    
    const inDropOffZone = this.jailhouse && Phaser.Geom.Intersects.RectangleToRectangle(this.player.sprite.getBounds(), this.jailhouse.turnInZone.getBounds());
    if (inDropOffZone && !this.isShopOpen) {
      // Automatically turn in captives
      if (this.player.capturedEnemies.length > 0) {
        this.turnInCaptives();
      }
      // Show shop prompt only if no captives are being turned in
      if (this.player.capturedEnemies.length === 0) {
        let promptText = 'Click to Purchase from Marketplace';
        this.turnInPrompt.setText(promptText).setVisible(true);
      }
    } else {
      if (this.turnInPrompt.visible) {
        this.turnInPrompt.setVisible(false);
      }
    }
  }
  turnInCaptives() {
    const captivesCount = this.player.capturedEnemies.length;
    if (captivesCount === 0) return;
    const rewardPerCaptive = 25;
    const totalReward = captivesCount * rewardPerCaptive;
    this.player.money += totalReward;
    this.player.totalEnemiesCaptured += captivesCount;
    // Play sound effect
    this.sound.play('jail_door_close', { volume: 0.8 });
    // Animate captives walking into jail
    const jailDoorX = this.jailhouse.sprite.x;
    const jailDoorY = this.jailhouse.sprite.y + 30; // Position adjusted to door level
    this.player.capturedEnemies.forEach(enemy => {
      // Disable their AI/following behavior
      enemy.isFollowingPlayer = false;
      // Clean up indicators immediately
      if (enemy.ropeVisual) enemy.ropeVisual.destroy(); // This line might be redundant now but is safe to keep
      if (enemy.followingIndicator) enemy.followingIndicator.destroy();
      this.tweens.add({
        targets: enemy.sprite,
        x: jailDoorX,
        y: jailDoorY,
        duration: 800, // Time to walk to the door
        ease: 'Power2',
        onComplete: () => {
          // Fade out and destroy
          this.tweens.add({
            targets: enemy.sprite,
            alpha: 0,
            duration: 200,
            onComplete: () => {
              enemy.sprite.destroy();
            }
          });
        }
      });
    });
    // Clear the list of captives
    this.player.capturedEnemies = [];
    if (this.ropeGraphics) {
        this.ropeGraphics.clear();
    }
    this.turnInPrompt.setVisible(false);
    this.updatePlayerStatusUI();
    // Display reward message
    this.displayTurnInMessage(captivesCount, totalReward);
  }
  displayTurnInMessage(count, reward) {
    const messageText = `Turned in ${count} bandit${count > 1 ? 's' : ''}\n+$${reward}`;
    const messageStyle = {
      fontSize: '28px',
      fill: '#FFD700',
      fontFamily: '"Georgia", serif',
      backgroundColor: 'rgba(0,0,0,0.8)',
      padding: { x: 20, y: 15 },
      align: 'center',
      stroke: '#000000',
      strokeThickness: 4
    };
    const turnInMessage = this.add.text(this.cameras.main.width / 2, this.cameras.main.height / 2, messageText, messageStyle)
      .setOrigin(0.5)
      .setScrollFactor(0)
      .setDepth(5000)
      .setAlpha(0);
    // Fade in and then out
    this.tweens.add({
      targets: turnInMessage,
      alpha: 1,
      duration: 400,
      ease: 'Power2',
      yoyo: true,
      hold: 2000, // Hold message for 2 seconds
      onComplete: () => {
        turnInMessage.destroy();
      }
    });
  }
  createShopMenu() {
    this.shopMenuContainer = this.add.container(this.cameras.main.width / 2, this.cameras.main.height / 2)
      .setScrollFactor(0)
      .setDepth(4000)
      .setVisible(false);
      
    const bg = this.add.graphics();
    bg.fillStyle(0x000000, 0.9);
    bg.fillRoundedRect(-250, -200, 500, 400, 15);
    bg.lineStyle(4, 0x4E342E, 1);
    bg.strokeRoundedRect(-250, -200, 500, 400, 15);
    this.shopMenuContainer.add(bg);
    
    const title = this.add.text(0, -160, 'Jailhouse Shop', {
      fontSize: '36px',
      fill: '#FFD700',
      fontFamily: '"Georgia", serif',
      stroke: '#000',
      strokeThickness: 5
    }).setOrigin(0.5);
    this.shopMenuContainer.add(title);
    
    // Close button
    const closeButton = this.add.text(230, -180, 'X (ESC)', {
        fontSize: '24px',
        fill: '#FFFFFF',
        backgroundColor: '#A0522D',
        padding: {x: 10, y: 5}
    }).setOrigin(0.5).setInteractive({ useHandCursor: true });
    
    closeButton.on('pointerdown', () => this.toggleShopMenu());
    closeButton.on('pointerover', () => closeButton.setBackgroundColor('#C4743C'));
    closeButton.on('pointerout', () => closeButton.setBackgroundColor('#A0522D'));
    this.shopMenuContainer.add(closeButton);
    this.shopCloseButton = closeButton; // Store reference to close button
    
    const itemStyle = { fontSize: '24px', fill: '#FFFFFF', fontFamily: '"Georgia", serif' };
    const costStyle = { fontSize: '22px', fill: '#FFD700', fontFamily: '"Georgia", serif' };
    const items = [
        { key: 'healthPack', name: 'Health Pack', cost: this.shopItems.healthPack.cost, icon: 'healthPack' },
        { key: 'lasso', name: 'Lasso', cost: this.shopItems.lasso.cost, icon: 'lasso' },
        { key: 'life', name: 'Extra Life', cost: this.shopItems.life.cost, icon: 'playerRanger' },
        { key: 'speedBoost', name: 'Speed Boost', cost: this.shopItems.speedBoost.cost, icon: 'speedBoostIcon' }
    ];
    let yPos = -90;
    items.forEach(item => {
        this.createShopItem(item, yPos, itemStyle, costStyle);
        yPos += 80;
    });
  }
  createShopItem(item, y, itemStyle, costStyle) {
    const itemContainer = this.add.container(0, y);
    
    // Icon
    const icon = this.add.image(-200, 0, item.icon).setDisplaySize(50, 50);
    itemContainer.add(icon);
    
    // Text
    const nameText = this.add.text(-150, -15, item.name, itemStyle).setOrigin(0, 0.5);
    const costText = this.add.text(-150, 15, `Cost: ${item.cost}`, costStyle).setOrigin(0, 0.5);
    itemContainer.add([nameText, costText]);
    
    // Buy Button
    const buyButton = this.add.text(160, 0, 'BUY', {
        fontSize: '28px',
        fill: '#FFFFFF',
        backgroundColor: '#4CAF50', // Green for buy
        padding: { x: 20, y: 10 },
        fontFamily: '"Georgia", serif'
    }).setOrigin(0.5);
    
    buyButton.setData('itemKey', item.key);
    buyButton.setInteractive({ useHandCursor: true });
    buyButton.on('pointerdown', () => {
        const itemKey = buyButton.getData('itemKey');
        const item = this.shopItems[itemKey];
        if (this.player.money >= item.cost) {
            const resultMessage = this.handlePurchase(itemKey);
            this.displayShopMessage(resultMessage, resultMessage.startsWith('Got it'));
        } else {
            this.displayShopMessage("You can't afford that, partner.", false);
        }
    });
    
    buyButton.on('pointerover', () => {
        if (this.player.money >= item.cost) {
            buyButton.setBackgroundColor('#66BB6A');
        }
    });
    buyButton.on('pointerout', () => {
        if (this.player.money >= item.cost) {
            buyButton.setBackgroundColor('#4CAF50');
        }
    });
    
    itemContainer.add(buyButton);
    this.shopButtons.push(buyButton);
    this.shopMenuContainer.add(itemContainer);
  }
  // This function is no longer needed as the direct pointerdown events on buttons now work
  // when the game is paused. Leaving it here commented out for reference.
  /*
  handleShopMenuClicks(pointer) {
    ...
  }
  */
  
  displayShopMessage(message, isSuccess) {
      if (this.shopMessage) {
          this.shopMessage.destroy();
      }
      const messageStyle = {
          fontSize: '20px',
          fill: isSuccess ? '#4CAF50' : '#F44336', // Green for success, red for failure
          fontFamily: '"Georgia", serif',
          backgroundColor: 'rgba(0,0,0,0.8)',
          padding: { x: 10, y: 5 }
      };
      
      this.shopMessage = this.add.text(0, 160, message, messageStyle).setOrigin(0.5);
      this.shopMenuContainer.add(this.shopMessage);
      
      this.time.delayedCall(2000, () => {
          if (this.shopMessage) {
              this.shopMessage.destroy();
              this.shopMessage = null;
          }
      });
  }
  
  toggleShopMenu() {
      this.isShopOpen = !this.isShopOpen;
      this.shopMenuContainer.setVisible(this.isShopOpen);
      
      if (this.isShopOpen) {
          this.physics.pause();
          this.tweens.pauseAll();
          if (this.turnInPrompt) this.turnInPrompt.setVisible(false);
          this.updateShopButtonsState();
          this.selectedShopButtonIndex = 0;
          this.updateShopButtonSelection();
          this.currentUIFocus = 'shop';
      } else {
          if (this.shopMessage) {
              this.shopMessage.destroy();
              this.shopMessage = null;
          }
          this.physics.resume();
          this.tweens.resumeAll();
          this.checkJailDropOff();
          if (this.currentUIFocus === 'shop') {
            this.currentUIFocus = 'game';
          }
      }
  }
  updateShopButtonsState() {
    this.shopButtons.forEach(button => {
        const itemKey = button.getData('itemKey');
        const item = this.shopItems[itemKey];
        if (!item) return;
        const canAfford = this.player.money >= item.cost;
        
        if (canAfford) {
            button.setInteractive({ useHandCursor: true });
            button.setBackgroundColor('#4CAF50');
            button.setAlpha(1.0);
        } else {
            button.disableInteractive();
            button.setBackgroundColor('#5D4037'); // A darker, browner gray
            button.setAlpha(0.6);
        }
    });
  }
  updateShopButtonSelection() {
      this.shopButtons.forEach((button, index) => {
          // Only update style for affordable buttons, keep others disabled-looking
          const itemKey = button.getData('itemKey');
          const item = this.shopItems[itemKey];
          const canAfford = this.player.money >= item.cost;
          if (canAfford) {
              if (index === this.selectedShopButtonIndex) {
                  // Selected style
                  button.setBackgroundColor('#66BB6A'); // A lighter green to show selection
                  button.setScale(1.05);
              } else {
                  // Default style for affordable items
                  button.setBackgroundColor('#4CAF50');
                  button.setScale(1.0);
              }
          } else {
              // Keep disabled style and scale
              button.setScale(1.0);
          }
      });
  }
  createInstructionsMenu() {
    this.instructionsMenuContainer = this.add.container(this.cameras.main.width / 2, this.cameras.main.height / 2)
      .setScrollFactor(0)
      .setDepth(3500) // Higher depth to appear over pause menu
      .setVisible(false);
      
    const bg = this.add.graphics();
    bg.fillStyle(0x000000, 0.95);
    bg.fillRoundedRect(-300, -250, 600, 500, 15);
    bg.lineStyle(4, 0x4E342E, 1);
    bg.strokeRoundedRect(-300, -250, 600, 500, 15);
    this.instructionsMenuContainer.add(bg);
    
    const title = this.add.text(0, -220, 'How to Play', {
      fontSize: '36px',
      fill: '#FFD700',
      fontFamily: '"Georgia", serif',
      stroke: '#000',
      strokeThickness: 5
    }).setOrigin(0.5);
    this.instructionsMenuContainer.add(title);
    
    const backButton = this.createPauseButton('Back', 210, () => this.toggleInstructionsMenu(false));
    this.instructionsMenuContainer.add(backButton);
    
    const instructionsText = `
[h]Movement & Combat[/h]
- [c]Move Player:[/c] W, A, S, D
- [c]Aim:[/c] Mouse Cursor
- [c]Shoot:[/c] Left-Click
[h]Capturing Bandits[/h]
    - [c]Capture:[/c] Get close to a bandit and press [k]F[/k]. Requires a lasso.
    - [c]Turn In:[/c] Walk into the Jailhouse building with a captive.
    - [c]Get Lassos:[/c] Defeat enemies or buy them at the shop.
[h]Items & Interaction[/h]
    - [c]Use Health Pack:[/c] Press [k]H[/k].
- [c]Mount/Dismount Horse:[/c] Press [k]O[/k].
- [c]Open Shop:[/c] Click the prompt at the Jailhouse.
- [c]Close Shop:[/c] Click the 'X' button or press [k]X[/k].
- [c]Talk to NPCs:[/c] Press [k]SPACE[/k].
[h]Game Menus[/h]
- [c]Pause Game:[/c] Press [k]P[/k].
- [c]Toggle Minimap Size:[/c] Press [k]T[/k].
- [c]Cycle UI Focus:[/c] Press [k]TAB[/k].
`;
    
    this.createFormattedText(instructionsText, -280, -180);
  }
  
  createFormattedText(text, startX, startY) {
    const lines = text.trim().split('\n');
    let y = startY;
    const headingStyle = { fontSize: '22px', fill: '#FFD700', fontFamily: '"Georgia", serif', fontStyle: 'bold' };
    const contentStyle = { fontSize: '18px', fill: '#FFFFFF', fontFamily: '"Georgia", serif' };
    const keyStyle = { fontSize: '18px', fill: '#FFD700', fontFamily: '"Georgia", serif' };
    lines.forEach(line => {
      if (line.startsWith('[h]')) {
        const content = line.substring(3, line.length - 4);
        const heading = this.add.text(0, y, content, headingStyle).setOrigin(0.5, 0);
        this.instructionsMenuContainer.add(heading);
        y += 35;
      } else if (line.trim()) {
        const parts = line.split(/(\[[kc]\].*?\[\/[kc]\])/g).filter(p => p);
        let x = startX;
        parts.forEach(part => {
          let content, style;
          if (part.startsWith('[c]')) {
            content = part.substring(3, part.length - 4);
            style = { ...contentStyle, fontStyle: 'italic' };
          } else if (part.startsWith('[k]')) {
            content = part.substring(3, part.length - 4);
            style = keyStyle;
          } else {
            content = part;
            style = contentStyle;
          }
          const textObj = this.add.text(x, y, content, style).setOrigin(0, 0);
          this.instructionsMenuContainer.add(textObj);
          x += textObj.width;
        });
        y += 28;
      } else {
        y += 10; // Extra space for empty lines
      }
    });
  }
  toggleInstructionsMenu(show) {
      if (show) {
          this.pauseMenuContainer.setVisible(false);
          this.instructionsMenuContainer.setVisible(true);
      } else {
          this.instructionsMenuContainer.setVisible(false);
          this.pauseMenuContainer.setVisible(true);
      }
  }
  handleCommandClick(pointer) {
    if (!this.isCommandMode) return;
    const worldPoint = this.cameras.main.getWorldPoint(pointer.x, pointer.y);
    // If an NPC is already selected, this click is the move command.
    if (this.selectedNPCForCommand) {
      const npc = this.selectedNPCForCommand;
      
      // Create a destination marker on the ground
      const groundMarker = this.add.sprite(worldPoint.x, worldPoint.y, 'command_arrow')
        .setScale(0.1)
        .setAlpha(0.7)
        .setDepth(1); // Ensure it's below characters
      // Add a tween to fade it out and destroy it
      this.tweens.add({
        targets: groundMarker,
        alpha: 0,
        duration: 3000,
        ease: 'Power2',
        onComplete: () => {
          groundMarker.destroy();
        }
      });
      
      // Tell the NPC system to move this NPC
      this.npcSystem.commandMoveTo(npc, worldPoint);
      
      // Hide arrow and reset command state
      this.commandTargetSprite.setVisible(false);
      this.input.setDefaultCursor('crosshair');
      this.commandPromptText.setVisible(false);
      
      // Reset for the next command
      this.selectedNPCForCommand = null;
      this.isCommandMode = false;
    } else { // Otherwise, this click is to select an NPC.
      const selectableNPCs = this.npcSystem.getNPCSprites().filter(npc => npc.isRecruited && npc.isAlive);
      for (const npc of selectableNPCs) {
          if (npc.getBounds().contains(worldPoint.x, worldPoint.y)) {
              this.selectedNPCForCommand = npc;
              
              // Visual feedback for selection
              if (npc.nameTag) {
                  this.tweens.add({
                      targets: npc.nameTag,
                      scale: 1.5,
                      duration: 150,
                      yoyo: true,
                      ease: 'Power1'
                  });
              }
              this.commandPromptText.setText(`Selected ${npc.nameTag?.text || 'ally'}. Click a location to guard.`);
              this.commandTargetSprite.setVisible(true); // Show the arrow
              break; 
          }
      }
    }
  }
  toggleCommandMode() {
    this.isCommandMode = !this.isCommandMode;
    if (this.isCommandMode) {
      this.input.setDefaultCursor('pointer');
      this.commandPromptText.setText('COMMAND MODE: Click on a recruited ally to command them.').setVisible(true);
      // We will add logic here to make NPCs selectable.
    } else {
      this.input.setDefaultCursor('crosshair');
      this.commandPromptText.setVisible(false);
      this.selectedNPCForCommand = null;
      this.commandTargetSprite.setVisible(false);
    }
  }
  createCommandUI() {
    this.commandPromptText = this.add.text(this.cameras.main.width / 2, 30, '', {
        fontFamily: '"Georgia", serif',
        fontSize: '24px',
        fill: '#FFD700',
        align: 'center',
        backgroundColor: 'rgba(0,0,0,0.7)',
        padding: { x: 15, y: 10 },
        stroke: '#000000',
        strokeThickness: 3
    }).setOrigin(0.5, 0).setScrollFactor(0).setDepth(2500).setVisible(false);
  }
  
  // Method to automatically equip recruited NPCs with auto guns
  equipRecruitedNPCWithAutoGun(npc) {
    if (!npc || !npc.isRecruited || !npc.isAlive) return;
    
    // Only equip if the auto gun system is available and NPC doesn't already have one
    if (this.autoGunSystem && !this.autoGunSystem.npcAutoGuns.has(npc)) {
      this.autoGunSystem.equipAutoGun(npc);
      
      // Show recruitment message with auto gun notification
      const recruitmentMessages = [
        `${npc.name || 'Ally'} joined Young Zealous and received an auto gun!`,
        `Welcome to the team, ${npc.name || 'partner'}! Auto gun equipped.`,
        `${npc.name || 'New ally'} is now armed with advanced weaponry!`,
        `Young Zealous welcomes ${npc.name || 'you'}! Auto targeting system online.`
      ];
      
      const message = Phaser.Math.RND.pick(recruitmentMessages);
      this.npcSystem.showDialogue(npc, message, 4000);
      
      // Visual celebration effect - Removed as requested
      // this.createRecruitmentCelebration(npc.x, npc.y);
      
      // Play recruitment sound
      if (this.sound.get('gunshot')) {
        this.sound.play('gunshot', {
          volume: 0.1,
          detune: -600, // Lower pitch for celebration
          delay: 0.2
        });
      }
      
      console.log(`Auto gun equipped for recruited NPC: ${npc.name || 'Unknown'}`);
    }
  }
  
  // Visual effect for NPC recruitment celebration
  createRecruitmentCelebration(x, y) {
    // Create celebratory particle effect
    const celebrationParticles = this.add.particles(x, y, 'croppedBullet', {
      speed: { min: 100, max: 300 },
      angle: { min: 0, max: 360 },
      scale: { start: 0.08, end: 0 },
      tint: [0x00FFFF, 0xFFD700, 0x00FF00, 0xFFFFFF], // Cyan, gold, green, white
      blendMode: 'ADD',
      lifespan: 1000,
      quantity: 15,
      emitting: true
    });
    
    // Create brief screen flash for nearby recruitment
    const distanceToPlayer = Phaser.Math.Distance.Between(
      x, y,
      this.player.sprite.x, this.player.sprite.y
    );
    
    if (distanceToPlayer < 400) {
      const flashOverlay = this.add.rectangle(0, 0, this.scale.width, this.scale.height, 0x00FFFF, 0.1);
      flashOverlay.setScrollFactor(0).setDepth(1600);
      
      this.tweens.add({
        targets: flashOverlay,
        alpha: 0,
        duration: 300,
        ease: 'Cubic.easeOut',
        onComplete: () => flashOverlay.destroy()
      });
    }
    
    // Clean up particles
    this.time.delayedCall(1200, () => {
      if (celebrationParticles) {
        celebrationParticles.destroy();
      }
    });
  }
  updateMobileButtonStates() {
    if (this.sys.game.device.os.desktop) return;
    // Health Button State
    const hasHealthPacks = this.player && this.player.inventory.healthPacks > 0;
    if (this.healthButton) {
      if (hasHealthPacks) {
        this.healthButton.setAlpha(1);
        this.healthButtonIcon.setAlpha(1);
        this.healthButton.setInteractive();
      } else {
        this.healthButton.setAlpha(0.3);
        this.healthButtonIcon.setAlpha(0.3);
        this.healthButton.disableInteractive();
      }
    }
    // Lasso Button State
    const hasLassos = this.player && this.player.lassoCount > 0;
     if (this.lassoButton) {
      if (hasLassos && !this.isLassoReady) {
        this.lassoButton.setAlpha(1);
        this.lassoButtonIcon.setAlpha(1);
        this.lassoButton.setInteractive();
      } else {
        this.lassoButton.setAlpha(0.3);
        this.lassoButtonIcon.setAlpha(0.3);
        this.lassoButton.disableInteractive();
      }
    }
  }
  handleGlobalInput() {
    // --- Global Key Presses that can happen anytime ---
    
    // Toggle Pause
    if (Phaser.Input.Keyboard.JustDown(this.wasd.P)) {
      this.togglePause();
    }
    
    // Toggle Inventory
    if (Phaser.Input.Keyboard.JustDown(this.wasd.I)) {
      this.inventoryUI.toggle();
      if (this.inventoryUI.isOpen) {
        this.currentUIFocus = 'inventory';
        this.selectedInventorySlotIndex = 0;
        this.inventoryUI.updateSelection(this.selectedInventorySlotIndex);
        // Pause game logic while inventory is open
        this.physics.pause();
        this.tweens.pauseAll();
      } else {
        this.currentUIFocus = 'game';
        this.physics.resume();
        this.tweens.resumeAll();
      }
    }
    
    // Close menus with ESC
    if (Phaser.Input.Keyboard.JustDown(this.escKey)) {
        if (this.isShopOpen) this.toggleShopMenu();
        else if (this.isPaused) this.togglePause();
        else if (this.inventoryUI.isOpen) this.inventoryUI.toggle();
    }
    // Toggle Minimap
    if (Phaser.Input.Keyboard.JustDown(this.wasd.T)) {
        this.uiManager.toggleMinimapSize();
    }
    
    // TAB key to cycle focus
    if (Phaser.Input.Keyboard.JustDown(this.wasd.TAB)) {
        const openMenus = [];
        if (this.isPaused) openMenus.push('pause');
        if (this.isShopOpen) openMenus.push('shop');
        if (this.inventoryUI.isOpen) openMenus.push('inventory');
        if (openMenus.length > 1) {
            const currentIndex = openMenus.indexOf(this.currentUIFocus);
            const nextIndex = (currentIndex + 1) % openMenus.length;
            this.currentUIFocus = openMenus[nextIndex];
            // Reset selection to the first item of the newly focused menu
            if (this.currentUIFocus === 'pause') {
                this.selectedPauseItemIndex = 0;
                this.updatePauseMenuSelection();
            } else if (this.currentUIFocus === 'shop') {
                this.selectedShopButtonIndex = 0;
                this.updateShopButtonSelection();
            } else if (this.currentUIFocus === 'inventory') {
                this.selectedInventorySlotIndex = 0;
                this.inventoryUI.updateSelection(this.selectedInventorySlotIndex);
            }
        }
        this.updateUIFocusVisuals();
    }
    
    // Only handle chat when no menus are open
    if (!this.isPaused && !this.isShopOpen && !this.inventoryUI.isOpen) {
        this.handleChatInput();
        this.handleHealthPackInput();
        this.handlePlayerRelease();
    }
  }
  updateUIFocusVisuals() {
    // Dim non-focused menus
    this.pauseMenuContainer.setAlpha(this.currentUIFocus === 'pause' || !this.isPaused ? 1 : 0.5);
    this.shopMenuContainer.setAlpha(this.currentUIFocus === 'shop' || !this.isShopOpen ? 1 : 0.5);
    this.inventoryUI.container.setAlpha(this.currentUIFocus === 'inventory' || !this.inventoryUI.isOpen ? 1 : 0.5);
  }
  handleHealthPackInput() {
    // Use health pack with 'H' key, but only when game is not paused/in a menu
    if (Phaser.Input.Keyboard.JustDown(this.wasd.H)) {
        this.player.useHealthPack();
    }
    }
    handlePlayerTrapCollision(playerSprite, trapSprite) {
        if (this.player.isTrapped) return;
        
        this.jailTrapSystem.trapPlayer(this.player);
        this.player.sprite.body.stop();
        trapSprite.destroy();
        this.uiManager.showTemporaryMessage('You are trapped! Press E to pay 50 coins to escape.', 5000);
        
        // Add visual trap indicator
        if (!this.player.trapIndicator) {
            this.player.trapIndicator = this.add.sprite(playerSprite.x, playerSprite.y, 'jailTrap')
                .setScale(0.15)
                .setDepth(playerSprite.depth + 1);
        }
    }
    handlePlayerRelease() {
        if (this.player.isTrapped && Phaser.Input.Keyboard.JustDown(this.wasd.E)) {
            const fee = 50;
            if (this.player.money >= fee) {
                this.player.money -= fee;
                this.jailTrapSystem.releasePlayer(this.player);
                if (this.player.trapIndicator) {
                    this.player.trapIndicator.destroy();
                    this.player.trapIndicator = null;
                }
                this.sound.play('chaChing', { volume: 0.6 });
                this.uiManager.showTemporaryMessage('You paid the fee and escaped!', 3000);
            } else {
                this.uiManager.showTemporaryMessage(`You need ${fee} coins to escape!`, 3000);
            }
        }
    }
    
    handleNPCTrapCollision(npcSprite, trapSprite) {
        if (npcSprite.isTrapped) return;
        
        this.jailTrapSystem.trapNPC(npcSprite);
        trapSprite.destroy();
        
        // We can add a visual or sound effect here later if needed.
    }
}