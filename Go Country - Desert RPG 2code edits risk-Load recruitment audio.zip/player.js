import Phaser from 'phaser';
import { Lasso } from './Lasso (rope)/lasso.js';

export class Player {
  constructor(scene, x, y) {
    this.scene = scene;
    this.name = 'Young Zealous';
    this.sprite = scene.add.sprite(x, y, 'playerRanger');
    this.sprite.setScale(0.15);
    this.sprite.setTint(0xFFE4B5);
    this.sprite.setDepth(10); // Render player in a higher layer
    
    scene.physics.add.existing(this.sprite);
    this.sprite.body.setCollideWorldBounds(true);
    this.sprite.body.setSize(60, 80);
    
    this.health = 105; // 7 shots * 15 damage
    this.maxHealth = 105;
    this.lives = 3;
    this.isAlive = true;
    this.speed = 200;
    this.originalSpeed = 200;
    this.lassoCount = 10;
    this.money = 0;
    this.isSpeedBoosted = false;
    this.lastTrailTime = 0;
    this.isMounted = false;
    this.horse = null;
    this.isTrapped = false;
    this.trapVisual = null;
    this.trapEscapeCost = 10;
    this.trapEscapePrompt = null;
    this.inventory = {
        molotovs: 5, // Start with some molotovs for testing
        healthPacks: 0,
        damageMines: 5,
        snareMines: 5,
        // other items can be added here
    };
    this.lastShot = 0;
    this.isShooting = false;
    this.shootCooldown = 200;
    this.originalCooldown = 200;
    this.capturedEnemies = [];
    this.deploySpyKey = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.EIGHT);
    this.recruitKey = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.R);
    this.equipLassoKey = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.F); // Also used for releasing
    this.isLassoEquipped = false;
    this.lassoEquipIndicator = null;
    this.lassoFireIndicator = null;
    this.commandKey = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SIX); // New key for guard command
    this.molotovKey = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.M);
    this.reviveKey = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.E);
    this.mountKey = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.U);
    this.useHealthKey = scene.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.H);
    // Bullets group
    this.bullets = scene.physics.add.group({
      defaultKey: 'playerBullet',
      maxSize: 1,
      runChildUpdate: true
    });
    
    // Lasso group
    this.lassos = scene.add.group({
      classType: Lasso,
      maxSize: 5,
      runChildUpdate: true
    });
    
    this.setupBullets();
    
    this.nameText = scene.add.text(this.sprite.x, this.sprite.y, this.name, {
        fontFamily: '"Press Start 2P", sans-serif',
        fontSize: '16px', fill: '#00FF00', // Bright green for player
        stroke: '#000', strokeThickness: 4,
        align: 'center'
    }).setOrigin(0.5, 1).setDepth(100);
  }
  
  setupBullets() {
    this.scene.physics.world.on('worldbounds', (body) => {
        const bullet = body.gameObject;
        if (bullet && this.bullets.contains(bullet)) {
            bullet.ricochets = (bullet.ricochets || 0) + 1;
            
            this.scene.sound.play('bullet_impact', { volume: 0.1, detune: 400 });
            if (bullet.ricochets >= 3) {
                bullet.disableBody(true, true);
            }
        }
    });
  }

  update(keys, pointer, joystickMove) {
    if (!this.isAlive) {
      this.sprite.body.setVelocity(0);
      return;
    }
    // If trapped, halt all actions
    if (this.isTrapped) {
        this.sprite.body.setVelocity(0);
        this.sprite.body.stop(); // Explicitly stop any existing movement
        if (!this.trapVisual) {
            this.trapVisual = this.scene.add.image(this.sprite.x, this.sprite.y, 'player and npc jail trap')
                .setScale(0.15)
                .setDepth(this.sprite.depth + 1);
        }
        this.trapVisual.setPosition(this.sprite.x, this.sprite.y);
        if (!this.trapEscapePrompt) {
            this.showTrapEscapePrompt();
        }
        // Allow player to pay a fee to escape the trap
        if (Phaser.Input.Keyboard.JustDown(this.reviveKey)) { // Using 'E' key
            if (this.money >= this.trapEscapeCost) {
                this.money -= this.trapEscapeCost;
                this.isTrapped = false;
                if (this.trapVisual) {
                    this.trapVisual.destroy();
                    this.trapVisual = null;
                }
                if(this.trapEscapePrompt) {
                    this.trapEscapePrompt.destroy();
                    this.trapEscapePrompt = null;
                }
                this.scene.sound.play('chaChing', { volume: 0.5 });
            } else {
                this.scene.uiManager.showTemporaryMessage(`Not enough coins! Need ${this.trapEscapeCost}.`);
            }
        }
        return;
    }
    
    // Stop all player movement and actions if typing
    if (this.scene.chatManager && this.scene.chatManager.isListening) {
        this.sprite.body.setVelocity(0);
        return; // Stop player movement while talking
    }
    if (Phaser.Input.Keyboard.JustDown(this.mountKey)) {
        this.toggleMount();
    }
    
    // If mounted, player movement is controlled by the horse.
    // Shooting and other actions are handled in horse.js update.
    if(this.isMounted) {
        this.sprite.body.setVelocity(0);
        return;
    }
    
    const body = this.sprite.body;
    
    // Movement
    body.setVelocity(0);
    if (joystickMove) {
      body.setVelocityX(this.speed * joystickMove.x);
      body.setVelocityY(this.speed * joystickMove.y);
      if (joystickMove.x < 0) {
        this.sprite.setFlipX(true);
      } else if (joystickMove.x > 0) {
        this.sprite.setFlipX(false);
      }
    } else {
      if (keys.A.isDown) {
        body.setVelocityX(-this.speed);
        this.sprite.setFlipX(true);
      } else if (keys.D.isDown) {
        body.setVelocityX(this.speed);
        this.sprite.setFlipX(false);
      }
      if (keys.W.isDown) {
        body.setVelocityY(-this.speed);
      } else if (keys.S.isDown) {
        body.setVelocityY(this.speed);
      }
    }
    // Change sprite texture based on direction
    if (joystickMove) {
      // Prioritize joystick direction for sprite texture
      if (joystickMove.y > 0.5) { // Use a threshold
        this.sprite.setTexture('playerRangerDown');
      } else if (joystickMove.y < -0.5) {
        this.sprite.setTexture('playerRanger');
      }
      // If y is neutral, we can either keep the last texture or base it on x, but for now we'll leave it.
    } else {
      // Fallback to keyboard/mouse when joystick is not in use
      if (keys.S.isDown || pointer.y > this.scene.scale.height / 2) {
        this.sprite.setTexture('playerRangerDown');
      } else {
        this.sprite.setTexture('playerRanger');
      }
    }
    
    // Shooting / Whip Action
    if (this.isShooting && joystickMove) {
        this.shoot(null, joystickMove);
    } else if (pointer.leftButtonDown()) {
        if (!this.isLassoEquipped) {
            this.shoot(pointer, null);
        } else if (this.lassoCount > 0) { // Only fire if there are lassos left
            this.fireLasso(pointer);
        }
    }
    
    // Equip/Unequip lasso
    if (Phaser.Input.Keyboard.JustDown(this.equipLassoKey)) {
        if (this.capturedEnemies.length > 0) {
            this.releaseEnemy(); // Prioritize releasing if enemies are captured
        } else {
            this.isLassoEquipped = !this.isLassoEquipped;
            this.toggleLassoIndicator(this.isLassoEquipped);
        }
    }
    // Lasso/Capture Action
    
    // Chatting
    // NOTE: Spacebar for chat is now handled in gameScene.js's handleChatInput
    
    // Releasing captured enemies is now handled by the 'F' key logic above.
    
    // Releasing captured enemies
    if (Phaser.Input.Keyboard.JustDown(this.deploySpyKey)) {
        this.deploySpy();
    }
    // NPC Interaction
    if (Phaser.Input.Keyboard.JustDown(this.recruitKey)) {
        this.scene.npcSystem.toggleRecruitment(pointer);
    }
    if (Phaser.Input.Keyboard.JustDown(this.commandKey)) {
        this.scene.npcSystem.commandGuardMove(pointer);
    }
    
    if (Phaser.Input.Keyboard.JustDown(this.molotovKey)) {
        this.throwMolotov(pointer);
    }
    if (Phaser.Input.Keyboard.JustDown(this.useHealthKey)) {
        this.useHealthPack();
    }
    
    // Reviving NPCs
    if (this.scene.npcSystem && typeof this.scene.npcSystem.handleRevive === 'function') {
      if (this.reviveKey.isDown) {
          this.scene.npcSystem.handleRevive(this, true);
      } else {
          this.scene.npcSystem.handleRevive(this, false);
      }
    }
    
    // NPC trap escape
    if (this.scene.npcSystem && typeof this.scene.npcSystem.handleTrapEscape === 'function') {
        if (Phaser.Input.Keyboard.JustDown(this.reviveKey)) { // Using 'E' key
            this.scene.npcSystem.handleTrapEscape(this, true);
        } else {
            this.scene.npcSystem.handleTrapEscape(this, false);
        }
    }
    
    
    // Update bullets - no longer needed as bullets self-destruct
    // this.bullets.children.entries.forEach(...)
    
    this.updateCapturedEnemies();
    if (this.isSpeedBoosted && this.scene.time.now > this.lastTrailTime + 50) {
        this.emitTrail();
        this.lastTrailTime = this.scene.time.now;
    }
    
    if (this.nameText) {
        this.nameText.setPosition(this.sprite.x, this.sprite.y - this.sprite.displayHeight / 2 - 5);
    }
    if (this.lassoEquipIndicator) {
        this.lassoEquipIndicator.setPosition(this.sprite.x, this.sprite.y - this.sprite.displayHeight - 10);
    }
  }
  startShooting() {
    this.isShooting = true;
  }
  stopShooting() {
    this.isShooting = false;
  }
  
  shoot(pointer, joystickMove) {
    if (this.isTrapped) return;
    // Only shoot if there are available bullets in the pool (i.e., less than maxSize are active)
    if (this.bullets.countActive(true) >= this.bullets.maxSize || this.scene.time.now < this.lastShot + this.shootCooldown) {
        return;
    }
    this.lastShot = this.scene.time.now;
    
    // Play reload sound when entering cooldown period
    this.scene.sound.play('reloadHandgun', { volume: 0.6 });
    
    const bullet = this.bullets.get();
    if (!bullet) return;
    // --- Core Setup ---
    let angle;
    if (joystickMove && (joystickMove.x !== 0 || joystickMove.y !== 0)) {
        angle = Math.atan2(joystickMove.y, joystickMove.x);
    } else if (pointer) {
        const worldPoint = this.scene.cameras.main.getWorldPoint(pointer.x, pointer.y);
        angle = Phaser.Math.Angle.Between(this.sprite.x, this.sprite.y, worldPoint.x, worldPoint.y);
    } else {
        return; // No valid direction to shoot.
    }
    const muzzleOffset = 25;
    const muzzleX = this.sprite.x + Math.cos(angle) * muzzleOffset;
    const muzzleY = this.sprite.y + Math.sin(angle) * muzzleOffset;
    this.createMuzzleFlash(muzzleX, muzzleY, angle);
    // --- Bullet Activation & Physics ---
    bullet.enableBody(true, muzzleX, muzzleY, true, true);
    bullet.setRotation(angle);
    bullet.body.setCircle(bullet.width * 0.5);
    bullet.body.setCollideWorldBounds(true, 1, 1, true); // Enable world bounds collision with bounce
    bullet.ricochets = 0;
    // --- Set Bullet Velocity ---
    const speed = 2500;
    this.scene.physics.velocityFromRotation(angle, speed, bullet.body.velocity);
    // --- Audio & Visual Feedback ---
    this.scene.sound.play('gunshot', { volume: 0.4 });
    this.scene.cameras.main.shake(50, 0.01);
  }
  createMuzzleFlash(x, y, angle) {
    const particles = this.scene.add.particles(x, y, 'bulletTracer', {
        speed: { min: 100, max: 300 },
        angle: { min: Phaser.Math.RadToDeg(angle) - 30, max: Phaser.Math.RadToDeg(angle) + 30 },
        scale: { start: 0.05, end: 0 },
        tint: [0xFFFF00, 0xFFE4B5, 0xFFFFFF], // Yellow-to-white flash for player
        blendMode: 'ADD',
        lifespan: 100,
        quantity: 15, // More particles for the player's flash
        emitting: true // Start emitting immediately
    });
    
    this.scene.time.delayedCall(200, () => {
        if (particles) {
            particles.destroy();
        }
    });
  }
  
  takeDamage(damage) {
    if (!this.isAlive) return;
    this.health -= damage;
    this.scene.triggerDamageFlash();
    this.sprite.setTint(0xFF4444);
    this.scene.time.delayedCall(100, () => {
      this.sprite.setTint(0xFFE4B5);
    });
    
    if (this.isAlive && this.health <= 0) {
      this.health = 0;
      this.isAlive = false;
      this.die();
    }
  }
  
  useHealthPack() {
    if (this.inventory.healthPacks > 0 && this.health < this.maxHealth) {
        this.inventory.healthPacks--;
        this.health = Math.min(this.maxHealth, this.health + 50); // Heal 50 HP
        
        // Visual feedback for healing
        this.sprite.setTint(0x00FF00); 
        this.scene.time.delayedCall(150, () => {
          if(this.isAlive) this.sprite.setTint(0xFFE4B5);
        });
        
        console.log(`Used a health pack. Current health: ${this.health}. Packs left: ${this.inventory.healthPacks}`);
    }
  }
  
  die() {
    this.lives--;
    this.sprite.body.stop();
    if (this.nameText) this.nameText.setVisible(false);
    this.sprite.play('player_death_anim');
    // After animation, decide whether to restart level or end game
    this.sprite.on('animationcomplete', () => {
      if (this.lives > 0) {
        this.scene.loseLife();
      } else {
        this.scene.gameOver();
      }
    }, this);
  }
  
  // This method is no longer needed as chat is initiated from GameScene
  /*
  attemptChat() {
    const chatRange = 100;
    const closestNPC = this.scene.npcSystem.findNearestNPC(this.sprite.x, this.sprite.y, chatRange);
    if (closestNPC) {
        this.scene.chatManager.startChat(closestNPC);
    }
  }
  */
  
  fireLasso(pointer) {
    if (this.lassoCount <= 0 || this.scene.time.now < this.lastShot + this.shootCooldown) return;
    const lasso = this.lassos.get();
    if (lasso) {
        this.lassoCount--;
        this.lastShot = this.scene.time.now;
        const worldPoint = this.scene.cameras.main.getWorldPoint(pointer.x, pointer.y);
        lasso.fire(this.sprite.x, this.sprite.y, worldPoint.x, worldPoint.y);
        this.scene.sound.play('lassoSound', { volume: 0.5 });
        // After the lasso is thrown, wait for it to "land" and then emit the event.
        this.scene.time.delayedCall(100, () => { // 100ms matches the lasso's throw duration
            this.scene.events.emit('lassoLanded', worldPoint.x, worldPoint.y);
        });
        this.isLassoEquipped = false;
        this.toggleLassoIndicator(false);
    }
  }
  
  throwMolotov(pointer) {
    if (this.inventory.molotovs > 0) {
        this.inventory.molotovs--;
        const molotov = this.scene.molotovs.get();
        if (molotov) {
          const worldPoint = this.scene.cameras.main.getWorldPoint(pointer.x, pointer.y);
          const angle = Phaser.Math.Angle.Between(
            this.sprite.x, this.sprite.y, worldPoint.x, worldPoint.y
          );
          molotov.throw(this.sprite.x, this.sprite.y, angle);
        }
    }
  }
  captureEnemy(enemy) {
      this.scene.enemyManager.captureEnemy(enemy);
      this.capturedEnemies.push(enemy);
      
      enemy.sprite.setTexture('capturedBandit');
      // Create lasso visual if it doesn't exist
      if (!enemy.lassoVisual) {
          enemy.lassoVisual = this.scene.add.graphics({
              lineStyle: { width: 2, color: 0x8B4513 } // Brown lasso color
          });
      }
      enemy.lassoVisual.setVisible(true);
  }
  
  releaseEnemy() {
    const enemyToRelease = this.capturedEnemies.pop(); // Releases the last one captured
    if (enemyToRelease) {
      if (enemyToRelease.lassoVisual) {
        enemyToRelease.lassoVisual.setVisible(false);
      }
      this.scene.enemyManager.releaseEnemy(enemyToRelease);
    }
  }
  
  deploySpy() {
      if (this.capturedEnemies.length > 0) {
          const spyEnemy = this.capturedEnemies.pop();
          if (spyEnemy.lassoVisual) {
              spyEnemy.lassoVisual.setVisible(false);
          }
          this.scene.npcSystem.createSpyFromEnemy(spyEnemy);
      }
  }
  
  updateCapturedEnemies() {
      // The first captured enemy is the one being dragged
      const draggedEnemy = this.capturedEnemies[0];
      if (draggedEnemy && draggedEnemy.sprite.active) {
          const distance = Phaser.Math.Distance.Between(this.sprite.x, this.sprite.y, draggedEnemy.sprite.x, draggedEnemy.sprite.y);
          const followDistance = 60; // How far behind the player the enemy should be
          if (distance > followDistance) {
              const angle = Phaser.Math.Angle.Between(draggedEnemy.sprite.x, draggedEnemy.sprite.y, this.sprite.x, this.sprite.y);
              // Move the enemy towards the player
              const moveSpeed = this.speed * 1.1; // Slightly faster than player to catch up
              this.scene.physics.velocityFromRotation(angle, moveSpeed, draggedEnemy.sprite.body.velocity);
          } else {
              draggedEnemy.sprite.body.setVelocity(0);
          }
      }
      // Chain the rest of the enemies together
      for (let i = 1; i < this.capturedEnemies.length; i++) {
          const currentEnemy = this.capturedEnemies[i];
          const previousEnemy = this.capturedEnemies[i - 1];
          if (currentEnemy.sprite.active && previousEnemy.sprite.active) {
              const distance = Phaser.Math.Distance.Between(previousEnemy.sprite.x, previousEnemy.sprite.y, currentEnemy.sprite.x, currentEnemy.sprite.y);
              const followDistance = 60;
              if (distance > followDistance) {
                  const angle = Phaser.Math.Angle.Between(currentEnemy.sprite.x, currentEnemy.sprite.y, previousEnemy.sprite.x, previousEnemy.sprite.y);
                  this.scene.physics.velocityFromRotation(angle, this.speed, currentEnemy.sprite.body.velocity);
              } else {
                  currentEnemy.sprite.body.setVelocity(0);
              }
          }
      }
      
      // Update lasso visuals
      this.capturedEnemies.forEach(enemy => {
          if (enemy.isCaptured && enemy.lassoVisual && enemy.sprite.active) {
              enemy.lassoVisual.clear();
              enemy.lassoVisual.lineStyle(4, 0x8B4513, 0.9); // Thicker, more visible ropes
              const spriteWidth = enemy.sprite.displayWidth * 0.4;
              const spriteHeight = enemy.sprite.displayHeight * 0.3;
              // Draw three horizontal lines to simulate being tied up
              for (let i = 0; i < 3; i++) {
                  const y = enemy.sprite.y - spriteHeight + (i * spriteHeight);
                  enemy.lassoVisual.strokeLineShape({
                      x1: enemy.sprite.x - spriteWidth, y1: y,
                      x2: enemy.sprite.x + spriteWidth, y2: y
                  });
              }
              enemy.lassoVisual.setDepth(enemy.sprite.depth + 1);
          } else if (enemy.lassoVisual) {
              enemy.lassoVisual.setVisible(false);
          }
      });
  }
  
  // Getter for money to be consistent with coins property used in npcSystem
  get coins() {
    return this.money;
  }
  // Setter for money
  set coins(value) {
    this.money = value;
  }
  activateFireRateBoost() {
    this.shootCooldown = this.originalCooldown / 2; // Double fire rate
    
    // Optional: Add visual feedback for the player
    this.sprite.setTint(0x00FF00); // Green glow
    
    this.scene.time.delayedCall(5000, () => {
      this.shootCooldown = this.originalCooldown; // Reset after 5 seconds
      this.sprite.setTint(0xFFE4B5); // Back to normal tint
    });
  }
  emitTrail() {
    const trailSprite = this.scene.add.sprite(this.sprite.x, this.sprite.y, this.sprite.texture.key);
    trailSprite.setTint(0xADD8E6);
    trailSprite.setScale(this.sprite.scaleX, this.sprite.scaleY);
    trailSprite.setFlipX(this.sprite.flipX);
    trailSprite.setAlpha(0.6);
    trailSprite.setDepth(this.sprite.depth - 1);
    this.scene.tweens.add({
      targets: trailSprite,
      alpha: 0,
      scale: this.sprite.scaleX * 0.8,
      duration: 600,
      ease: 'Cubic.easeOut',
      onComplete: () => {
        trailSprite.destroy();
      }
    });
  }
  activateSpeedBoost(onActivate) {
    if (this.isSpeedBoosted) return; // Don't stack boosts
    this.speed = this.originalSpeed * 1.5; // 50% speed increase
    this.isSpeedBoosted = true;
    if (onActivate) onActivate();
    
    // Visual feedback for speed boost
    this.sprite.setTint(0xADD8E6); // Light blue glow
    
    this.scene.time.delayedCall(10000, () => {
      this.speed = this.originalSpeed; // Reset after 10 seconds
      this.isSpeedBoosted = false;
      if(this.isAlive) this.sprite.setTint(0xFFE4B5); // Back to normal tint
    });
  }
  
  toggleMount() {
      if (this.isMounted) {
          if (this.horse) {
              this.horse.dismount();
          }
      } else {
          const mountRange = 100;
          let closestHorse = this.scene.physics.closest(this.sprite, this.scene.horses.getChildren());
          if (closestHorse) {
              const distance = Phaser.Math.Distance.Between(this.sprite.x, this.sprite.y, closestHorse.x, closestHorse.y);
              if (distance <= mountRange && !closestHorse.isMounted) {
                  closestHorse.mount(this);
                  this.isMounted = true;
                  this.horse = closestHorse;
                  this.sprite.setVisible(false);
                  this.sprite.body.enable = false;
                  if (this.nameText) this.nameText.setVisible(false);
              }
          }
      }
  }
  showTrapEscapePrompt() {
    if (this.trapEscapePrompt) {
        this.trapEscapePrompt.destroy();
    }
    const cost = this.trapEscapeCost;
    const container = this.scene.add.container(this.sprite.x, this.sprite.y - this.sprite.displayHeight / 2 - 20).setDepth(101);
    
    const text = `Pay ${cost} to escape! [E]`;
    const promptText = this.scene.add.text(0, 0, text, {
        fontFamily: '"Press Start 2P", sans-serif',
        fontSize: '12px', fill: '#FFD700',
        stroke: '#000', strokeThickness: 3,
        align: 'center'
    }).setOrigin(0.5);
    const coinIcon = this.scene.add.image(promptText.width / 2 + 5, 0, 'coinIcon').setScale(0.08);
    container.add([promptText, coinIcon]);
    this.trapEscapePrompt = container;
  }
  toggleLassoIndicator(isEquipped) {
    if (isEquipped) {
        if (!this.lassoEquipIndicator) {
            this.lassoEquipIndicator = this.scene.add.sprite(this.sprite.x, this.sprite.y, 'rope lasso');
            this.lassoEquipIndicator.setScale(0.2).setDepth(this.sprite.depth + 1);
            
            // Assuming the GIF has been loaded with a key like 'rope_lasso_anim'
            // and an animation was created from it in the preloader.
            if (this.scene.anims.exists('rope_lasso_anim')) {
                this.lassoEquipIndicator.play('rope_lasso_anim');
            }
        }
        this.lassoEquipIndicator.setVisible(true);
    } else {
        if (this.lassoEquipIndicator) {
            this.lassoEquipIndicator.setVisible(false);
        }
    }
  }
}