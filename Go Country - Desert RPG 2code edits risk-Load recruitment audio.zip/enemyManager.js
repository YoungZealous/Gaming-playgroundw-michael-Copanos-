import Phaser from 'phaser';

export class EnemyManager {
  constructor(scene, npcSystem) {
    this.scene = scene;
    this.npcSystem = npcSystem; // Store reference to NPC system
    this.debug = false; // Master debug switch for this manager
    this.enemies = [];
    this.enemyGroup = this.scene.physics.add.group(); // Dynamic group for all enemy sprites
    
    // Performance optimization tracking for health bars
    this.lastHealthUpdate = new Map(); // Track last health values for each enemy
    this.healthUpdateInterval = 50; // Update health bars every 50ms instead of every frame
    this.lastHealthBarUpdate = 0;
    
    // Performance optimization tracking for alert icons
    this.lastAlertIconPositions = new Map(); // Track last alert icon positions
    this.alertIconUpdateInterval = 75; // Update alert icons every 75ms instead of every frame
    this.lastAlertIconUpdate = 0;
    
    this.spawnPoints = [
      // Top edge (far)
      { x: -1500, y: -1800 }, { x: 0, y: -1900 }, { x: 1500, y: -1800 },
      // Bottom edge (far)
      { x: -1500, y: 1800 }, { x: 0, y: 1900 }, { x: 1500, y: 1800 },
      // Left edge (far)
      { x: -1900, y: -1000 }, { x: -1850, y: 0 }, { x: -1900, y: 1000 },
      // Right edge (far)
      { x: 1900, y: -1000 }, { x: 1850, y: 0 }, { x: 1900, y: 1000 }
    ];
    
    this.createEnemies();
    // No longer need to defer, as npcSystem is passed in directly.
    this.setupCollisions();
    this.bullets = this.scene.physics.add.group({
      defaultKey: 'bullet',
      maxSize: 50
    });
    this.setupBullets();
    // Listen for the lassoLanded event to trigger the capture check
    this.scene.events.on('lassoLanded', this.captureEnemyAtPosition, this);
  }
  
  createEnemies() {
    // Determine the number of groups to spawn
    const numberOfGroups = Phaser.Math.Between(10, 14); // Further increased for more action
    const availableSpawnPoints = [...this.spawnPoints];
    
    // --- Spawn Groups ---
    for (let i = 0; i < numberOfGroups; i++) {
        if (availableSpawnPoints.length === 0) break;
        // Pick a random spawn point for the group and remove it from the available list
        const spawnIndex = Phaser.Math.RND.integerInRange(0, availableSpawnPoints.length - 1);
        const spawnPoint = availableSpawnPoints.splice(spawnIndex, 1)[0];
        // Decide group size
        const groupSize = Phaser.Math.Between(5, 8); // Increased group size
        const group = [];
        const radius = 120; // Radius for circular formation
        // Decide if the group is enemy type 1 or enemy type 2
        const enemyType = Phaser.Math.RND.pick(['enemyType1', 'enemyType2', 'sapper', 'marksman', 'rusher']); // Added 'rusher'
        for (let j = 0; j < groupSize; j++) {
            // Arrange enemies in a circle to prevent overlap
            const angle = (j / groupSize) * 2 * Math.PI;
            const offsetX = radius * Math.cos(angle) + Phaser.Math.Between(-20, 20);
            const offsetY = radius * Math.sin(angle) + Phaser.Math.Between(-20, 20);
            
            const individualSpawnPoint = {
                x: spawnPoint.x + offsetX,
                y: spawnPoint.y + offsetY
            };
            
            const enemy = this.createEnemyOfType(enemyType, individualSpawnPoint, group);
            group.push(enemy);
        }
        // Assign partners within the group
        for(let k = 0; k < group.length; k++) {
            if (group[k+1]) {
                group[k].partner = group[k+1];
                group[k+1].partner = group[k]; // Simple chain partnering
            }
        }
    }
    
    // --- Spawn Solitary Enemies ---
    const numberOfLoneWolves = Phaser.Math.Between(4, 7); // More lone wolves
    for (let i = 0; i < numberOfLoneWolves; i++) {
        if (availableSpawnPoints.length === 0) break;
        const spawnIndex = Phaser.Math.RND.integerInRange(0, availableSpawnPoints.length - 1);
        const spawnPoint = availableSpawnPoints.splice(spawnIndex, 1)[0];
        // Create a single enemy, not part of any group
        this.createEnemyOfType('enemyType1', spawnPoint);
    }
  }
  createEnemyOfType(type, spawnPoint) {
    // Offset is now handled in the group creation logic to prevent overlap
    const offsetX = 0;
    const offsetY = 0;
    let config;
    if (type === 'enemyType1') {
      config = {
        spriteAsset: 'banditEnemy', // Back to classic bandit enemy
        health: 80, // Restored higher health
        speed: 120,
        scale: 0.30, // Increased from 0.16 to 0.30
        tint: 0xFFFFFF,
        attackRange: 300,
        attackCooldown: 1200,
        detectionRange: 350
      };
    } else if (type === 'enemyType2') { // enemyType2
      config = {
        spriteAsset: 'banditEnemy', // Both types use bandit enemy now
        health: 80, // Same health for consistency
        speed: 120,
        scale: 0.20, // Increased from 0.16 to 0.20
        tint: 0xFFAADD, // Slight pink tint to differentiate type 2
        attackRange: 300,
        attackCooldown: 1200,
        detectionRange: 350
      };
    } else if (type === 'sapper') {
        config = {
            spriteAsset: 'banditEnemy',
            health: 60, // Sappers are a bit more fragile
            speed: 130, // Slightly faster
            scale: 0.25,
            tint: 0xD2B48C, // Sandy brown tint
            attackRange: 250, // Shorter attack range
            attackCooldown: 1500, // Slower fire rate
            detectionRange: 300
        };
    } else if (type === 'marksman') {
        config = {
            spriteAsset: 'banditEnemy',
            health: 50, // Fragile sniper
            speed: 90,  // Slower, positional
            scale: 0.25,
            tint: 0x006400, // Dark green tint
            attackRange: 500, // Long attack range
            attackCooldown: 2000, // Slow fire rate
            detectionRange: 600 // Very long detection range
        };
    } else if (type === 'rusher') {
        config = {
            spriteAsset: 'banditEnemy',
            health: 40, // More fragile
            speed: 200,  // Very fast
            scale: 0.18,
            tint: 0xFF0000, // Red tint for rushers
            attackRange: 50, // Melee range
            attackCooldown: 500, // Fast attack
            detectionRange: 450 // Long detection range to initiate rush
        };
    }
    const enemy = {
      type: type,
      sprite: this.scene.add.sprite(spawnPoint.x + offsetX, spawnPoint.y + offsetY, config.spriteAsset),
      originalSpawn: { x: spawnPoint.x, y: spawnPoint.y }, // Store original spawn point
      health: config.health,
      maxHealth: config.health,
      speed: config.speed,
      lastMove: 0,
      moveInterval: Phaser.Math.Between(3000, 6000), // Time between choosing new patrol points
      idleTarget: null,
      detectionRange: config.detectionRange,
      attackRange: config.attackRange,
      lastAttack: 0,
      attackCooldown: config.attackCooldown,
      isCaptured: false,
      partner: null,
      isAvenging: false,
      isPoweredUp: false,
      isAlerted: false,
      isPreppingAttack: false,
      lastMineLay: 0,
      mineLayCooldown: Phaser.Math.Between(8000, 15000) // Cooldown for laying mines (8-15 seconds)
    };
    enemy.sprite.setScale(config.scale);
    enemy.sprite.setTint(config.tint); // Use the config tint
    enemy.sprite.setDepth(9); // Ensure enemies are rendered above the jailhouse but below the player
    this.scene.physics.add.existing(enemy.sprite);
    this.enemyGroup.add(enemy.sprite); // Add sprite to the dynamic group
    enemy.sprite.body.setSize(enemy.sprite.width * 0.6, enemy.sprite.height * 0.9); // Increased hitbox size
    enemy.healthBar = this.scene.add.graphics();
    if (this.debug) {
      enemy.alertIcon = this.scene.add.text(enemy.sprite.x + 30, enemy.sprite.y - 60, '!', {
          fontSize: '32px', fill: '#FFFF00', fontStyle: 'bold', stroke: '#000', strokeThickness: 2
      }).setOrigin(0.5).setDepth(100).setVisible(false);
    } else {
      enemy.alertIcon = null; // Ensure alertIcon is null if debug is off
    }
    this.enemies.push(enemy);
    return enemy;
  }
  
  setupCollisions() {
    this.scene.physics.add.overlap(
      this.scene.player.bullets,
      this.enemyGroup, // Use the dynamic group for collision
      (bullet, enemySprite) => {
          const enemy = this.enemies.find(e => e.sprite === enemySprite);
          if (enemy) {
              this.hitEnemy(enemy, bullet);
          }
      }
    );
      
    this.scene.physics.add.overlap(
        this.enemyGroup, // Use the dynamic group for collision
        this.scene.powerUps,
        (enemySprite, powerUp) => {
            const enemy = this.enemies.find(e => e.sprite === enemySprite);
            if (enemy) {
                this.collectPowerUp(enemy, powerUp);
            }
        }
    );
      
    // Add collision for NPC bullets
    this.scene.physics.add.overlap(
        this.npcSystem.bullets,
        this.enemyGroup, // Use the dynamic group for collision
        (enemySprite, bullet) => {
            const enemy = this.findEnemyBySprite(enemySprite);
            if (enemy && bullet.active) {
                // Use the generic damage function
                this.takeDirectDamage(enemy, bullet.damage || 10); // Use damage from bullet property
                this.createNpcImpactEffect(bullet.x, bullet.y);
                bullet.setActive(false).setVisible(false);
            }
        }
    );
  }
  findEnemyBySprite(sprite) {
    return this.enemies.find(e => e.sprite === sprite);
  }
  
  update() {
    const currentTime = this.scene.time.now;
    const needsHealthBarUpdate = currentTime - this.lastHealthBarUpdate > this.healthUpdateInterval;
    const needsAlertIconUpdate = currentTime - this.lastAlertIconUpdate > this.alertIconUpdateInterval;
    
    if (needsHealthBarUpdate) {
      this.lastHealthBarUpdate = currentTime;
    }
    
    if (needsAlertIconUpdate) {
      this.lastAlertIconUpdate = currentTime;
    }
    
    this.enemies.forEach(enemy => {
      if (!enemy.sprite.active) {
        return;
      }
      
      // Only update health bar when necessary
      if (needsHealthBarUpdate || this.hasHealthChanged(enemy)) {
        this.updateHealthBar(enemy);
        this.lastHealthUpdate.set(enemy.sprite.name || enemy.sprite.x + ',' + enemy.sprite.y, enemy.health);
      }
      
      // Only update alert icon position when necessary
      if (enemy.alertIcon && (needsAlertIconUpdate || this.hasAlertIconMoved(enemy))) {
        enemy.alertIcon.setPosition(enemy.sprite.x + 30, enemy.sprite.y - 60);
        this.lastAlertIconPositions.set(enemy.sprite.name || enemy.sprite.x + ',' + enemy.sprite.y, {
          x: enemy.sprite.x,
          y: enemy.sprite.y
        });
        
        // Hide icon if target is lost - only check when updating
        if (enemy.alertIcon.visible && !this.isTargetStillValid(enemy)) {
          enemy.alertIcon.setVisible(false);
        }
      }
      
      // --- Power-up Seeking Logic ---
      let seekingPowerUp = false;
      if (!enemy.isCaptured) {
        let closestPowerUp = null;
        let minPowerUpDist = Infinity;
        
        this.scene.powerUps.getChildren().forEach(powerUp => {
          if (powerUp.active) {
            const dist = Phaser.Math.Distance.Between(enemy.sprite.x, enemy.sprite.y, powerUp.x, powerUp.y);
            if (dist < minPowerUpDist) {
              minPowerUpDist = dist;
              closestPowerUp = powerUp;
            }
          }
        });
        
        if (closestPowerUp && minPowerUpDist < enemy.detectionRange * 1.5) {
          const angle = Phaser.Math.Angle.Between(enemy.sprite.x, enemy.sprite.y, closestPowerUp.x, closestPowerUp.y);
          enemy.sprite.body.setVelocity(Math.cos(angle) * enemy.speed, Math.sin(angle) * enemy.speed);
          enemy.sprite.setFlipX(closestPowerUp.x < enemy.sprite.x);
          seekingPowerUp = true;
        }
      }
      if (seekingPowerUp) return; // Prioritize getting power-up over combat/idling.
      
      // --- Target Selection: Prioritize recruited NPCs ---
      let target = null;
      let distance = Infinity;
      let closestNpc = null;
      let minNpcDistance = Infinity;
      // Find the closest, active, recruited NPC
      const recruitedNpcs = this.scene.npcSystem.getNPCSprites().filter(npc => npc.isRecruited && npc.isAlive);
      recruitedNpcs.forEach(npc => {
        const d = Phaser.Math.Distance.Between(enemy.sprite.x, enemy.sprite.y, npc.x, npc.y);
        if (d < minNpcDistance) {
          minNpcDistance = d;
          closestNpc = npc;
        }
      });
      
      // If a recruited NPC is in range, target them.
      if (closestNpc && minNpcDistance < enemy.detectionRange) {
        target = closestNpc;
        distance = minNpcDistance;
      } else {
        // Otherwise, target the player if they are in range.
        const distanceToPlayer = Phaser.Math.Distance.Between(enemy.sprite.x, enemy.sprite.y, this.scene.player.sprite.x, this.scene.player.sprite.y);
        if (distanceToPlayer < enemy.detectionRange) {
          target = this.scene.player.sprite;
          distance = distanceToPlayer;
        }
      }
      if (target && !enemy.isAlerted) {
          enemy.isAlerted = true;
          // Increase fire rate when alerted
          enemy.attackCooldown *= 0.7; // 30% faster fire rate
          if(enemy.alertIcon) {
              enemy.alertIcon.setVisible(true).setFill('#FFFF00'); // Yellow for general alert
          }
      }
      if (enemy.isCaptured) {
        // Follow player
        const followDistance = 80;
        const distToPlayer = Phaser.Math.Distance.Between(enemy.sprite.x, enemy.sprite.y, this.scene.player.sprite.x, this.scene.player.sprite.y);
        if (distToPlayer > followDistance) {
          const angle = Phaser.Math.Angle.Between(enemy.sprite.x, enemy.sprite.y, this.scene.player.sprite.x, this.scene.player.sprite.y);
          enemy.sprite.body.setVelocity(
            Math.cos(angle) * (this.scene.player.speed * 0.9),
            Math.sin(angle) * (this.scene.player.speed * 0.9)
          );
          enemy.sprite.setFlipX(this.scene.player.sprite.x < enemy.sprite.x);
        } else {
          enemy.sprite.body.setVelocity(0);
        }
      } else if (target) { // AI behavior: only if a target has been selected
        // Move towards target
        const angle = Phaser.Math.Angle.Between(
          enemy.sprite.x, enemy.sprite.y, target.x, target.y
        );
        
        if (distance > enemy.attackRange) {
          enemy.sprite.body.setVelocity(
            Math.cos(angle) * enemy.speed,
            Math.sin(angle) * enemy.speed
          );
          enemy.sprite.setFlipX(Math.cos(angle) < 0);
        } else {
          enemy.sprite.body.setVelocity(0);
          // Attack target
          if (this.scene.time.now > enemy.lastAttack + enemy.attackCooldown) {
            if (enemy.type === 'rusher') {
                this.meleeAttack(enemy, target);
            } else {
                // New: Prepare attack, show red icon
                if (!enemy.isPreppingAttack) {
                  enemy.isPreppingAttack = true;
                  if (enemy.alertIcon) {
                      enemy.alertIcon.setFill('#FF0000'); // Red for attack prep
                  }
                  this.scene.time.delayedCall(300, () => {
                    // Check if still alive and has a target before attacking
                    if (enemy.sprite.active && this.isTargetStillValid(enemy)) {
                      this.attack(enemy, target, angle);
                    }
                    enemy.isPreppingAttack = false;
                    if (enemy.alertIcon) {
                      // Revert to yellow if still alerted, otherwise it will be hidden
                      if (enemy.isAlerted) enemy.alertIcon.setFill('#FFFF00');
                    }
                  });
                }
            }
          }
        }
      } else {
        if (enemy.isAlerted) {
            enemy.isAlerted = false;
            // Reset fire rate when losing target
            const config = this.getEnemyConfig(enemy.type);
            enemy.attackCooldown = config.attackCooldown;
        }
        // Idle movement: Patrol between random points
        const now = this.scene.time.now;
        if (!enemy.idleTarget || now > enemy.lastMove + enemy.moveInterval) {
            const patrolRadius = 400; // Reduced wander range
            // Patrol near their original spawn point to keep them on the edges
            const targetX = enemy.originalSpawn.x + Phaser.Math.Between(-patrolRadius, patrolRadius);
            const targetY = enemy.originalSpawn.y + Phaser.Math.Between(-patrolRadius, patrolRadius);
            // Clamp to world bounds to prevent them from walking off-map
            const worldBounds = this.scene.physics.world.bounds;
            enemy.idleTarget = {
                x: Phaser.Math.Clamp(targetX, worldBounds.x + 50, worldBounds.right - 50),
                y: Phaser.Math.Clamp(targetY, worldBounds.y + 50, worldBounds.bottom - 50)
            };
            
            enemy.lastMove = now;
            enemy.moveInterval = Phaser.Math.Between(4000, 8000); // Set time for next patrol point decision
        }
        const distanceToTarget = Phaser.Math.Distance.Between(enemy.sprite.x, enemy.sprite.y, enemy.idleTarget.x, enemy.idleTarget.y);
        
        if (distanceToTarget > 20) {
            const angle = Phaser.Math.Angle.Between(enemy.sprite.x, enemy.sprite.y, enemy.idleTarget.x, enemy.idleTarget.y);
            enemy.sprite.body.setVelocity(
                Math.cos(angle) * enemy.speed * 0.5, // Move at 50% speed
                Math.sin(angle) * enemy.speed * 0.5
            );
            enemy.sprite.setFlipX(enemy.idleTarget.x < enemy.sprite.x);
        } else {
            enemy.sprite.body.setVelocity(0, 0);
            enemy.idleTarget = null; // Reached target, will pick a new one on next cycle
        }
      }
      // --- Sapper Mine Laying Logic ---
      if (enemy.type === 'sapper' && !target && !seekingPowerUp && !enemy.isCaptured) {
        if (currentTime > enemy.lastMineLay + enemy.mineLayCooldown) {
          this.layMine(enemy);
          enemy.lastMineLay = currentTime;
          enemy.mineLayCooldown = Phaser.Math.Between(8000, 15000); // Reset cooldown for next mine
        }
      }
    });
  }
  
  hasHealthChanged(enemy) {
    const enemyKey = enemy.sprite.name || enemy.sprite.x + ',' + enemy.sprite.y;
    const lastHealth = this.lastHealthUpdate.get(enemyKey);
    return lastHealth !== enemy.health;
  }
  
  hasAlertIconMoved(enemy) {
    const enemyKey = enemy.sprite.name || enemy.sprite.x + ',' + enemy.sprite.y;
    const lastPosition = this.lastAlertIconPositions.get(enemyKey);
    
    if (!lastPosition) return true; // First time, needs update
    
    const threshold = 5; // Only update if moved more than 5 pixels
    return Math.abs(lastPosition.x - enemy.sprite.x) > threshold || 
           Math.abs(lastPosition.y - enemy.sprite.y) > threshold;
  }
  
  updateHealthBar(enemy) {
    // Only clear if we're actually going to redraw
    if (enemy.health <= 0) {
      enemy.healthBar.clear();
      return;
    }
    
    enemy.healthBar.clear();
    const x = enemy.sprite.x - 25;
    const y = enemy.sprite.y - 50;
    const w = 50;
    const h = 5;
    const healthPercent = enemy.health / enemy.maxHealth;
    // Background
    enemy.healthBar.fillStyle(0x333333);
    enemy.healthBar.fillRect(x, y, w, h);
    // Health
    const healthColor = enemy.isPoweredUp ? 0xFFD700 : 0xFF0000; // Gold if powered up, else red
    enemy.healthBar.fillStyle(healthColor);
    enemy.healthBar.fillRect(x, y, w * healthPercent, h);
  }
  
  hitEnemy(enemy, bullet) {
    // A captured enemy cannot be hit.
    if (!enemy || enemy.isCaptured) {
        if(bullet.active) bullet.setActive(false).setVisible(false);
        return;
    }
    
    this.scene.createImpactEffect(bullet.x, bullet.y);
    bullet.setActive(false).setVisible(false);
    
    enemy.health -= 15; // Player bullets deal 15 damage
    enemy.detectionRange = enemy.isPoweredUp ? 450 : 400; // Aggro on hit
    enemy.sprite.setTint(0xFF0000);
    this.scene.time.delayedCall(100, () => {
        // Revert to normal tint for both enemy types
        const defaultTint = 0xFFFFFF;
        if (enemy.sprite.active) {
            enemy.sprite.setTint(defaultTint);
        }
    });
    
    if (enemy.health <= 0 && enemy.sprite.active) {
      // Deactivate the enemy instead of just tinting
      enemy.sprite.setActive(false).setVisible(false);
      enemy.sprite.body.enable = false;
      enemy.healthBar.setVisible(false);
      
      // Drop mines when dying (40% chance) - No longer needed, handled by Sapper-specific logic
      // if (Math.random() < 0.4) {
      //   this.scene.time.delayedCall(200, () => {
      //     this.scene.mineSystem.createMine(
      //       enemy.sprite.x + Phaser.Math.Between(-30, 30),
      //       enemy.sprite.y + Phaser.Math.Between(-30, 30)
      //     );
      //   });
      // }
      
      // Drop loot based on enemy type
      if (enemy.type === 'enemyType1') {
        // Enemy Type 1 drops lassos and health packs
        this.scene.dropLasso(enemy.sprite.x, enemy.sprite.y);
        if (Math.random() < 0.6) {
          this.scene.dropHealthPack(enemy.sprite.x, enemy.sprite.y);
        }
      } else if (enemy.type === 'enemyType2') { // enemyType2 drops
        // Enemy Type 2 has higher health pack drop rate
        if (Math.random() < 0.8) {
          this.scene.dropHealthPack(enemy.sprite.x, enemy.sprite.y);
        }
        if (Math.random() < 0.4) {
          this.scene.dropLasso(enemy.sprite.x, enemy.sprite.y);
        }
      } else if (enemy.type === 'sapper') { // Sapper drops
          // High chance of dropping a mine on death
          if (Math.random() < 0.75) { // 75% chance
              this.dropDeathMine(enemy.sprite.x, enemy.sprite.y);
          }
          // Lower chance for other items
          if (Math.random() < 0.2) {
              this.scene.dropHealthPack(enemy.sprite.x, enemy.sprite.y);
          }
      } else if (enemy.type === 'marksman') { // Marksman drops
          // High chance of dropping coins, low chance of items
          if (Math.random() < 0.1) {
              this.scene.dropLasso(enemy.sprite.x, enemy.sprite.y);
          }
      } else if (enemy.type === 'rusher') { // Rusher drops
          // High chance of dropping health packs
          if (Math.random() < 0.5) {
              this.scene.dropHealthPack(enemy.sprite.x, enemy.sprite.y);
          }
      }
      const coinCount = Phaser.Math.Between(3, 7);
      for(let i = 0; i < coinCount; i++) {
        this.scene.time.delayedCall(i * 50, () => {
          this.scene.dropCoin(enemy.sprite.x + Phaser.Math.Between(-20, 20), enemy.sprite.y + Phaser.Math.Between(-20, 20), 'coin');
        });
      }
      
      if (enemy.partner && enemy.partner.sprite.active && !enemy.partner.isAvenging) {
        this.triggerVengeance(enemy.partner);
      }
      
      this.playDeathAnimation(enemy.sprite, () => {
        this.disableAndRespawnEnemy(enemy);
      });
    }
  }
  disableAndRespawnEnemy(enemy, respawnDelay = 10000) {
      if (!enemy || !enemy.sprite.active) return;
      
      // Deactivate the enemy
      enemy.sprite.setActive(false).setVisible(false);
      enemy.sprite.body.enable = false;
      if(enemy.healthBar) enemy.healthBar.setVisible(false);
      
      if (enemy.partner && enemy.partner.sprite.active && !enemy.partner.isAvenging) {
        this.triggerVengeance(enemy.partner);
      }
      
      // Schedule respawn after delay
      this.scene.time.delayedCall(respawnDelay, () => {
        this.respawnEnemy(enemy);
      });
  }
  
  takeDirectDamage(enemy, damage) {
    // If the enemy is null, already dead, or has been captured, do nothing.
    if (!enemy || !enemy.sprite.active || enemy.isCaptured) return;
    
    enemy.health -= damage;
    enemy.sprite.setTint(0xFF0000);
    this.scene.time.delayedCall(100, () => {
        if (enemy.sprite.active) { // No need to check isCaptured here, as their tint is managed separately
            if(enemy.isAvenging) {
                enemy.sprite.setTint(0xFF4500); // Back to vengeful tint
            } else {
                const defaultTint = 0xFFFFFF;
                enemy.sprite.setTint(defaultTint);
            }
        }
    });
    if (enemy.health <= 0) {
      // Deactivate the enemy instead of just tinting
      enemy.sprite.setActive(false).setVisible(false);
      enemy.sprite.body.enable = false;
      enemy.healthBar.setVisible(false);
      
      // Drop mines when dying (40% chance) - No longer needed, handled by Sapper-specific logic
      // if (Math.random() < 0.4) {
      //   this.scene.time.delayedCall(200, () => {
      //     this.scene.mineSystem.createMine(
      //       enemy.sprite.x + Phaser.Math.Between(-30, 30),
      //       enemy.sprite.y + Phaser.Math.Between(-30, 30)
      //     );
      //   });
      // }
      
      // Drop loot based on enemy type
      if (enemy.type === 'enemyType1') {
        // Enemy Type 1 drops lassos and health packs
        this.scene.dropLasso(enemy.sprite.x, enemy.sprite.y);
        if (Math.random() < 0.6) {
          this.scene.dropHealthPack(enemy.sprite.x, enemy.sprite.y);
        }
      } else if (enemy.type === 'enemyType2') { // enemyType2 drops
        // Enemy Type 2 has higher health pack drop rate
        if (Math.random() < 0.8) {
          this.scene.dropHealthPack(enemy.sprite.x, enemy.sprite.y);
        }
        if (Math.random() < 0.4) {
          this.scene.dropLasso(enemy.sprite.x, enemy.sprite.y);
        }
      } else if (enemy.type === 'sapper') { // Sapper drops
          if (Math.random() < 0.75) { // 75% chance to drop a mine
              this.dropDeathMine(enemy.sprite.x, enemy.sprite.y);
          }
      } else if (enemy.type === 'marksman') { // Marksman drops
          if (Math.random() < 0.1) {
              this.scene.dropLasso(enemy.sprite.x, enemy.sprite.y);
          }
      } else if (enemy.type === 'rusher') { // Rusher drops
        if (Math.random() < 0.5) {
            this.scene.dropHealthPack(enemy.sprite.x, enemy.sprite.y);
        }
      }
      const coinCount = Phaser.Math.Between(3, 7);
      for(let i = 0; i < coinCount; i++) {
        this.scene.time.delayedCall(i * 50, () => {
          this.scene.dropCoin(enemy.sprite.x + Phaser.Math.Between(-20, 20), enemy.sprite.y + Phaser.Math.Between(-20, 20), 'coin');
        });
      }
      
      this.playDeathAnimation(enemy.sprite, () => {
        this.disableAndRespawnEnemy(enemy);
      });
    }
  }
  
  collectPowerUp(enemy, powerUp) {
    if (!powerUp.active) return;
    
    powerUp.destroy();
    this.scene.sound.play('gunshot', { volume: 0.1, detune: 500 }); // Power-up collect sound
    
    // Boost attack speed (reduce cooldown)
    enemy.attackCooldown = Math.max(500, enemy.attackCooldown * 0.8); // 20% faster, with a cap
    enemy.isPoweredUp = true;
    
    // Visual feedback for power-up
    this.scene.createEnemyPowerUpEffect(enemy.sprite.x, enemy.sprite.y);
    enemy.sprite.setTint(0x00FF00); // Green flash
    this.scene.time.delayedCall(200, () => {
      if (enemy.isAvenging) {
          enemy.sprite.setTint(0xFF4500); // Back to vengeful tint
      } else {
          enemy.sprite.setTint(0xFFFFFF); // Back to normal tint
      }
    });
  }
  
  attack(enemy, target, angle) {
    // Both enemy types use the same attack animation approach
    // No texture switching needed for now - can be added later if needed
    const bullet = this.bullets.get(null, null, 'bulletTracer');
    if (bullet) {
      bullet.setActive(true).setVisible(true);
      bullet.setPosition(enemy.sprite.x, enemy.sprite.y);
      bullet.setRotation(angle);
      // Update properties for the tracer asset
      bullet.setScale(0.1, 0.03); 
      bullet.setTint(0xFF0000); // Enemy red tint
      bullet.body.isCircle = false;
      bullet.body.setSize(bullet.width, bullet.height);
      const speed = 2500; // Match player's bullet speed
      bullet.body.setVelocity(
        Math.cos(angle) * speed,
        Math.sin(angle) * speed
      );
      bullet.damage = 4; // Reduced from 8 to 4 for a better fight
      // Set a timer to automatically destroy the bullet after a short time
      this.scene.time.delayedCall(1500, () => {
          if(bullet.active) {
              bullet.setActive(false).setVisible(false);
          }
      });
      enemy.lastAttack = this.scene.time.now;
      // Calculate distance-based volume
      const playerPos = this.scene.player.sprite;
      const distance = Phaser.Math.Distance.Between(playerPos.x, playerPos.y, enemy.sprite.x, enemy.sprite.y);
      const maxSoundDistance = 1200; // Max distance to hear the shot
      const maxVolume = 0.3;
      let volume = maxVolume * (1 - distance / maxSoundDistance);
      volume = Phaser.Math.Clamp(volume, 0, maxVolume);
      this.scene.sound.play('gunshot', { volume: volume });
      this.createMuzzleFlash(enemy.sprite.x, enemy.sprite.y, angle);
      
      // Notify NPC system that this enemy shot at a target
      if (target === this.scene.player.sprite) {
        this.scene.npcSystem.enemyAttackedPlayer(enemy);
      }
    }
  }
  setupBullets() {
    // This function is less critical now that bullets are configured on creation in `attack`,
    // but we can keep it for pre-warming the pool if needed in the future.
    // For now, we'll leave it empty as the logic is handled in `attack`.
  }
  createNpcImpactEffect(x, y) {
    const particles = this.scene.add.particles('bulletTracer');
    const emitter = particles.createEmitter({
        x: x,
        y: y,
        speed: { min: 50, max: 200 },
        angle: { min: 0, max: 360 },
        scale: { start: 0.3, end: 0 },
        tint: 0x00FF00, // Friendly green tint
        blendMode: 'ADD',
        lifespan: 400,
        quantity: 15
    });
    this.scene.time.delayedCall(400, () => {
        if (particles) particles.destroy();
    });
  }
  createMuzzleFlash(x, y, angle) {
    // Determine flash position slightly in front of the shooter
    const muzzleOffset = 40;
    const flashX = x + muzzleOffset * Math.cos(angle);
    const flashY = y + muzzleOffset * Math.sin(angle);
    const particles = this.scene.add.particles(flashX, flashY, 'bulletTracer', {
        speed: { min: 100, max: 250 },
        angle: { min: Phaser.Math.RadToDeg(angle) - 30, max: Phaser.Math.RadToDeg(angle) + 30 },
        scale: { start: 0.04, end: 0 },
        tint: [0xFF0000, 0xFFE4B5, 0xFFFFFF], // Red-to-white flash for enemies
        blendMode: 'ADD',
        lifespan: 100,
        quantity: 12,
        emitting: true // Start emitting immediately
    });
    this.scene.time.delayedCall(200, () => {
        if (particles) {
            particles.destroy();
        }
    });
  }
  
  captureEnemy(enemy) {
    enemy.isCaptured = true;
    enemy.sprite.setTint(0x66CCFF); // Blue tint to show they are captured
    enemy.healthBar.setVisible(false);
  }
  releaseEnemy(enemy) {
    if (!enemy || !enemy.isCaptured) return;
    
    enemy.isCaptured = false;
    // Revert texture and alert others
    enemy.sprite.setTexture('banditEnemy');
    this.alertNearbyEnemies(enemy.sprite.x, enemy.sprite.y);
    // Visual effect for breaking free
    enemy.sprite.setTint(0xFF8C00); // Orange tint
    
    this.scene.time.delayedCall(1500, () => {
      // Revert to normal after delay
      const defaultTint = enemy.type === 'coyote' ? 0xFFFFFF : 0xFFFFFF;
      if (enemy.sprite.active) {
          enemy.sprite.setTint(defaultTint);
      }
      enemy.healthBar.setVisible(true);
      enemy.lastAttack = this.scene.time.now; // Reset attack cooldown
    });
  }
  alertNearbyEnemies(x, y, radius = 700) {
      this.enemies.forEach(otherEnemy => {
          if (otherEnemy.sprite.active && !otherEnemy.isCaptured && otherEnemy.health > 0) {
              const distance = Phaser.Math.Distance.Between(x, y, otherEnemy.sprite.x, otherEnemy.sprite.y);
              if (distance < radius) {
                  // Make the enemy immediately hostile towards the player
                  otherEnemy.detectionRange = 1500; // Max out detection range to ensure they see the player
                  
                  // Show the alert icon
                  if (otherEnemy.alertIcon) {
                      otherEnemy.alertIcon.setVisible(true).setFill('#FFFF00');
                  }
              }
          }
      });
  }
  
  respawnEnemy(enemy) {
    // Pick a random spawn point from the edges
    const spawnPoint = Phaser.Math.RND.pick(this.spawnPoints);
    const offsetX = Phaser.Math.Between(-100, 100);
    const offsetY = Phaser.Math.Between(-100, 100);
    
    // Reset enemy properties
    enemy.sprite.setPosition(spawnPoint.x + offsetX, spawnPoint.y + offsetY);
    enemy.health = enemy.maxHealth;
    enemy.isCaptured = false;
    
    // Re-enable the enemy
    enemy.sprite.setActive(true).setVisible(true);
    enemy.sprite.body.enable = true;
    const defaultTint = 0xFFFFFF;
    enemy.sprite.setTint(defaultTint); // Reset tint
    enemy.healthBar.setVisible(true);
    enemy.isAvenging = false;
    const defaultConfig = this.getEnemyConfig(enemy.type);
    enemy.speed = defaultConfig.speed; // Reset speed
    enemy.attackCooldown = defaultConfig.attackCooldown; // Reset attack speed
    enemy.idleTarget = null; // Reset idle target
    enemy.detectionRange = defaultConfig.detectionRange; // Reset detection range
    enemy.isPoweredUp = false; // Reset power-up status
    enemy.healthBar.setVisible(true);
    if(enemy.alertIcon) enemy.alertIcon.setVisible(false);
  }
  isTargetStillValid(enemy) {
      const distanceToPlayer = Phaser.Math.Distance.Between(enemy.sprite.x, enemy.sprite.y, this.scene.player.sprite.x, this.scene.player.sprite.y);
      if (distanceToPlayer < enemy.detectionRange) {
          return true;
      }
      const recruitedNpcs = this.scene.npcSystem.getNPCSprites().filter(npc => npc.isRecruited && npc.isAlive);
      for(const npc of recruitedNpcs) {
          const d = Phaser.Math.Distance.Between(enemy.sprite.x, enemy.sprite.y, npc.x, npc.y);
          if (d < enemy.detectionRange) {
              return true;
          }
      }
      return false;
  }
  
  triggerVengeance(partner) {
    if (!partner || !partner.sprite.active) return;
    
    partner.isAvenging = true;
    partner.speed *= 1.5;
    partner.attackCooldown /= 2;
    partner.detectionRange *= 1.5;
    
    partner.sprite.setTint(0xFF4500); // Vengeful orange-red tint
    
    const vengeanceText = this.scene.add.text(
      partner.sprite.x,
      partner.sprite.y - 60,
      "You'll pay for that!", {
        fontSize: '18px', fill: '#FF6347', fontStyle: 'bold', stroke: '#000000', strokeThickness: 3
      }
    ).setOrigin(0.5).setDepth(100);
    
    this.scene.time.delayedCall(2500, () => {
      vengeanceText.destroy();
    });
  }
  
  getEnemyConfig(type) {
    if (type === 'enemyType1') {
      return {
        spriteAsset: 'banditEnemy', // Updated to match createEnemyOfType
        health: 80, // Updated to match createEnemyOfType
        speed: 120, // Updated to match createEnemyOfType
        scale: 0.20, // Updated from 0.16 to 0.20
        tint: 0xFFFFFF,
        attackRange: 300, // Updated to match createEnemyOfType
        attackCooldown: 1200, // Updated to match createEnemyOfType
        detectionRange: 350 // Updated to match createEnemyOfType
      };
    } else if (type === 'enemyType2') {
      return {
        spriteAsset: 'banditEnemy', // Updated to match createEnemyOfType
        health: 80, // Updated to match createEnemyOfType
        speed: 120, // Updated to match createEnemyOfType
        scale: 0.20, // Updated from 0.16 to 0.20
        tint: 0xFFAADD, // Updated to match createEnemyOfType
        attackRange: 300, // Updated to match createEnemyOfType
        attackCooldown: 1200, // Updated to match createEnemyOfType
        detectionRange: 350 // Updated to match createEnemyOfType
      };
    } else if (type === 'sapper') {
        return {
            spriteAsset: 'banditEnemy',
            health: 60,
            speed: 130,
            scale: 0.25,
            tint: 0xD2B48C,
            attackRange: 250,
            attackCooldown: 1500,
            detectionRange: 300
        };
    } else if (type === 'marksman') {
        return {
            spriteAsset: 'banditEnemy',
            health: 50,
            speed: 90,
            scale: 0.25,
            tint: 0x006400,
            attackRange: 500,
            attackCooldown: 2000,
            detectionRange: 600
        };
    } else if (type === 'rusher') {
        return {
            spriteAsset: 'banditEnemy',
            health: 40,
            speed: 200,
            scale: 0.18,
            tint: 0xFF0000,
            attackRange: 50,
            attackCooldown: 500,
            detectionRange: 450
        };
    }
  }
  throwMineAtPlayer(enemy) {
    // Calculate angle to player
    const angle = Phaser.Math.Angle.Between(
      enemy.sprite.x, enemy.sprite.y,
      this.scene.player.sprite.x, this.scene.player.sprite.y
    );
    
    // Create a "thrown" mine that travels toward the player
    const throwDistance = 120;
    const targetX = enemy.sprite.x + Math.cos(angle) * throwDistance;
    const targetY = enemy.sprite.y + Math.sin(angle) * throwDistance;
    
    // Visual effect for throwing
    const throwEffect = this.scene.add.circle(enemy.sprite.x, enemy.sprite.y, 4, 0x8B4513);
    throwEffect.setDepth(10);
    
    // Animate the thrown mine
    this.scene.tweens.add({
      targets: throwEffect,
      x: targetX,
      y: targetY,
      duration: 600,
      ease: 'Quad.easeOut',
      onComplete: () => {
        throwEffect.destroy();
        // Create mine at landing position with shorter arming time
        const thrownMine = this.scene.mineSystem.createMine(targetX, targetY);
        if (thrownMine) {
          // Override arming delay for thrown mines (much faster)
          if (thrownMine.armingTimer) {
            thrownMine.armingTimer.destroy();
          }
          
          thrownMine.armingTimer = this.scene.time.delayedCall(500, () => { // 0.5 seconds instead of 2
            thrownMine.isArmed = true;
            thrownMine.indicator.setAlpha(0.8);
            // Faster pulsing for thrown mines
            this.scene.tweens.add({
              targets: thrownMine.indicator,
              alpha: { from: 0.8, to: 0.3 },
              duration: 400,
              yoyo: true,
              repeat: -1,
              ease: 'Sine.easeInOut'
            });
          });
        }
      }
    });
  }
  playDeathAnimation(sprite, onComplete) {
    if (!sprite || !sprite.active) return;
    
    // Play a "fall over" animation
    this.scene.tweens.add({
      targets: sprite,
      angle: sprite.flipX ? -90 : 90, // Fall left or right
      alpha: 0,
      y: sprite.y + sprite.height * 0.2, // Drop slightly
      duration: 400,
      ease: 'Power2',
      onComplete: () => {
        if (onComplete) {
          onComplete();
        }
      }
    });
  }
  createMineLayEffect(x, y) {
    const particles = this.scene.add.particles(x, y + 20, 'bulletTracer', { // Corrected particle creation
        speed: { min: 50, max: 150 },
        angle: { min: 250, max: 290 }, // Upwards kick-up angle
        scale: { start: 0.25, end: 0 },
        tint: [0x8B4513, 0xA0522D, 0xD2B48C], // Shades of brown for dust
        blendMode: 'NORMAL',
        lifespan: 600,
        quantity: 25,
        emitting: true
    });
    particles.setDepth(10);
    this.scene.time.delayedCall(600, () => {
        if (particles) particles.destroy();
    });
  }
  layMine(enemy) {
    // Quick animation for laying a mine
    enemy.sprite.body.setVelocity(0); // Stop moving to lay the mine
    const originalDepth = enemy.sprite.depth;
    enemy.sprite.setDepth(11); // Bring to front for animation
    this.scene.tweens.add({
      targets: enemy.sprite,
      y: enemy.sprite.y - 10,
      yoyo: true,
      duration: 250,
      ease: 'Cubic.easeInOut',
      onComplete: () => {
        if (enemy && enemy.sprite.active) {
          this.createMineLayEffect(enemy.sprite.x, enemy.sprite.y); // Add visual effect
          this.scene.mineSystem.createMine(enemy.sprite.x, enemy.sprite.y);
          enemy.sprite.setDepth(originalDepth);
        }
      }
    });
  }
  dropDeathMine(x, y) {
    // Create a warning indicator
    const warning = this.scene.add.graphics();
    warning.fillStyle(0xFF0000, 0.5);
    warning.fillCircle(0, 0, 40);
    warning.setPosition(x, y);
    warning.setDepth(1);
    
    // Pulse the warning
    this.scene.tweens.add({
      targets: warning,
      scale: 0.8,
      yoyo: true,
      duration: 200,
      repeat: 2, // Pulse 3 times over 600ms
      onComplete: () => {
        warning.destroy();
        this.scene.mineSystem.createMine(x, y);
      }
    });
  }
  captureEnemyAtPosition(x, y, radius = 60) {
      let capturedEnemy = null;
      let closestDistance = radius;
      this.enemies.forEach(enemy => {
          if (enemy.sprite.active && !enemy.isCaptured) {
              const distance = Phaser.Math.Distance.Between(x, y, enemy.sprite.x, enemy.sprite.y);
              // Find the closest enemy within the radius
              if (distance < closestDistance) {
                  closestDistance = distance;
                  capturedEnemy = enemy;
              }
          }
      });
      // If an enemy was found within the radius, capture it
      if (capturedEnemy) {
          this.captureEnemy(capturedEnemy);
          // Optionally, return the captured enemy for further logic
          return capturedEnemy;
      }
      return null; // No enemy was captured
  }
  meleeAttack(enemy, target) {
    if (!target || !target.active) return;
    // Damage logic
    if (target === this.scene.player.sprite) {
        this.scene.player.takeDamage(10); // Rusher deals 10 damage
    } else {
        // If target is an NPC, find it in the npcSystem and deal damage
        const npc = this.scene.npcSystem.findNpcBySprite(target);
        if (npc) {
            this.scene.npcSystem.takeDamage(npc, 10);
        }
    }
    enemy.lastAttack = this.scene.time.now;
    // Visual feedback for the attack
    this.scene.tweens.add({
        targets: enemy.sprite,
        scaleX: enemy.sprite.scaleX * 1.2,
        scaleY: enemy.sprite.scaleY * 1.2,
        yoyo: true,
        duration: 100,
        ease: 'Cubic.easeInOut'
    });
    // Knockback effect on the enemy after attacking
    const angleToTarget = Phaser.Math.Angle.Between(enemy.sprite.x, enemy.sprite.y, target.x, target.y);
    const knockbackDistance = 50;
    enemy.sprite.body.setVelocity(
        -Math.cos(angleToTarget) * knockbackDistance * 5,
        -Math.sin(angleToTarget) * knockbackDistance * 5
    );
    this.scene.time.delayedCall(200, () => {
        if(enemy.sprite.active) {
            enemy.sprite.body.setVelocity(0,0);
        }
    });
  }
}