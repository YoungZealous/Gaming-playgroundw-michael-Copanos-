

import Phaser from 'phaser';

export class Horse extends Phaser.GameObjects.Sprite {
    constructor(scene, x, y) {
        super(scene, x, y, 'horse');
        this.scene = scene;
        scene.add.existing(this);
        scene.physics.add.existing(this);

        this.setScale(0.25);
        this.setDepth(9);
        this.body.setCollideWorldBounds(true);
        this.body.setSize(this.width * 0.7, this.height * 0.8);
        this.isMounted = false;
        this.rider = null;
        this.health = 500;
        this.maxHealth = 500;
    }
    mount(player) {
        this.isMounted = true;
        this.rider = player;
    }
    dismount() {
        if (!this.rider) return;
        const dismountX = this.x + (this.flipX ? -60 : 60);
        const dismountY = this.y;
        this.rider.sprite.setPosition(dismountX, dismountY);
        this.rider.sprite.setVisible(true);
        this.rider.sprite.body.enable = true;
        
        this.rider.isMounted = false;
        this.rider.horse = null;
        
        this.isMounted = false;
        this.rider = null;
        this.body.setVelocity(0);
    }
    update() {
        if (this.isMounted && this.rider) {
            const keys = this.scene.wasd;
            const speed = 350;
            this.body.setVelocity(0);
            if (keys.A.isDown) {
                this.body.setVelocityX(-speed);
                this.setFlipX(true);
            } else if (keys.D.isDown) {
                this.body.setVelocityX(speed);
                this.setFlipX(false);
            }
            if (keys.W.isDown) {
                this.body.setVelocityY(-speed);
            } else if (keys.S.isDown) {
                this.body.setVelocityY(speed);
            }
            
            this.rider.sprite.setPosition(this.x, this.y);
            // Allow rider to shoot
            const pointer = this.scene.input.activePointer;
            if (pointer.leftButtonDown()) {
                if (!this.rider.isWhipEquipped) {
                    this.rider.shoot(pointer);
                }
            }
        } else {
            this.body.setVelocity(0);
        }
    }
    
    takeDamage(damage) {
        if (!this.active) return;
        this.health -= damage;
        this.scene.sound.play('bullet_impact', { volume: 0.4, detune: -500 }); // Horse hit sound
        this.setTint(0xff0000); // Flash red
        this.scene.time.delayedCall(150, () => {
            if (this.active) {
                this.clearTint();
            }
        });
        if (this.health <= 0) {
            this.destroyHorse();
        }
    }
    destroyHorse() {
        if (this.isMounted && this.rider) {
            this.dismount();
        }
        this.destroy();
    }
}

