

import Phaser from 'phaser';

export class Molotov extends Phaser.Physics.Arcade.Sprite {
    constructor(scene, x, y) {
        super(scene, x, y, 'playerBullet');
        
        scene.add.existing(this);
        scene.physics.add.existing(this);
        
        this.setScale(1.2);
        this.setTint(0x331a00); // Dark brown for the bottle
        this.lifespan = 1000; // Time until it breaks
    }
    
    throw(x, y, angle) {
        this.body.reset(x, y);
        this.setActive(true);
        this.setVisible(true);
        this.setRotation(angle);
        this.body.setAngularVelocity(360); // Spinning effect

        const speed = 600;
        this.scene.physics.velocityFromRotation(angle, speed, this.body.velocity);
        
        // Break after lifespan
        this.scene.time.delayedCall(this.lifespan, () => {
            if (this.active) {
                this.explode();
            }
        });
    }

    explode() {
        this.setActive(false);
        this.setVisible(false);
        this.body.stop();
        // Create fire area at this position
        this.scene.createFireArea(this.x, this.y);
    }
    
    preUpdate(time, delta) {
        super.preUpdate(time, delta);
        // Simple boundary check to prevent getting lost
        if (this.y < -50 || this.y > this.scene.physics.world.bounds.height + 50 || this.x < -50 || this.x > this.scene.physics.world.bounds.width + 50) {
            if (this.active) {
                this.explode();
            }
        }
    }
}

