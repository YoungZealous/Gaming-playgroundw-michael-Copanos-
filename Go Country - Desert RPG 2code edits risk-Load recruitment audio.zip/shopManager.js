

import Phaser from 'phaser';

export class ShopManager {
    constructor(scene) {
        this.scene = scene;
        this.player = scene.player;

        this.container = null;
        this.isOpen = false;
        this.buttons = [];
        this.selectedButtonIndex = 0;
        this.messageText = null;

        this.items = {
            healthPack: { cost: 15, name: 'Health Pack', icon: 'healthPack' },
            lasso: { cost: 20, name: 'Lasso', icon: 'lasso' },
            life: { cost: 50, name: 'Extra Life', icon: 'playerRanger' },
            speedBoost: { cost: 10, name: 'Speed Boost', icon: 'speedBoostIcon' }
        };

        this.createMenu();
    }

    createMenu() {
        this.container = this.scene.add.container(this.scene.cameras.main.width / 2, this.scene.cameras.main.height / 2)
            .setScrollFactor(0)
            .setDepth(4000)
            .setVisible(false);

        const bg = this.scene.add.graphics();
        bg.fillStyle(0x000000, 0.9);
        bg.fillRoundedRect(-250, -200, 500, 400, 15);
        bg.lineStyle(4, 0x4E342E, 1);
        bg.strokeRoundedRect(-250, -200, 500, 400, 15);
        this.container.add(bg);

        const title = this.scene.add.text(0, -160, 'Jailhouse Shop', {
            fontSize: '36px',
            fill: '#FFD700',
            fontFamily: '"Georgia", serif',
            stroke: '#000',
            strokeThickness: 5
        }).setOrigin(0.5);
        this.container.add(title);

        const closeButton = this.scene.add.text(230, -180, 'X (ESC)', {
            fontSize: '24px',
            fill: '#FFFFFF',
            backgroundColor: '#A0522D',
            padding: { x: 10, y: 5 }
        }).setOrigin(0.5).setInteractive({ useHandCursor: true });

        closeButton.on('pointerdown', () => this.toggle());
        closeButton.on('pointerover', () => closeButton.setBackgroundColor('#C4743C'));
        closeButton.on('pointerout', () => closeButton.setBackgroundColor('#A0522D'));
        this.container.add(closeButton);

        const itemStyle = { fontSize: '24px', fill: '#FFFFFF', fontFamily: '"Georgia", serif' };
        const costStyle = { fontSize: '22px', fill: '#FFD700', fontFamily: '"Georgia", serif' };

        const items = [
            { key: 'healthPack', name: 'Health Pack', cost: this.items.healthPack.cost, icon: 'healthPack' },
            { key: 'lasso', name: 'Lasso', cost: this.items.lasso.cost, icon: 'lasso' },
            { key: 'life', name: 'Extra Life', cost: this.items.life.cost, icon: 'playerRanger' },
            { key: 'speedBoost', name: 'Speed Boost', cost: this.items.speedBoost.cost, icon: 'speedBoostIcon' }
        ];

        let yPos = -90;
        items.forEach(item => {
            this.createShopItem(item, yPos, itemStyle, costStyle);
            yPos += 80;
        });
    }

    createShopItem(item, y, itemStyle, costStyle) {
        const itemContainer = this.scene.add.container(0, y);

        const icon = this.scene.add.image(-200, 0, item.icon).setDisplaySize(50, 50);
        itemContainer.add(icon);

        const nameText = this.scene.add.text(-150, -15, item.name, itemStyle).setOrigin(0, 0.5);
        const costText = this.scene.add.text(-150, 15, `Cost: ${item.cost}`, costStyle).setOrigin(0, 0.5);
        itemContainer.add([nameText, costText]);

        const buyButton = this.scene.add.text(160, 0, 'BUY', {
            fontSize: '28px',
            fill: '#FFFFFF',
            backgroundColor: '#4CAF50',
            padding: { x: 20, y: 10 },
            fontFamily: '"Georgia", serif'
        }).setOrigin(0.5);

        buyButton.setData('itemKey', item.key);
        buyButton.setInteractive({ useHandCursor: true });
        buyButton.on('pointerdown', () => {
            const itemKey = buyButton.getData('itemKey');
            const itemData = this.items[itemKey];
            if (this.player.money >= itemData.cost) {
                const resultMessage = this.handlePurchase(itemKey);
                this.displayMessage(resultMessage, resultMessage.startsWith('Got it'));
            } else {
                this.displayMessage("You can't afford that, partner.", false);
            }
        });

        buyButton.on('pointerover', () => {
            if (this.player.money >= this.items[item.key].cost) {
                buyButton.setBackgroundColor('#66BB6A');
            }
        });
        buyButton.on('pointerout', () => {
            if (this.player.money >= this.items[item.key].cost) {
                buyButton.setBackgroundColor('#4CAF50');
            }
        });

        itemContainer.add(buyButton);
        this.buttons.push(buyButton);
        this.container.add(itemContainer);
    }

    toggle() {
        this.isOpen = !this.isOpen;
        this.container.setVisible(this.isOpen);

        if (this.isOpen) {
            this.scene.physics.pause();
            this.scene.tweens.pauseAll();
            if (this.scene.turnInPrompt) this.scene.turnInPrompt.setVisible(false);
            this.updateButtonsState();
            this.selectedButtonIndex = 0;
            this.updateButtonSelection();
            this.scene.currentUIFocus = 'shop';
        } else {
            if (this.messageText) {
                this.messageText.destroy();
                this.messageText = null;
            }
            this.scene.physics.resume();
            this.scene.tweens.resumeAll();
            this.scene.checkJailDropOff();
            if (this.scene.currentUIFocus === 'shop') {
                this.scene.currentUIFocus = 'game';
            }
        }
    }

    updateButtonsState() {
        this.buttons.forEach(button => {
            const itemKey = button.getData('itemKey');
            const item = this.items[itemKey];
            if (!item) return;
            const canAfford = this.player.money >= item.cost;

            if (canAfford) {
                button.setInteractive({ useHandCursor: true });
                button.setBackgroundColor('#4CAF50');
                button.setAlpha(1.0);
            } else {
                button.disableInteractive();
                button.setBackgroundColor('#5D4037');
                button.setAlpha(0.6);
            }
        });
    }

    updateButtonSelection() {
        this.buttons.forEach((button, index) => {
            const itemKey = button.getData('itemKey');
            const item = this.items[itemKey];
            const canAfford = this.player.money >= item.cost;

            if (canAfford) {
                if (index === this.selectedButtonIndex) {
                    button.setBackgroundColor('#66BB6A');
                    button.setScale(1.05);
                } else {
                    button.setBackgroundColor('#4CAF50');
                    button.setScale(1.0);
                }
            } else {
                button.setScale(1.0);
            }
        });
    }

    handleInput() {
        if (Phaser.Input.Keyboard.JustDown(this.scene.cursors.down) || Phaser.Input.Keyboard.JustDown(this.scene.wasd.S)) {
            this.selectedButtonIndex = (this.selectedButtonIndex + 1) % this.buttons.length;
            this.updateButtonSelection();
        } else if (Phaser.Input.Keyboard.JustDown(this.scene.cursors.up) || Phaser.Input.Keyboard.JustDown(this.scene.wasd.W)) {
            this.selectedButtonIndex = (this.selectedButtonIndex - 1 + this.buttons.length) % this.buttons.length;
            this.updateButtonSelection();
        } else if (Phaser.Input.Keyboard.JustDown(this.scene.enterKey)) {
            const selectedButton = this.buttons[this.selectedButtonIndex];
            if (selectedButton && selectedButton.input.enabled) {
                selectedButton.emit('pointerdown');
            }
        }
    }

    handlePurchase(itemKey) {
        const item = this.items[itemKey];
        if (!item) return "What in tarnation is that?";

        if (this.player.money >= item.cost) {
            this.player.money -= item.cost;

            switch (itemKey) {
                case 'healthPack':
                    this.player.inventory.healthPacks++;
                    break;
                case 'lasso':
                    this.player.lassoCount++;
                    break;
                case 'life':
                    this.player.lives++;
                    break;
                case 'speedBoost':
                    this.player.activateSpeedBoost(() => {
                        this.scene.startSpeedBoostTimer(10);
                    });
                    break;
            }

            this.scene.sound.play('chaChing', { volume: 0.6 });
            this.scene.updatePlayerStatusUI();
            this.updateButtonsState();
            return `Got it. One ${item.name} for you. That'll be ${item.cost} coin.`;
        } else {
            return `Looks like you're a bit short on coin for that, partner. You need ${item.cost}.`;
        }
    }

    displayMessage(message, isSuccess) {
        if (this.messageText) {
            this.messageText.destroy();
        }
        const messageStyle = {
            fontSize: '20px',
            fill: isSuccess ? '#4CAF50' : '#F44336',
            fontFamily: '"Georgia", serif',
            backgroundColor: 'rgba(0,0,0,0.8)',
            padding: { x: 10, y: 5 }
        };

        this.messageText = this.scene.add.text(0, 160, message, messageStyle).setOrigin(0.5);
        this.container.add(this.messageText);

        this.scene.time.delayedCall(2000, () => {
            if (this.messageText) {
                this.messageText.destroy();
                this.messageText = null;
            }
        });
    }
}

