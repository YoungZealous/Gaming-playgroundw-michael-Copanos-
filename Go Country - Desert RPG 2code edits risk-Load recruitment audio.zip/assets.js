

export const assets = {
  playerMinimapIcon: {
    name: 'playerMinimapIcon',
    url: 'https://play.rosebud.ai/assets/Untitled Project - 2025-07-07T130417.816.png?SKzg'
  },
  reloadHandgun: {
    name: 'reloadHandgun',
    url: 'https://play.rosebud.ai/assets/reload hand gun 9mm.mp3.mp3?Yn49'
  }
};

