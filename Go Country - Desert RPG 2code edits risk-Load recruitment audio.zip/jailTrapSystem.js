import Phaser from 'phaser';
export class JailTrapSystem {
    constructor(scene) {
    this.scene = scene;
    this.traps = this.scene.physics.add.group();
    this.playerTrapVisual = null;
    this.npcTrapVisuals = new Map();
  }
    placeTrap(x, y) {
        const trapSprite = this.traps.create(x, y, 'player and npc jail trap');
        trapSprite.setScale(0.25); 
        trapSprite.setDepth(100);
        trapSprite.setData('isTrap', true);
        trapSprite.refreshBody();
        return trapSprite;
    }
    trapPlayer(player) {
        if (player.isTrapped) return;
        player.isTrapped = true;
        if (!this.playerTrapVisual) {
            this.playerTrapVisual = this.scene.add.sprite(player.sprite.x, player.sprite.y, 'player and npc jail trap');
            this.playerTrapVisual.setScale(0.25);
            this.playerTrapVisual.setDepth(player.sprite.depth + 1);
        }
        this.playerTrapVisual.setVisible(true);
        this.playerTrapVisual.setPosition(player.sprite.x, player.sprite.y);
    }
    
    releasePlayer(player) {
        player.isTrapped = false;
        if(this.playerTrapVisual) {
            this.playerTrapVisual.setVisible(false);
        }
    }
    trapNPC(npc) {
        if (npc.isTrapped) return;
        
        npc.isTrapped = true;
        // The NPCsystem should handle stopping movement and shooting based on this flag.
        if (this.scene.uiManager) {
            this.scene.uiManager.displayAllyTrappedMessage(npc.name);
        }
        
        const trapVisual = this.scene.add.sprite(npc.x, npc.y, 'player and npc jail trap');
        trapVisual.setScale(0.15);
        trapVisual.setDepth(npc.depth + 1);
        this.npcTrapVisuals.set(npc, trapVisual);
    }
    
    releaseNPC(npc) {
        if (!npc.isTrapped) return;
        npc.isTrapped = false;
        if (this.npcTrapVisuals.has(npc)) {
            this.npcTrapVisuals.get(npc).destroy();
            this.npcTrapVisuals.delete(npc);
            this.scene.sound.play('chaChing', { volume: 0.5 });
        }
    }
    update() {
        if (this.scene.player?.isTrapped && this.playerTrapVisual?.visible) {
            this.playerTrapVisual.setPosition(this.scene.player.sprite.x, this.scene.player.sprite.y);
        }
        this.npcTrapVisuals.forEach((visual, npc) => {
            if (npc.active) {
                visual.setPosition(npc.x, npc.y);
            } else {
                // Clean up if NPC is destroyed
                this.releaseNPC(npc);
            }
        });
    }
}